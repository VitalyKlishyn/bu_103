/*
 * automat.c
 *
 *  Created on: 25 февр. 2023 г.
 *      Author: vitaly
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "secure.h"
#include "bu_103_bus.h"
#include "automat.h"
#include "net.h"
#include "kaskad.h"
#include "table.h"
#include "at25df.h"

extern UART_HandleTypeDef huart1;
extern I2C_HandleTypeDef hi2c1;
extern display ledDisplay;
extern uint8_t keyboard;

void InitAutomat(void)
{
	ClockRAM.config.srk = SRK_INIT;
	ReadEEtoRegisters();
	IndexingRegisters();
	LoadSettings();			// load data from EEPROM
	InitPumps();
	InitInputs();
	InitState();
	Room.currStream = 0;
	Room.stream = order_array[Room.currStream];
	alarmState_old = 0xFF;
	lsb_old = 0;
	alarm_old = 0xFF;								/// debug
	log_debug = ClockRAM.config.log_debug_state;	/// debug 1
}

void InitState(void)
{
	switch(ClockRAM.config.state_BU103)
	{
		case WORK_STATE:
		ClockRAM.config.state_BU103 = GO_WORK_STATE;
		break;

		case WAIT_STATE:
		if(ClockRAM.config.lsa)		Room.State = ROOM_OFF;		// off all RegKaskad();
		else						Room.State = ROOM_WAIT;
		ClockRAM.config.state_BU103 = GO_WAIT_STATE;
		break;

		case AVARY_STATE:
		ClockRAM.config.state_BU103 = GO_AVARY_STATE;
		break;

		default:
		Menu.CurrMenu = 0;
		break;
	}
}

void SetState(void)
{
	T1 = (uint16_t)T_hot;
	T2 = (uint16_t)T_cold;
	T3 = (uint16_t)T_out;
	T4 = (uint16_t)T_in;
	switch(ClockRAM.config.state_BU103)
	{
		case GO_WORK_STATE:
	    Menu.CurrMenu = RUN_MENU;
	    Menu.RunMenu = RUN_MENU_MIN;
	    if(Room.AllUnits)	Room.State = ROOM_START;		// on RegKaskad();
	    InitPumps();
	    Room.shnekCntr = ZOLO_RUN;
	    Room.zoloState = ZOLO_WAIT;
		if(ClockRAM.config.alrMemory == 0)
		{
			if((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0)
			{ // manual mode
				if(ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK)	BIT_SET(ClockRAM.config.dc, 4);
				else											BIT_SET(ClockRAM.config.dc, 3);
			}
			else
			{ // automatic mode
				 if(ClockRAM.config.statePumps < ERROR_PRIMARY_PUMP)
				 {
					 ControlPumps.statePumps = START_PRIMARY_PUMP;
				 }
				 else
				 {
					 ControlPumps.statePumps = ERROR_PRIMARY_PUMP;
				 }
			}
			ClockRAM.config.state_BU103 = WORK_STATE;
			Beep(BEEP_PULSE_3);
		}
		if(ClockRAM.config.alr || ClockRAM.config.alrMemory)
		{
			ClockRAM.config.state_BU103 = GO_AVARY_STATE;
			Beep(BEEP_PULSE_3);
		}
		break;

		case GO_AVARY_STATE:
		Menu.CurrMenu = AVARY_MENU;
		RelayAlarm(ALARM_ON);
		ClockRAM.config.state_BU103 = AVARY_STATE;
		cntDisplayAvary = GetCntDisplayAvary(DISPLAY_AVARY_MIN, 1);
		break;

		case GO_WAIT_STATE:
		Menu.CurrMenu = CURR_AUTH;
    	if((Room.State == ROOM_WAIT) || (Room.AllUnits == 0))
    	{
    		RelayAlarm(ALARM_OFF);
    		WaitingMode();
    		ControlPumps.statePumps = WAIT_PUMP;
    		Room.shnekCntr = ZOLO_STOP;		// shnek off
    		Room.zoloState = ZOLO_WAIT;
    		ClockRAM.config.state_BU103 = WAIT_STATE;
    		Beep(BEEP_PULSE_3);
    	}
		break;

		case WORK_STATE:
		ClockRAM.config.srk = SRK_WORK;
		if(ClockRAM.config.alr || ClockRAM.config.alrMemory)
		{
			ClockRAM.config.state_BU103 = GO_AVARY_STATE;
		}
		break;

		case AVARY_STATE:
		ClockRAM.config.srk = SRK_ALARM;
		if((ClockRAM.config.alr == 0) && (ClockRAM.config.alrMemory == 0))
		{
			RelayAlarm(ALARM_OFF);
			ClockRAM.config.state_BU103 = GO_WORK_STATE;
		}
		break;

		case WAIT_STATE:
		ClockRAM.config.srk = SRK_DEJURNY;
		break;

		default:
		break;
	}
}

void SetConfigDefault(void)
{
//		memset(ClockRAM.data8, 0, RAM_CONFIG_LEN_BYTES);
	ClockRAM.config.version = CURRENT_VERSION;
	ClockRAM.config.cfg = DEFAULT_CFG_BITS;
	ClockRAM.config.state_BU103 = WAIT_STATE;
	ClockRAM.config.T31 = T_PODACHI_DEF;
	ClockRAM.config.t37 = ROOM_TIMEOUT_T37;
	ClockRAM.config.t38 = CHANGE_TIME_UNIT_T38;
	ClockRAM.config.T41 = THRESHOLD_T41;
	ClockRAM.config.delta_T41 = DELTA_T41;
	ClockRAM.config.T42 = THRESHOLD_T42;
	ClockRAM.config.delta_T42 = DELTA_T42;
	ClockRAM.config.T43 = NTC_SENSOR_OPEN;
	ClockRAM.config.T44 = NTC_SENSOR_SHORT;
	ClockRAM.config.T45 = NTC_SENSOR_OPEN;
	ClockRAM.config.T46 = NTC_SENSOR_SHORT;
	ClockRAM.config.t33 = TIME_SHNEK_OFF;
	ClockRAM.config.t34 = TIME_SHNEK_ON;
	ClockRAM.config.T47 = THRESHOLD_ANTIFROZE;
	ClockRAM.config.delta_T47 = DELTA_ANTIFROZE;
	ClockRAM.config.t54 = DEFAULT_CFG_DELAY;
	ClockRAM.config.t63 = TIMEOUT_SERVICE+1;
	ClockRAM.config.timeout_automat = TIMEOUT_AUTOMAT+1;
	ClockRAM.config.rrk = RRK_INIT;
	ClockRAM.config.dc = BEGIN_OFF;
	ClockRAM.config.t71 = COUNT_WAIT_ALARM;
	ClockRAM.config.t72 = COUNT_TIMER_ALARM;
	ClockRAM.config.N73 = ALARM_CYCLES_TRESHOLD;
	ClockRAM.config.t81 = PUMP_TIME_CHANGE;
	ClockRAM.config.t82 = PUMP_SWITCH_DELAY;
	ClockRAM.config.t83 = PUMP_CFG_DELAY;
	ClockRAM.config.t11 = TEST_LINE_TIMEOUT;
	ClockRAM.config.AM = BU103_ADDR;
	ClockRAM.config.alr = 0;
	ClockRAM.config.tdi = DEFAULT_CFG_TYPE;
	ClockRAM.config.alrMemory = 0;
	ClockRAM.config.wrn = 0;
	ClockRAM.config.T35 = TEMPERATURE_CORR;
	ClockRAM.config.N34 = TEMPERATURE_KOEF;
	ClockRAM.config.T36 = TEMPERATURE_MINIMAL;
	ClockRAM.config.RoomState = ROOM_WAIT;
	ClockRAM.config.lsa = 0;
	ClockRAM.config.lsb = 0;
	ClockRAM.config.ipHi = 0x0A08;	// 10 8; C0 A8
	ClockRAM.config.ipLow = 0x000A;	// 0 10
	ClockRAM.config.ipPort = BU_PORT;
	ClockRAM.config.serverHi = 0x0A08;	// 10 8; 217 77
	ClockRAM.config.serverLow = 0x0001;	// 0 1; 209 122
	ClockRAM.config.gwHi = 0x0A08;	// 10 8; C0 A8
	ClockRAM.config.gwLow = 0x0009;	// 0 9
	ClockRAM.config.maskHi = 0xFFFF;	// 255 255
	ClockRAM.config.maskLow = 0xFFFC;	// 255 252
	ClockRAM.config.mac2_3 = 0xF2F3;	// F2 F3
	ClockRAM.config.mac4_5 = 0xF4F5;	// F4 F5
	ClockRAM.config.log_debug_state = 0;
	RefreshEEpromData();						// write data to EEPROM memory
}

void ReadEEtoRegisters(void)
{
#ifdef _MEMORY_25_SERIES
	at25df_read(START_ADDR, ClockRAM.data8, RAM_CONFIG_LEN_BYTES); //	ReadEEtoRAM
#endif

#ifdef _MEMORY_24_SERIES
	HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, START_ADDR, I2C_MEMADD_SIZE_16BIT, ClockRAM.data8, RAM_CONFIG_LEN_BYTES, TIMEOUT_I2C);
#endif

	if(ClockRAM.config.version == 0xFFFF)
	{
		SetConfigDefault();
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nrestore_default_data...");
		}
#endif
	}
	if(ClockRAM.config.version != CURRENT_VERSION)
	{
		ClockRAM.config.version = CURRENT_VERSION;
		RefreshEEpromData();						// write data to EEPROM memory
	}
}

void RefreshEEpromData(void)
{ // writing data to EEPROM memory
	WriteRAMtoEE(START_ADDR, ClockRAM.data8, RAM_CONFIG_LEN_BYTES);
}

void RunMenu(void)
{
	rm_counter++;
	switch(Menu.CurrMenu)
	{
		default:
		case CURR_AUTH:
		if(Room.State != ROOM_WAIT)
		{
			Display("---", OHRANA_CURR, STATE_GREEN, FLASH_DIGIT);
		}
		else
		{
			Display("---", OHRANA_CURR, STATE_GREEN, FLASH_OFF);
		}
		break;

		case AVARY_MENU:
		cntDisplayAvary = GetCntDisplayAvary(cntDisplayAvary, 0);
		DisplayAvary(cntDisplayAvary);
		break;

		case RUN_MENU:
		switch(Menu.RunMenu)
		{
			case RUN_ACTIVE:
			if(T_hot < T_HOT_IND_MIN)		Display(ToDisplay(T_HOT_IND_MIN), OHRANA_CURR, STATE_YELLOW, FLASH_OFF);
			else if(T_hot > T_HOT_IND_MAX)	Display(ToDisplay(T_HOT_IND_MAX), OHRANA_CURR, STATE_YELLOW, FLASH_OFF);
			else 							Display(ToDisplay(T_hot), OHRANA_CURR, STATE_YELLOW, FLASH_OFF);
			break;

			case RUN_SET_UST:
			Display(ToDisplay(ClockRAM.config.T31), OHRANA_CURR, STATE_CURR, FLASH_OFF);
			break;

		    case RUN_SEL_PUMP:
		    Display("0_H", OHRANA_CURR, STATE_CURR, FLASH_OFF);
		    break;

		    case RUN_SEL_MODE:
		    if(ControlPumps.selMode)	Display("P_A", OHRANA_CURR, STATE_CURR, FLASH_OFF);
		    else						Display("P_P", OHRANA_CURR, STATE_CURR, FLASH_OFF);
		    break;

		    case RUN_PUMP_1:
		    Display("H_1", OHRANA_CURR, STATE_CURR, FLASH_OFF);
		    if(BIT_TEST(ClockRAM.config.dc, 3))	Menu.Param = 1;
		    else								Menu.Param = 0;
		    break;

		    case RUN_PUMP_2:
		    Display("H_2", OHRANA_CURR, STATE_CURR, FLASH_OFF);
		    if(BIT_TEST(ClockRAM.config.dc, 4))	Menu.Param = 1;
		    else								Menu.Param = 0;
		    break;

		    default:
		    break;
		}
		break;

		case SUB_RUN_MENU:
		switch(Menu.RunMenu)
		{
			default:

			break;

			case RUN_ACTIVE:
			if(T_hot < T_HOT_IND_MIN)		Display(ToDisplay(T_HOT_IND_MIN), OHRANA_CURR, STATE_YELLOW, FLASH_OFF);
			else if(T_hot > T_HOT_IND_MAX)	Display(ToDisplay(T_HOT_IND_MAX), OHRANA_CURR, STATE_YELLOW, FLASH_OFF);
			else 							Display(ToDisplay(T_hot), OHRANA_CURR, STATE_YELLOW, FLASH_OFF);
			Menu.CurrMenu = RUN_MENU;
			break;

			case RUN_SET_UST:
			Display(ToDisplay(ClockRAM.config.T31), OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
			break;

			case RUN_SEL_PUMP:
			if(ControlPumps.selPump)	Display("H_2", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
			else						Display("H_1", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
			break;

			case RUN_SEL_MODE:
			if(ControlPumps.selMode)	Display("P_A", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
			else						Display("P_P", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
			break;

			case RUN_PUMP_1:
			if((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0)
			{ // manual mode
				if(Menu.Param == 0)
				{
					if(BIT_TEST(ClockRAM.config.dc, 4))	Display("-0-", OHRANA_CURR, STATE_CURR, FLASH_OFF);
					else								Display("-0-", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
				}
				if(Menu.Param == 1)
				{
					Display("-1-", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
					BIT_CLR(ClockRAM.config.dc, 2);		// set 1-st pump active
				}
			}
			else
			{ // automatic mode
				if(Menu.Param == 0)		Display("-0-", OHRANA_CURR, STATE_CURR, FLASH_OFF);
				else					Display("-1-", OHRANA_CURR, STATE_CURR, FLASH_OFF);
			}
			break;

			case RUN_PUMP_2:
			if((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0)
			{ // manual mode
				if(Menu.Param == 0)
				{
					if(BIT_TEST(ClockRAM.config.dc, 3))		Display("-0-", OHRANA_CURR, STATE_CURR, FLASH_OFF);
					else									Display("-0-", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
				}
				if(Menu.Param == 1)
				{
					Display("-1-", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);
					BIT_SET(ClockRAM.config.dc, 2);		// set 2-st pump active
				}
			}
			else
			{
				if(Menu.Param == 0)		Display("-0-", OHRANA_CURR, STATE_CURR, FLASH_OFF);
				else					Display("-1-", OHRANA_CURR, STATE_CURR, FLASH_OFF);
			}
			break;
		}
		break;

		case CURR_SERVICE:
		switch(Menu.ServiceMenu)
		{
			case SERVICE_UZO:
			Display("Y30", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_N1:			//	2
			Display("H_1", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_N2:			//	3
			Display("H_2", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_AVR:			//	4
			Display("A8P", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_SZO:			//	5
			Display("C30", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_RZV:			//	6
			Display("P38", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_TPOD:			//	7
			Display("_tZ", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_TOBR:			//	8
			Display("_t0", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_TOUT:			//	9
			Display("_tH", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_TIN:			//	10
			Display("_tz", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_UIN:			//	11
			Display("_Ui", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_CC:			//	12
			Display("C_C", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_CO:			//	13
			Display("C_0", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_7C:			//	14
			Display("7_C", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_PV:			//	15
			Display("_Z8", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_NV:			//	16
			Display("_H8", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_NN:			//	17
			Display("_HH", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_NC:			//	18
			Display("_HC", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_OC:			//	19
			Display("_0C", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_PC:			//	20
			Display("_ZC", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_NR:			//	21
			Display("_HP", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			case SERVICE_NZ:			//	22
			Display("_H3", OHRANA_OFF, STATE_OFF, FLASH_OFF);
			break;

			default:
			break;
		}
		break;

		case SUB_MENU_SERVICE:
		switch(Menu.ServiceMenu)
		{
			case SERVICE_UZO:
			if(Menu.Param == 0)
			{
				Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_SHNEK, 0);
			}
			if(Menu.Param == 1)
			{
				Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_SHNEK, 1);
			}
			break;

			case SERVICE_N1:			//	2
			if(Menu.Param == 0)
			{
				Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_PUMP1, 0);
			}
			if(Menu.Param == 1)
			{
				Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_PUMP1, 1);
			}
			break;

			case SERVICE_N2:			//	3
			if(Menu.Param == 0)
			{
				Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_PUMP2, 0);
			}
			if(Menu.Param == 1)
			{
				Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_PUMP2, 1);
			}
			break;

			case SERVICE_AVR:			//	4
			if(Menu.Param == 0)
			{
				Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_ALARM, 0);
			}
			if(Menu.Param == 1)
			{
				Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_ALARM, 1);
			}
			break;

			case SERVICE_SZO:			//	5
			if(Menu.Param == 0)
			{
				Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_SZO_BUZ, 0);
				Relays(RELAY_SZO_LED, 0);
			}
			if(Menu.Param == 1)
			{
				Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_SZO_BUZ, 1);
				Relays(RELAY_SZO_LED, 1);
			}
			break;

			case SERVICE_RZV:			//	6
			if(Menu.Param == 0)
			{
				Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_REZERV, 0);
			}
			if(Menu.Param == 1)
			{
				Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
				Relays(RELAY_REZERV, 1);
			}
			break;

			case SERVICE_TPOD:			//	7
			Display(ToDisplay(T_hot), OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_TOBR:			//	8
			Display(ToDisplay(T_cold), OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_TOUT:			//	9
			Display(ToDisplay(T_out), OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_TIN:			//	10
			Display(ToDisplay(T_in), OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_UIN:			//	11
			Display(ToDisplay(U_input), OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_CC:			//	12
			if(rm_counter & 0x01)	Display("C_C", OHRANA_OFF, STATE_RED, FLASH_DIGIT);
			else					Display("C_C", OHRANA_OFF, STATE_GREEN, FLASH_DIGIT);
			break;

			case SERVICE_CO:			//	13
			if(rm_counter & 0x01)	Display("C_0", OHRANA_RED, STATE_OFF, FLASH_DIGIT);
			else					Display("C_0", OHRANA_GREEN, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_7C:			//	14
			if(rm_counter > 9)		rm_counter = 0;
			switch(rm_counter)
			{
				case 0:
				Display("000", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 1:
				Display("111", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 2:
				Display("222", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 3:
				Display("333", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 4:
				Display("444", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 5:
				Display("555", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 6:
				Display("666", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 7:
				Display("777", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 8:
				Display("888", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
				case 9:
				Display("999", OHRANA_OFF, STATE_OFF, FLASH_OFF);
				break;
			}
			break;

			case SERVICE_PV:			//	15
			if(BIT_TEST(inputData, 0))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_NV:			//	16
			if(BIT_TEST(inputData, 1))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_NN:			//	17
			if(BIT_TEST(inputData, 2))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_NC:			//	18
			if(BIT_TEST(inputData, 3))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_OC:			//	19
			if(BIT_TEST(inputData, 4))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_PC:			//	20
			if(BIT_TEST(inputData, 5))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_NR:			//	21
			if(BIT_TEST(inputData, 6))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			case SERVICE_NZ:			//	22
			if(BIT_TEST(inputData, 7))	Display("-1-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			else						Display("-0-", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);
			break;

			default:
			break;
		}
		break;

		case IN_TO_SERVICE:
		Display("CP8", OHRANA_OFF, STATE_OFF, FLASH_OFF);
		timeoutService = ClockRAM.config.t63;
		if(rm_counter > 5)
		{
			Menu.CurrMenu = CURR_SERVICE;
			Menu.ServiceMenu = SERVICE_MIN;
			exitService();
		}
		break;
	}
}

void AntiFroze()
{
	if(BIT_TEST(ClockRAM.config.cfg, 0) == 0)	return;

	if(ClockRAM.config.state_BU103 == WAIT_STATE)
	{
		if(BIT_TEST(ClockRAM.config.wrn, 8))
		{
			ControlPumps.statePumps = START_PRIMARY_PUMP;
		}
		else
		{
			ControlPumps.statePumps = WAIT_PUMP;
			BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
			BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
		}
	}
}

void InitInputs(void)
{
	InitD(&DA11, ClockRAM.config.tdi, 0);
	InitD(&DA12, ClockRAM.config.tdi, 1);
	InitD(&DA13, ClockRAM.config.tdi, 2);
	InitD(&DA14, ClockRAM.config.tdi, 3);
	InitD(&DA15, ClockRAM.config.tdi, 4);
	InitD(&DA16, ClockRAM.config.tdi, 5);
	InitD(&DA17, ClockRAM.config.tdi, 6);
	InitD(&DA18, ClockRAM.config.tdi, 7);
}

void TestInputs(void)
{
	TestD(&DA11, ClockRAM.config.t54, 0);
	TestD(&DA12, ClockRAM.config.t54, 1);
	TestD(&DA13, ClockRAM.config.t54, 2);
	TestD(&DA14, ClockRAM.config.t54, 3);
	TestD(&DA15, ClockRAM.config.t54, 4);
	TestD(&DA16, ClockRAM.config.t54, 5);
	TestD(&DA17, ClockRAM.config.t54, 6);
	TestD(&DA18, ClockRAM.config.t54, 7);
}

void InitD(input_t *dd, uint16_t type, uint8_t bit)
{//
	if(BIT_TEST(type, bit))		dd->type = PINTYPE_NC;
	else						dd->type = PINTYPE_NO;
	dd->delay = 0;
	if(dd->type == PINTYPE_NO)		dd->state = 1;
	if(dd->type == PINTYPE_NC)		dd->state = 0;
}

void TestD(input_t *DP , uint16_t dly, uint16_t bit)
{	// inputData, out in registers di, dim
	uint8_t val;

	if(BIT_TEST(inputData, bit))	val = 1;
	else							val = 0;
	if(DP->state != val)
	{
		DP->state = val;
		DP->delay = dly;
		if(DP->delay == 0)		DP->delay = 1;
	}
	if(DP->delay == 0)
	{
		if(((DP->state == 0) && (DP->type == PINTYPE_NO)) || ((DP->state == 1) && (DP->type == PINTYPE_NC)))
		{
			BIT_SET(DIO, bit);
		}
	}
	else
	{
		if(((DP->state == 1) && (DP->type == PINTYPE_NO)) || ((DP->state == 0) && (DP->type == PINTYPE_NC)))
		{
			BIT_CLR(DIO, bit);
		}
	}
}

void AvaryDA11(void)
{ // 1, APV
	if(BIT_TEST(DIO, 0) && (T_hot >= (int16_t)ClockRAM.config.T41))
	{ // bit 1
		BIT_SET(ClockRAM.config.alr, 0);
		RoomOff();			// off all working units
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, 0))
		{
			BIT_CLR(ClockRAM.config.alr, 0);
			BIT_SET(ClockRAM.config.alrMemory, 0);
		}
	}
}

void AvaryDA12(void)
{ // 2, ANV
	if(BIT_TEST(DIO, 1))
	{ // bit 2
		BIT_SET(ClockRAM.config.alr, 1);
		ControlPumps.statePumps = WAIT_PUMP;
		BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
		BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
		RoomOff();			// off all working units
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, 1))
		{
			BIT_CLR(ClockRAM.config.alr, 1);
			BIT_SET(ClockRAM.config.alrMemory, 1);
		}
	}
}

void AvaryDA13(void)
{ // 3, ANN
	if(BIT_TEST(ClockRAM.config.alr, 2))
	{
		BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
		BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
		ControlPumps.alrCnt++;			// counter delay from alr to alrMemory
	}
	if(ControlPumps.alrCnt > PUMP_SWITCH_DELAY)
	{
		BIT_CLR(ClockRAM.config.alr, 2);
		BIT_SET(ClockRAM.config.alrMemory, 2);
		ControlPumps.alrCnt = 0;
		RoomOff();			// off all working units
	}
}

void AvaryDA14(void)
{ // 4, ANS, net
	if(BIT_TEST(DIO, 3))
	{ // bit 4
		BIT_SET(ClockRAM.config.alr, 3);
		ControlPumps.statePumps = WAIT_PUMP;
		BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
		BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
		Room.shnekCntr = ZOLO_STOP;		// shnek off
		Room.zoloState = ZOLO_WAIT;
		RoomOff();			// off all working units
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, 3))
		{
			BIT_CLR(ClockRAM.config.alr, 3);
			BIT_SET(ClockRAM.config.alrMemory, 3);
		}
	}
}

void AvaryDA11DT11(void)
{ // 5, NPV
	if((T_hot < (int16_t)ClockRAM.config.T41) && BIT_TEST(DIO, 0))
	{ // bit 5
		BIT_SET(ClockRAM.config.alr, 4);
		BIT_CLR(ClockRAM.config.alr, 0);
		RoomOff();			// off all working units
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, 4))
		{
			BIT_CLR(ClockRAM.config.alr, 4);
			BIT_SET(ClockRAM.config.alrMemory, 4);
		}
	}
}

void AvaryDT11DA11(void)
{ // 6, NtP, 11, OtP, 12, ZtP
	if(BIT_TEST(tempDIO, 0))
	{ // avary DT11 open, bit 10
		BIT_SET(ClockRAM.config.alr, 10);
		if(BIT_TEST(ClockRAM.config.cfg, 3) == 0)
		{ // scenary 0
			RoomOff();			// off all working units
		}
	}
	else if(BIT_TEST(tempDIO, 1))
	{ // avary DT11 short, bit 11
		BIT_SET(ClockRAM.config.alr, 11);
		if(BIT_TEST(ClockRAM.config.cfg, 3) == 0)
		{ // scenary 0
			RoomOff();			// off all working units
		}
	}
	else if((T_hot >= (int16_t)ClockRAM.config.T42) && (BIT_TEST(DIO, 0) == 0))
	{ // bit 6
		 BIT_SET(ClockRAM.config.alr, 5);
		 RoomOff();			// off all working units
	}
	if(T_hot < ((int16_t)ClockRAM.config.T42-(int16_t)ClockRAM.config.delta_T42))
	{
		if(BIT_TEST(ClockRAM.config.alr, 5))
		{
			BIT_CLR(ClockRAM.config.alr, 5);
			BIT_SET(ClockRAM.config.alrMemory, 5);
		}
	}
	if(BIT_TEST(tempDIO, 0) == 0)
	{ // bit 11
		if(BIT_TEST(ClockRAM.config.alr, 10))
		{
			BIT_CLR(ClockRAM.config.alr, 10);
			BIT_SET(ClockRAM.config.alrMemory, 10);
		}
	}
	if(BIT_TEST(tempDIO, 1) == 0)
	{  // bit 12
		if(BIT_TEST(ClockRAM.config.alr, 11))
		{
			BIT_CLR(ClockRAM.config.alr, 11);
			BIT_SET(ClockRAM.config.alrMemory, 11);
		}
	}
}

void AvaryDA16(void)
{ // 7, APS
	if(BIT_TEST(DIO, 5))
	{ // bit 7
		BIT_SET(ClockRAM.config.alr, 6);
		Room.shnekCntr = ZOLO_RUN;		// shnek on
		Room.zoloState = ZOLO_WAIT_DLY_OFF;
		Room.shnekTimeOff = 0;
		RoomOff();			// off all working units
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, 6))
		{
			BIT_CLR(ClockRAM.config.alr, 6);
			BIT_SET(ClockRAM.config.alrMemory, 6);
		}
	}
}

void AvaryDA17(void)
{ // 8, ANP
	if(BIT_TEST(DIO, 6))
	{ // bit 8
		BIT_SET(ClockRAM.config.alr, 7);
		RoomOff();			// off all working units
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, 7))
		{
			BIT_CLR(ClockRAM.config.alr, 7);
			BIT_SET(ClockRAM.config.alrMemory, 7);
		}
	}
}

void AvaryDA18(void)
{
	if(BIT_TEST(DIO, 7))
	{ // bit 9
		BIT_SET(ClockRAM.config.alr, 8);
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, 8))
		{
			BIT_CLR(ClockRAM.config.alr, 8);
			BIT_SET(ClockRAM.config.alrMemory, 8);
		}
	}
}

void AvaryBA(void)
{ // bit 10, set if case avary in BA103
//	Display("A6A", OHRANA_CURR, STATE_CURR, FLASH_DIGIT);		// "A6A"
//	Display("A6A", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "A6A"
}

void SetAvary(void)
{
	if(alarmState_old != ClockRAM.config.alr)
	{
		if(alarmState_old < ClockRAM.config.alr)
		{
			Beep(BEEP_PULSE_5);
		}
		alarmState_old = ClockRAM.config.alr;
	}
	if(alarm_old != ALR)
	{
		alarm_old = ALR;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nALR: 0x");
			itoa(ALR, buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(warning_old != ClockRAM.config.wrn)
	{
		if(warning_old < ClockRAM.config.wrn)
		{
			Beep(BEEP_PULSE_4);
		}
		warning_old = ClockRAM.config.wrn;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nwrn: 0x");
			itoa(ClockRAM.config.wrn, buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(lsb_old != ClockRAM.config.lsb)
	{
		if(lsb_old < ClockRAM.config.lsb)
		{
			Beep(BEEP_PULSE_4);
		}
		if(ClockRAM.config.lsb)
		{
			BIT_SET(ClockRAM.config.wrn, 10);
		}
		else
		{
			BIT_CLR(ClockRAM.config.wrn, 10);
		}
		lsb_old = ClockRAM.config.lsb;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nlsa: 0b");
			itoa(ClockRAM.config.lsa, buff, 2);
			Println(&huart1, buff);
			Println(&huart1, "; lsb: 0b");
			itoa(ClockRAM.config.lsb, buff, 2);
			Println(&huart1, buff);
		}
#endif
	}
#ifdef _AUTOMAT_OUTPUT_UART
	if(log_debug)
	{
		if(di_old != DIO)
		{
			Println(&huart1, "\ndio: 0x");
			itoa(DIO, buff, 16);
			Println(&huart1, buff);
			di_old = DIO;
		}
	}
#endif
	if(ClockRAM.config.statePumps != ControlPumps.statePumps)
	{
		ClockRAM.config.statePumps = ControlPumps.statePumps;
	}
	if(ClockRAM.config.state_BU103 > WAIT_STATE)
	{
		AvaryDA11();		// alarmState, bit1
		AvaryDA12();		// alarmState, bit2
		AvaryDA13();		// alarmState, bit3
		AvaryDA14();		// alarmState, bit4
		AvaryDA11DT11();	// alarmState, bit5
		AvaryDT11DA11();	// alarmState, bit6
		AvaryDA16();		// alarmState, bit7
		AvaryDA17();		// alarmState, bit8
		AvaryDA18();		// alarmState, bit9
		AvaryBA();			// alarmState, bit10
	}
	ALR = ClockRAM.config.alr | ClockRAM.config.alrMemory;
	Warnings();
}

void Warnings(void)
{
	if(T_hot >= (int16_t)ClockRAM.config.T41)	BIT_SET(ClockRAM.config.wrn, 7);
	else										BIT_CLR(ClockRAM.config.wrn, 7);
	if(T_in <= (int16_t)ClockRAM.config.T47)
	{
		BIT_SET(ClockRAM.config.wrn, 8);
	}
	if(T_in >= ((int16_t)ClockRAM.config.T47 + (int16_t)ClockRAM.config.delta_T47))
	{
		BIT_CLR(ClockRAM.config.wrn, 8);
	}
}

void DisplayAvary(uint16_t cnt)
{
	if(ClockRAM.config.alr)
	{
		if(BitCalc(ClockRAM.config.alr) > 1)		indPoints = 1;
		else										indPoints = 0;
		switch(cnt)
		{
			default:
			break;

			case 0:
			Display("AZ8", OHRANA_CURR, STATE_RED, FLASH_DIGIT);	// "АПВ"
			break;

			case 1:
			Display("AH8", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "АHВ"
			break;

			case 2:
			Display("AHH", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "АHH"
			break;

			case 3:
			Display("AHC", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "АHC"
			break;

			case 4:
			Display("HZ8", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "НПВ"
			break;

			case 5:
			Display("HtZ", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "НtП"
			break;

			case 6:
			Display("AZC", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "AПC"
			break;

			case 7:
			Display("AHP", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "AHP"
			break;

			case 8:
			Display("AH3", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "AH3"
			break;

			case 9:
			Display("A6A", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "A6A"
			break;

			case 10:
			Display("0tZ", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "0tП"
			break;

			case 11:
			Display("3tZ", OHRANA_CURR, STATE_RED, FLASH_DIGIT);		// "3tП"
			break;
		}
	}
	else if(ClockRAM.config.alrMemory)
	{
		if(BitCalc(ClockRAM.config.alrMemory) > 1)		indPoints = 1;
		else											indPoints = 0;
		switch(cnt)
		{
			default:
			break;

			case 0:
			Display("AZ8", OHRANA_CURR, STATE_CURR, FLASH_OFF);	// "АПВ"
			break;

			case 1:
			Display("AH8", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "АHВ"
			break;

			case 2:
			Display("AHH", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "АHH"
			break;

			case 3:
			Display("AHC", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "АHC"
			break;

			case 4:
			Display("HZ8", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "НПВ"
			break;

			case 5:
			Display("HtZ", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "НtП"
			break;

			case 6:
			Display("AZC", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "AПC"
			break;

			case 7:
			Display("AHP", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "AHP"
			break;

			case 8:
			Display("AH3", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "AH3"
			break;

			case 9:
			Display("A6A", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "A6A"
			break;

			case 10:
			Display("0tZ", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "0tП"
			break;

			case 11:
			Display("3tZ", OHRANA_CURR, STATE_CURR, FLASH_OFF);		// "3tП"
			break;
		}
	}
}

uint16_t GetCntDisplayAvary(uint16_t curr_cnt, uint8_t dir)
{
	uint16_t cnt;

	cnt = curr_cnt;
	if(dir == 0)  // 0 - no change
	{
		if(ClockRAM.config.alr)
		{
			if(BIT_TEST(ClockRAM.config.alr, curr_cnt) == 0)
			{
				dir = 1;
			}
		}
		else if(ClockRAM.config.alrMemory)
		{
			if(BIT_TEST(ClockRAM.config.alrMemory, curr_cnt) == 0)
			{
				dir = 1;
			}
		}
	}
	if(dir == 1)
	{ // increment, 1
		if(ClockRAM.config.alr)
		{
			do
			{
				cnt++;
				if(cnt > DISPLAY_AVARY_MAX) 	cnt = DISPLAY_AVARY_MIN;
				if(BIT_TEST(ClockRAM.config.alr, cnt))	break;
			}while(cnt != curr_cnt);
		}
		else if(ClockRAM.config.alrMemory)
		{
			do
			{
				cnt++;
				if(cnt > DISPLAY_AVARY_MAX) 	cnt = DISPLAY_AVARY_MIN;
				if(BIT_TEST(ClockRAM.config.alrMemory, cnt))	break;
			}while(cnt != curr_cnt);
		}
	}
	if(dir == 2)
	{ // decrement, 2
		if(ClockRAM.config.alr)
		{
			do
			{
				if(cnt >= DISPLAY_AVARY_MIN)	cnt--;
				if(cnt < DISPLAY_AVARY_MIN)	cnt = DISPLAY_AVARY_MAX;
				if(BIT_TEST(ClockRAM.config.alr, cnt))	break;
			}while(cnt != curr_cnt);
		}
		else if(ClockRAM.config.alrMemory)
		{
			do
			{
				if(cnt >= DISPLAY_AVARY_MIN)	cnt--;
				if(cnt < DISPLAY_AVARY_MIN)		cnt = DISPLAY_AVARY_MAX;
				if(BIT_TEST(ClockRAM.config.alrMemory, cnt))	break;
			}while(cnt != curr_cnt);
		}
	}
	return cnt;
}

void InitPumps(void)
{
	ClockRAM.config.srn = 1;	// 0x01 - init state
	ControlPumps.pumpDelay = 0;
	BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
	Pump1.cntTimePump = 0;
	Pump1.workTimePump = 0;
	BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
	Pump2.cntTimePump = 0;
	Pump2.workTimePump = 0;
	BIT_CLR(ClockRAM.config.wrn, 6);	// clear pump warning
	BIT_CLR(ClockRAM.config.alr, 2);	// clear avary DA13
	if(BIT_TEST(ClockRAM.config.alrMemory, 1) ||
	   BIT_TEST(ClockRAM.config.alrMemory, 2) ||
	   BIT_TEST(ClockRAM.config.alrMemory, 3))
	{
		ControlPumps.statePumps = WAIT_PUMP;
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.dc, 0))
		{ // room on
			if((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0)
			{ // manual mode
				if(ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK)	BIT_SET(ClockRAM.config.dc, 4);
				else											BIT_SET(ClockRAM.config.dc, 3);
			}
			else
			{ // automatic mode
				if(ClockRAM.config.statePumps < ERROR_PRIMARY_PUMP)
				{
					ControlPumps.statePumps = START_PRIMARY_PUMP;
				}
				else
				{
					ControlPumps.statePumps = ERROR_PRIMARY_PUMP;
				}
			}
		}
	}
}

void Pump(void)
{
	if(ClockRAM.config.rrk & RRK_MODE_PUMP_MASK)
	{ // automatic mode
		switch (ControlPumps.statePumps)
		{
			case START_PRIMARY_PUMP:
			if(ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK)
			{ // pump 2
				Pump2.cntTimePump = 0;
				Pump2.workTimePump = 0;
				BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
				BIT_SET(ClockRAM.config.dc, 4);	// Pump2 ON;
			}
			else
			{ // pump 1
				Pump1.cntTimePump = 0;
				Pump1.workTimePump = 0;
				BIT_SET(ClockRAM.config.dc, 3);	// Pump1 ON;
				BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
			}
			if(BIT_TEST(DIO, 9) || BIT_TEST(DIO, 10))
			{
				ClockRAM.config.srn = 4;	// 0x04 - on osnovnoy nasos
			}
			ControlPumps.statePumps = TIMEOUT_PRIMARY;
			break;

			case TIMEOUT_PRIMARY:
			if(ControlPumps.cntTimeDiff == 0)
			{
				ControlPumps.statePumps = PRIMARY_PUMP;
			}
			break;

			case PRIMARY_PUMP:
			if((ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK) == 0)
			{ // pump 1 is primary
				Pump1.cntTimePump++;
				if(Pump1.cntTimePump >= 3600)	Pump1.workTimePump++;	/// 2->3600
				if(Pump1.workTimePump >= ClockRAM.config.t81)
				{ // change pump
					ControlPumps.statePumps = TIMER_CHANGE_PUMP;
				}
			}
			if(ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK)
			{ // pump 2 is primary
				Pump2.cntTimePump++;
				if(Pump2.cntTimePump >= 3600)	Pump2.workTimePump++;	/// 2->3600
				if(Pump2.workTimePump >= ClockRAM.config.t81)
				{ // change pump
					ControlPumps.statePumps = TIMER_CHANGE_PUMP;
				}
			}
			if(BIT_TEST(DIO, 2) == 0)
			{
				ControlPumps.statePumps = ERROR_PRIMARY_PUMP;
			}
			break;

			case TIMER_CHANGE_PUMP:
			BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
			BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
			ControlPumps.statePumps = CHANGE_PUMP;
			break;

			case CHANGE_PUMP:
			BIT_INV(ClockRAM.config.dc, 2);
			ControlPumps.statePumps = START_PRIMARY_PUMP;
			break;

			case ERROR_PRIMARY_PUMP:
			BIT_CLR(ClockRAM.config.dc, 3);			// Pump1 OFF;
			BIT_CLR(ClockRAM.config.dc, 4);			// Pump2 OFF;
			BIT_SET(ClockRAM.config.wrn, 6);		// set warning primary pump
			ControlPumps.statePumps = TIMER_ERROR_PUMP;
			break;

			case TIMER_ERROR_PUMP:
			if(ControlPumps.pumpDelay == 0)
			{
				if((ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK) == 0)
				{ // pump 1 is primary, on reserv
					BIT_SET(ClockRAM.config.dc, 4);	// Pump2 ON;
				}
				if(ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK)
				{ // pump 2 is primary, on reserv
					BIT_SET(ClockRAM.config.dc, 3);	// Pump1 ON;
				}
				if(BIT_TEST(DIO, 9) || BIT_TEST(DIO, 10))
				{
					ClockRAM.config.srn = 8;	// 0x08 - on orezerv nasos
					ControlPumps.statePumps = TIMEOUT_REZERV;
				}
			}
			break;

			case TIMEOUT_REZERV:
			if(ControlPumps.cntTimeDiff == 0)
			{
				ControlPumps.statePumps = REZERV_PUMP;
			}
			break;

			case REZERV_PUMP:
			if(BIT_TEST(DIO, 2) == 0)
			{
				ControlPumps.statePumps = ALARM_PUMP;
			}
			break;

			case ALARM_PUMP:
			ClockRAM.config.srn = 0x10;			// 0x10 - avary pumps
			ControlPumps.alrCnt = 0;
			BIT_SET(ClockRAM.config.alr, 2);
			ControlPumps.statePumps = WAIT_PUMP;
			break;

			case CHANGE_PRIMARY_PUMP:
			if(ClockRAM.config.dc & DC_PUMPS_MASK)
			{
				if((ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK) && (ClockRAM.config.dc & PUMP_1_MASK))
				{ // if set pump 2 & pump 1 is on
					BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
					BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
				}
				if(((ClockRAM.config.dc & DC_ACTIVE_PUMP_MASK) == 0) && (ClockRAM.config.dc & PUMP_2_MASK))
				{ //  if set pump 1 & pump 2 is on
					BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
					BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
				}
			}
			ControlPumps.statePumps = CHANGE_PRIMARY_PUMP+1;
			break;

			case CHANGE_PRIMARY_PUMP+1:
			if(ControlPumps.pumpDelay == 0)
			{
				ControlPumps.statePumps = START_PRIMARY_PUMP;
			}
			break;

			case WAIT_PUMP:
			default:
				ClockRAM.config.dc &= ~DC_PUMPS_MASK;  // off pumps
			break;
		}
	}
	if((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0)
	{ // manual mode

	}
	if(dc_old != ClockRAM.config.dc)
	{
		dc_old = ClockRAM.config.dc;
		if((ControlPumps.pumpDelay == 0) && ((ClockRAM.config.dc & DC_PUMPS_MASK) != DC_PUMPS_MASK))
		{
			if(ClockRAM.config.dc & PUMP_1_MASK)
			{
				Relays(RELAY_PUMP1, 1);	// on relay
				ControlPumps.cntTimeDiff = ClockRAM.config.t83+ClockRAM.config.t54+2;
#ifdef _AUTOMAT_OUTPUT_UART
				if(log_debug)
				{
					Println(&huart1, "\nNASOS_1_ON");
				}
#endif
			}
			else
			{
				Relays(RELAY_PUMP1, 0);		// off relay
				ControlPumps.pumpDelay = ClockRAM.config.t82;
#ifdef _AUTOMAT_OUTPUT_UART
				if(log_debug)
				{
					Println(&huart1, "\nNASOS_1_OFF");
				}
#endif
			}
			if(ClockRAM.config.dc & PUMP_2_MASK)
			{
				Relays(RELAY_PUMP2, 1);	// on relay
				ControlPumps.cntTimeDiff = ClockRAM.config.t83+ClockRAM.config.t54+2;
#ifdef _AUTOMAT_OUTPUT_UART
				if(log_debug)
				{
					Println(&huart1, "\nNASOS_2_ON");
				}
#endif
			}
			else
			{
				Relays(RELAY_PUMP2, 0);	// off relay
				ControlPumps.pumpDelay = ClockRAM.config.t82;
#ifdef _AUTOMAT_OUTPUT_UART
				if(log_debug)
				{
					Println(&huart1, "\nNASOS_2_OFF");
				}
#endif
			}
		}
	}
	if((BIT_TEST(ClockRAM.config.dc, 3) == 0) && (BIT_TEST(ClockRAM.config.dc, 4) == 0))
	{
		ClockRAM.config.srn = 2;	// 0x02 - off all pump
	}
#ifdef _AUTOMAT_OUTPUT_UART
	if(log_debug)
	{
		if(bu_state_old != ClockRAM.config.state_BU103)
		{
			Println(&huart1, "\nstate_BU103: ");
			itoa(ClockRAM.config.state_BU103, buff, 10);
			Println(&huart1, buff);
			bu_state_old = ClockRAM.config.state_BU103;
			if(BIT_TEST(ClockRAM.config.rrk, 0))	Println(&huart1, ", automatic pump mode");
			else									Println(&huart1, ", manual pump mode");
		}
	}
#endif
}

void WaitingMode(void)
{ // go to waiting mode, off state
	BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
	BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
	timeoutAutomat = 0;
	ControlPumps.pumpDelay = 0;
}

uint8_t BitCalc(uint16_t val)
{
	uint8_t nBits, ci;

	nBits = 0;
	for(ci=DISPLAY_AVARY_MIN; ci<DISPLAY_AVARY_MAX; ci++)
	{
		if(BIT_TEST(val, ci))	nBits++;
	}

	return nBits;
}

void ZoloDel(void)
{
	if (Room.shnekCntr == ZOLO_RUN)
	{ // shnek ON
		if(Room.shnekTimeOff)		Room.shnekTimeOff--;
		if(Room.shnekTimeOn)		Room.shnekTimeOn--;
		switch(Room.zoloState)
		{
			default:
			case ZOLO_WAIT:
				BIT_CLR(relayData, RELAY_SHNEK);
				if(Room.working != SetCntWork())
				{
					Room.working = SetCntWork();
	#ifdef _AUTOMAT_OUTPUT_UART
					if(log_debug)
					{
						itoa(Room.working, buff, 10);
						Println(&huart1, "\nworking units: ");
						Println(&huart1, buff);
					}
	#endif
				}
				if(Room.working > 0)
				{
					Room.shnekTimeOff = ClockRAM.config.t33 / Room.working;
					Room.zoloState = ZOLO_WAIT_DLY_OFF;
				}
				break;

			case ZOLO_WAIT_DLY_OFF:
				if(Room.shnekTimeOff == 0)
				{
					Room.shnekTimeOn = ClockRAM.config.t34;
					BIT_SET(relayData, RELAY_SHNEK);
					Room.zoloState = ZOLO_WAIT_DLY_ON;
				}
				break;

			case ZOLO_WAIT_DLY_ON:
				if(Room.shnekTimeOn == 0)	Room.zoloState = ZOLO_WAIT;
				break;
		}
	}
	else
	{ // shnek OFF
		BIT_CLR(relayData, RELAY_SHNEK);
		Room.zoloState = ZOLO_WAIT;
	}
}

void PogodaTemp(void)
{
	int16_t Nkriva, Melement;

	if(BIT_TEST(ClockRAM.config.cfg, 1) == 0)
	{ // reg_pogoda_off
		ustPodachi = (int16_t)ClockRAM.config.T31;
		return;
	}
	if(BIT_TEST(ClockRAM.config.wrn, 1) ||
	   BIT_TEST(ClockRAM.config.wrn, 2))
	{ // error T_out
		ustPodachi = (int16_t)ClockRAM.config.T31;
	}
	else
	{
		Melement = (T_out + 30);
		Melement += (int16_t)ClockRAM.config.T35;
		if(Melement < 0)	Melement = 0;
		if(Melement > 50)	Melement = 50;
		Nkriva = ClockRAM.config.N34;
		if(Nkriva < 2)		Nkriva = 2;
		if(Nkriva > 50)		Nkriva = 50;
		ustPodachi = pogoda_array[Nkriva][Melement];
//		if(ustPodachi > (int16_t)ClockRAM.config.T41)	ustPodachi = (int16_t)ClockRAM.config.T41;
		if(ustPodachi > (int16_t)T_PODACHI_MAX)			ustPodachi = (int16_t)T_PODACHI_MAX;
		if(ustPodachi < (int16_t)ClockRAM.config.T36)	ustPodachi = (int16_t)ClockRAM.config.T36;
	}
#ifdef _AUTOMAT_OUTPUT_UART
	if(log_debug)
	{
		if(ustPodachi_old != ustPodachi)
		{
			Println(&huart1, "\npogoda temp T32: ");
			itoa(ustPodachi, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, "(C); T_out: ");
			itoa(T_out, buff, 10);
			Println(&huart1, buff);
			ustPodachi_old = ustPodachi;
			Println(&huart1, ", N kryva: ");
			itoa(ClockRAM.config.N34, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", T corr: ");
			itoa((int16_t)ClockRAM.config.T35, buff, 10);
			Println(&huart1, buff);
		}
	}
#endif
}

char* ToDisplay(int16_t val)
{
	char str[8];

	memset(str, 0, sizeof(str));
	itoa(val, str, 10);
	if(val < 0)
	{
		if(strlen(str) == 2)
		{
			buff[2] = str[1];
			buff[1] = '0';
			buff[0] = '-';
		}
		if(strlen(str) == 3)
		{
			buff[2] = str[2];
			buff[1] = str[1];
			buff[0] = '-';
		}
		if(strlen(str) > 3)
		{
			buff[2] = ' ';
			buff[1] = ' ';
			buff[0] = ' ';
		}
	}
	else
	{
		if(strlen(str) == 1)
		{
			buff[2] = str[0];
			buff[1] = '0';
			buff[0] = '0';
		}
		if(strlen(str) == 2)
		{
			buff[2] = str[1];
			buff[1] = str[0];
			buff[0] = '0';
		}
		if(strlen(str) > 2)
		{
			buff[2] = str[2];
			buff[1] = str[1];
			buff[0] = str[0];
		}
	}
	return buff;
}

void LoadSettings(void)
{
	PogodaTemp();
	Room.State = ClockRAM.config.RoomState;
	DIO = 0;
	tempDIO = 0;
}

void SaveSettings(void)
{

}

void RoomOff(void)
{
	if(Room.State == ROOM_WAIT)		return;
	if(Room.State < ROOM_OFF)
	{
		if(ClockRAM.config.lsa)		Room.State = ROOM_OFF;		// off all RegKaskad();
		else						Room.State = ROOM_WAIT;
	}
}

void IndexingRegisters(void)
{
	ptr_reg[1] = &DIO;						// RAM
	ptr_reg[2] = &ALR;						// RAM, ALR = ClockRAM.config.alr | ClockRAM.config.alrMemory;
	ptr_reg[3] = &ClockRAM.config.wrn;						// 4, 5
	ptr_reg[4] = &ClockRAM.config.srk;						// 6, 7
	ptr_reg[5] = &ClockRAM.config.sro;						// 10, 11
	ptr_reg[6] = &ClockRAM.config.srn;						// 14, 15
	ptr_reg[7] = &ClockRAM.config.rrk;						// 16, 17 1-auto; 0-manual;
	ptr_reg[8] = &ClockRAM.config.dc;						// 18, 19
	ptr_reg[9] = &ClockRAM.config.cfg;						// 20, 21
	ptr_reg[10] = &ClockRAM.config.lsa;						// 22, 23
	ptr_reg[11] = &ClockRAM.config.lsb;						// 24, 25
	ptr_reg[12] = &ClockRAM.config.tdi;						// 26, 27
	ptr_reg[13] = &T1;						// RAM
	ptr_reg[14] = &T2;						// RAM
	ptr_reg[15] = &T3;						// RAM
	ptr_reg[16] = &T4;						// RAM
	ptr_reg[17] = &ClockRAM.config.T31;						// 28, 29
	ptr_reg[18] = &ustPodachi;				// RAM			//
	ptr_reg[19] = &ClockRAM.config.t33;						// 30, 31
	ptr_reg[20] = &ClockRAM.config.t34;						// 32, 33
	ptr_reg[21] = &ClockRAM.config.N34;						// 34, 35 kurva
	ptr_reg[22] = &ClockRAM.config.T35;						// 36, 37  +/- deltaT in room -10...+10
	ptr_reg[23] = &ClockRAM.config.t37;						// 38, 39
	ptr_reg[24] = &ClockRAM.config.t38;						// 40, 41
	ptr_reg[25] = &ClockRAM.config.T41;						// 42_43 +80(C)
	ptr_reg[26] = &ClockRAM.config.T42;						// 44_45 +95(C)
	ptr_reg[27] = &ClockRAM.config.T43;						// 46_47 open 2800 mV
	ptr_reg[28] = &ClockRAM.config.T44;						// 48_49 short 1000 mV
	ptr_reg[29] = &ClockRAM.config.T45;						// 50_51 open 2800 mV
	ptr_reg[30] = &ClockRAM.config.T46;						// 52_53 short 1000 mV
	ptr_reg[31] = &ClockRAM.config.T47;						// 54_55 +5(C)
	ptr_reg[32] = &ClockRAM.config.delta_T41;				// 56_57
	ptr_reg[33] = &ClockRAM.config.delta_T42;				// 58_59
	ptr_reg[34] = &ClockRAM.config.delta_T47;				// 60_61
	ptr_reg[35] = &ClockRAM.config.t54;						// 62, 63
	ptr_reg[36] = &ClockRAM.config.t63;						// 64, 65
	ptr_reg[37] = &ClockRAM.config.t71;						// 68, 69
	ptr_reg[38] = &ClockRAM.config.t72;						// 70, 71
	ptr_reg[39] = &ClockRAM.config.N73;						// 72, 73
	ptr_reg[40] = &ClockRAM.config.t81;						// 76, 77
	ptr_reg[41] = &ClockRAM.config.t82;						// 78, 79
	ptr_reg[42] = &ClockRAM.config.t83;						// 80, 81
	ptr_reg[43] = &ClockRAM.config.t11;						// 82, 83
	ptr_reg[44] = &ClockRAM.config.AM;						// 84, 85, address BU103
	ptr_reg[45] = &ClockRAM.config.version;					// 74, 75
	ptr_reg[46] = &ClockRAM.config.serverHi;					//
	ptr_reg[47] = &ClockRAM.config.serverLow;					//
	ptr_reg[48] = &ClockRAM.config.ipPort;					//
	ptr_reg[49] = &ClockRAM.config.ipHi;				//
	ptr_reg[50] = &ClockRAM.config.ipLow;				//
	ptr_reg[51] = &ClockRAM.config.maskHi;				//
	ptr_reg[52] = &ClockRAM.config.maskLow;				//
	ptr_reg[53] = &ClockRAM.config.gwHi;				//
	ptr_reg[54] = &ClockRAM.config.gwLow;				//
	ptr_reg[55] = &ClockRAM.config.mac2_3;				//
	ptr_reg[56] = &ClockRAM.config.mac4_5;				//
	ptr_reg[57] = &ClockRAM.config.T36;					//
	ptr_reg[58] = &ClockRAM.config.null;				// loop
	ptr_reg[59] = &ClockRAM.config.null;				// loop

//	ptr_reg[55] = &ClockRAM.config.RoomState;				// 86, 87
}




