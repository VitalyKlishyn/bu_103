/*
 * kaskad.c
 *  Created on: 9 мая 2023 г.
 *      Author: vitaly
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "secure.h"
#include "bu_103_bus.h"
#include "automat.h"
#include "net.h"
#include "kaskad.h"
#include "table.h"

void RegKaskad(void)
{
	uint16_t	mask;

	mask = BA_AVARY_MASK_SCS_0; // scenary 0
	if(BIT_TEST(ClockRAM.config.cfg, 3))		mask = BA_AVARY_MASK_SCS_1;	 // scenary 1
	if(Room.oldState != Room.State)
	{
		Room.oldState = Room.State;
		ClockRAM.config.RoomState = Room.State;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			PrintTick();
			Println(&huart1, "\nRoom.State: ");
			switch(Room.State)
			{
				default:
				case ROOM_WAIT:
				Println(&huart1, "ROOM_WAIT");
				break;

				case ROOM_START:
				Println(&huart1, "ROOM_START");
				break;

				case ROOM_START+1:
				Println(&huart1, "ROOM_START+1");
				break;

				case ROOM_SET_T:
				Println(&huart1, "ROOM_SET_T");
				break;

				case ROOM_SET_DLY:
				Println(&huart1, "ROOM_SET_DLY");
				break;

				case ROOM_STABLE:
				Println(&huart1, "ROOM_STABLE");
				break;

				case ROOM_STABLE+1:
				Println(&huart1, "ROOM_STABLE+1");
				break;

				case ROOM_STABLE+2:
				Println(&huart1, "ROOM_STABLE+2");
				break;

				case ROOM_INC_UNIT:
				Println(&huart1, "ROOM_INC_UNIT");
				break;

				case ROOM_INC_UNIT+1:
				Println(&huart1, "ROOM_INC_UNIT+1");
				break;

				case ROOM_INC_UNIT+2:
				Println(&huart1, "ROOM_INC_UNIT+2");
				break;

				case ROOM_INC_UNIT+3:
				Println(&huart1, "ROOM_INC_UNIT+3");
				break;

				case ROOM_DEC_UNIT:
				Println(&huart1, "ROOM_DEC_UNIT");
				break;

				case ROOM_DEC_UNIT+1:
				Println(&huart1, "ROOM_DEC_UNIT+1");
				break;

				case ROOM_DEC_UNIT+2:
				Println(&huart1, "ROOM_DEC_UNIT+2");
				break;

				case ROOM_DEC_UNIT+3:
				Println(&huart1, "ROOM_DEC_UNIT+3");
				break;

				case ROOM_DEC_UNIT+4:
				Println(&huart1, "ROOM_DEC_UNIT+4");
				break;

				case ROOM_DEC_UNIT+5:
				Println(&huart1, "ROOM_DEC_UNIT+5");
				break;

				case ROOM_OFF:
				Println(&huart1, "ROOM_OFF");
				break;

				case ROOM_OFF+1:
				Println(&huart1, "ROOM_OFF+1");
				break;

				case ROOM_OFF+2:
				Println(&huart1, "ROOM_OFF+2");
				break;

				case ROOM_OFF+3:
				Println(&huart1, "ROOM_OFF+3");
				break;
			}
		}
#endif
	}

#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			if((CurrUnit != Room.CurrUnit) && (BIT_TEST(ClockRAM.config.cfg, 2)))
			{
				CurrUnit = Room.CurrUnit;
				Println(&huart1, "\nCurrUnit: ");
				itoa(Room.CurrUnit, buff, 10);
				Println(&huart1, buff);
				Println(&huart1, "; addr: ");
				itoa(Room.kaskad[Room.CurrUnit], buff, 10);
				Println(&huart1, buff);
			}
		}
#endif
	switch(Room.State)
	{
		case ROOM_START:	// 1
		if(BIT_TEST(ClockRAM.config.cfg, 2))
		{ // kaskad on
			if((T_hot < ustPodachi) && ((ClockRAM.config.alr & mask) == 0) && ((ClockRAM.config.alrMemory & mask) == 0))
			{ // on unit
				if(Req.state == REQ_UNIT_WAIT)
				{
					Room.CurrUnit = 0;
					if(TestModeUnit(Room.kaskad[Room.CurrUnit]) == Room.kaskad[Room.CurrUnit])
					{ // test remote mode & good link
						UnitOn(Room.kaskad[Room.CurrUnit]);
						Room.State = ROOM_START+1;
					}
					else
					{

					}
				}
			}
		}
		else
		{ // kaskad off
			if(Req.state == REQ_UNIT_WAIT)
			{
				if(ustPodachi != (SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_TUST]))
				{ // set temperature
					SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_TUST] = ustPodachi;
					Room.State = ROOM_SET_T;
				}
				else
				{
					CurrUnitInc();	// increment unit
				}
			}
		}
		break;

		case ROOM_START+1:	// 2  // for kaskad on only
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_SET_T;
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.timeCounter = 0;
			Room.State = ROOM_START;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nUnit ");
				itoa(Room.kaskad[Room.CurrUnit], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, " is off");
			}
#endif
		}
		break;

		case ROOM_SET_T:	// 3
		if(Req.state == REQ_UNIT_WAIT)
		{ // set temperature in unit
			if((TestModeUnit(Room.kaskad[Room.CurrUnit])) == Room.kaskad[Room.CurrUnit])
			{ // unit online and remote control
				UnitSetT(Room.kaskad[Room.CurrUnit]);
				Room.State = ROOM_SET_DLY;
			}
			else
			{
				if((Req.ok) || (Room.timeCounter < 2))
				{
					Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
					CurrUnitInc();	// increment unit
					Room.State = ROOM_START;
				}
			}
		}
		break;

		case ROOM_SET_DLY:	// 4
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			if(BIT_TEST(ClockRAM.config.cfg, 2))
			{ // kaskad on
				Room.State = ROOM_STABLE;
			}
			else
			{
				Room.State = ROOM_START;
			}
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_START;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nUnit ");
				itoa(Room.kaskad[Room.CurrUnit], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, " fail set temperature");
			}
#endif
		}
		break;

		case ROOM_STABLE:	// 5
		if(ustPodachi != (SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_TUST]))
		{ // set temperature
			SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_TUST] = ustPodachi;
			Room.State = ROOM_SET_T;
		}
		else
		{ // ustPodachi == tmpReg
			if(((SelUnit(Room.kaskad[Room.CurrUnit])->oldQmax) == 0) && ((SelUnit(Room.kaskad[Room.CurrUnit])->oldQmin) == 0))
			{
				SelUnit(Room.kaskad[Room.CurrUnit])->oldQcurr = SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_ZF];
				SelUnit(Room.kaskad[Room.CurrUnit])->oldQmax = SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_Q_MAX];
				SelUnit(Room.kaskad[Room.CurrUnit])->oldQmin = SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_Q_MIN];
				return;		// wait for reading data unit
			}
			if((SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_SRK] & SRK_WORK_ONLY) != SRK_WORK_ONLY)	return; // wait work mode unit
			if((SelUnit(Room.kaskad[Room.CurrUnit])->oldQcurr) >= (SelUnit(Room.kaskad[Room.CurrUnit])->oldQmax))
			{
				if(ustPodachi > (SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_DT1]))
				{
					if(Room.timeCounter <= 1)	Room.timeCounter = ClockRAM.config.t37*60;	// start timeout
					Room.State = ROOM_STABLE+1;	//  for increment
				}
			}
			if((SelUnit(Room.kaskad[Room.CurrUnit])->oldQcurr) <= (SelUnit(Room.kaskad[Room.CurrUnit])->oldQmin))
			{
				if(ustPodachi < (SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_DT1]))
				{
					if(Room.timeCounter <= 1)	Room.timeCounter = ClockRAM.config.t37*60;	// start timeout
					Room.State = ROOM_STABLE+2;	//  for decrement
				}
			}
		}
		break;

		case ROOM_STABLE+1:	// 6, timeout for increment
		if(ustPodachi != (SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_TUST]))
		{ // set temperature
			Room.State = ROOM_STABLE;
		}
		if((SelUnit(Room.kaskad[Room.CurrUnit])->oldQcurr) < (SelUnit(Room.kaskad[Room.CurrUnit])->oldQmax))
		{
			Room.State = ROOM_STABLE;
		}
		else
		{
			if(Room.timeCounter == 1)
			{ // currQ == maxQ, maximal power unit
				Room.timeCounter = ClockRAM.config.t37*60;	// start timeout
				if(T_hot < (ustPodachi - DELTA_T))
				{ // test next unit for increment
					if(TestModeUnit(Room.kaskad[Room.CurrUnit+1]) != 0)	// testing next unit
					{
						Room.State = ROOM_INC_UNIT;
					}
					else
					{
						Room.State = ROOM_STABLE;
#ifdef _AUTOMAT_OUTPUT_UART
						if(log_debug)
						{
							Println(&huart1, "\nnot available unit for INC");
						}
#endif
					}
				}
			}
		}
		break;

		case ROOM_STABLE+2:	// 7, timeout for decrement
		if(ustPodachi != (SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_TUST]))
		{ // set temperature
			Room.State = ROOM_STABLE;
		}
		if((SelUnit(Room.kaskad[Room.CurrUnit])->oldQcurr) > (SelUnit(Room.kaskad[Room.CurrUnit])->oldQmin))
		{
			Room.State = ROOM_STABLE;
		}
		else
		{
			if(Room.timeCounter == 1)
			{ // currQ == minQ, minimal power unit
				Room.timeCounter = ClockRAM.config.t37*60;	// start timeout
				if(T_hot > (ustPodachi + DELTA_T))
				{
					if(Room.CurrUnit != 0)
					{
						Room.State = ROOM_DEC_UNIT;
					}
					else
					{
						Room.State = ROOM_OFF;
#ifdef _AUTOMAT_OUTPUT_UART
						if(log_debug)
						{
							Println(&huart1, "\noff all units...");
						}
#endif
					}
				}
			}
		}
		break;

		case ROOM_INC_UNIT:		// 8
		if(Req.state == REQ_UNIT_WAIT)
		{
			UnitPconst(Room.kaskad[Room.CurrUnit]);
			Room.State = ROOM_INC_UNIT+1;
		}
		break;

		case ROOM_INC_UNIT+1:	// 9
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Req.timeUnit = ClockRAM.config.t38;	// set timer for change
			Room.CurrUnit = ChangeUnit(DIR_UP);	// change unit
			Room.State = ROOM_INC_UNIT+2;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nset Unit ");
				itoa(Room.kaskad[Room.CurrUnit], buff, 10);
				Println(&huart1, buff);
			}
#endif
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.timeCounter = ClockRAM.config.t37*60;
			Room.State = ROOM_INC_UNIT;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nUnit ");
				itoa(Room.kaskad[Room.CurrUnit], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, " fail inc");
			}
#endif
		}
		break;

		case ROOM_INC_UNIT+2:	// 10
		if(Req.state == REQ_UNIT_WAIT)
		{
			UnitOn(Room.kaskad[Room.CurrUnit]);
			Room.State = ROOM_INC_UNIT+3;
		}
		break;

		case ROOM_INC_UNIT+3:	// 11
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.timeCounter = ClockRAM.config.t37*60;
			Room.State = ROOM_STABLE;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nsuccess inc unit");
			}
#endif
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_INC_UNIT+2;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nUnit ");
				itoa(Room.kaskad[Room.CurrUnit], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, " inc next unit");
			}
#endif
		}
		break;

		case ROOM_DEC_UNIT:		// 12
		if(Req.state == REQ_UNIT_WAIT)
		{
			UnitOff(Room.kaskad[Room.CurrUnit]);
			Room.State = ROOM_DEC_UNIT+1;
		}
		break;

		case ROOM_DEC_UNIT+1:	// 13
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Req.timeUnit = ClockRAM.config.t38;	// set timer for change
			Room.CurrUnit = ChangeUnit(DIR_DN);	// change unit down
			Room.State = ROOM_DEC_UNIT+2;
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_DEC_UNIT;
		}
		break;

		case ROOM_DEC_UNIT+2:	// 14
		if(Req.state == REQ_UNIT_WAIT)
		{
			UnitOn(Room.kaskad[Room.CurrUnit]);
			Room.State = ROOM_DEC_UNIT+3;
		}
		break;

		case ROOM_DEC_UNIT+3:	// 15
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_DEC_UNIT+4;
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_DEC_UNIT+2;
#ifdef _AUTOMAT_OUTPUT_UART
				if(log_debug)
				{
					Println(&huart1, "\nUnit ");
					itoa(Room.CurrUnit, buff, 10);
					Println(&huart1, buff);
					Println(&huart1, " no answer");
				}
#endif
		}
		break;

		case ROOM_DEC_UNIT+4:	// 16
		tmpReg = SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_RC];
		if(tmpReg & ROOM_ON_MASK)
		{
			if(Req.state == REQ_UNIT_WAIT)
			{
				UnitSetT(Room.kaskad[Room.CurrUnit]);
				Room.State = ROOM_DEC_UNIT+5;
			}
		}
		else
		{
			Room.State = ROOM_DEC_UNIT+2;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nUnit ");
				itoa(Room.CurrUnit, buff, 10);
				Println(&huart1, buff);
				Println(&huart1, " not on mask");
			}
#endif
		}
		break;

		case ROOM_DEC_UNIT+5:	// 17
		tmpReg = SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_TUST];
		if(Req.ok == 1) // (tmpReg == ustPodachi)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.timeCounter = ClockRAM.config.t37*60;
			Room.State = ROOM_STABLE;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nsuccess dec unit");
			}
#endif
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_DEC_UNIT+3;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nUnit ");
				itoa(Room.kaskad[Room.CurrUnit], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, ", dec, fail set temperature");
			}
#endif
		}
		break;

		case ROOM_OFF:	// 18
		Room.CurrUnit = 0;
		Room.indUnit = 0;
		if(ClockRAM.config.lsa)
		{ // if using units
			Room.State = ROOM_OFF+1;
			Req.failCnt = 0;		// timeout 5 sec. start
		}
		else			Room.State = ROOM_WAIT;
		break;

		case ROOM_OFF+1:	// 19
		if((Room.kaskad[Room.indUnit] != 0) && (TestModeUnit(Room.kaskad[Room.indUnit]) == Room.kaskad[Room.indUnit]))
		{ // off only "remote mode" units
			if(((SelUnit(Room.kaskad[Room.indUnit])->ba[ADDR_POINT_SRK]) == SRK_OFF_MASK) || (((SelUnit(Room.kaskad[Room.indUnit])->ba[ADDR_POINT_RC]) & RC_AUTO_FLAME) == 0))
			{
				Room.State = ROOM_OFF+3;
			}
			else
			{
				if(Req.state == REQ_UNIT_WAIT)
				{
					UnitOff(Room.kaskad[Room.indUnit]);
					Room.State = ROOM_OFF+2;
				}
			}
		}
		break;

		case ROOM_OFF+2:	// 20
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_OFF+3;
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			Room.State = ROOM_OFF+3;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nfail off Unit[");
				itoa(Room.indUnit+1, buff, 10);
				Println(&huart1, buff);
				Println(&huart1, "]");
			}
#endif
		}
		else
		{
			Req.failCnt++;
			if(Req.failCnt > REQUEST_FAIL_CNT)
			{
				Req.failCnt = 0;
				Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
				Room.State = ROOM_OFF+3;
#ifdef _AUTOMAT_OUTPUT_UART
				if(log_debug)
				{
					Println(&huart1, "\ntimeout off Unit[");
					itoa(Room.indUnit+1, buff, 10);
					Println(&huart1, buff);
					Println(&huart1, "]");
				}
#endif
			}
		}
		break;

		case ROOM_OFF+3:  // 21
		Room.indUnit++;
		if(Room.indUnit >= Room.AllUnits)
		{
			Room.State = ROOM_WAIT;
		}
		else
		{
			Room.State = ROOM_OFF+1;
		}
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nRoom.indUnit:");
			itoa(Room.indUnit, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", Room.AllUnits:");
			itoa(Room.AllUnits, buff, 10);
			Println(&huart1, buff);
		}
#endif
		break;

		case ROOM_WAIT:
		default:
		if((BIT_TEST(ClockRAM.config.dc, 0)) && ((ClockRAM.config.alr & mask) == 0) && ((ClockRAM.config.alrMemory & mask) == 0))
		{ // room is on
			Room.State = ROOM_START;
		}
		break;
	}
}

uint8_t ChangeUnit(uint8_t dir)
{
	Req.tcnt++;
	if(Req.tcnt > 3600)
	{
		Req.timeUnit++;
		Req.tcnt = 0;
	}
	if(Req.timeUnit >= ClockRAM.config.t38)
	{
		Req.timeUnit = 0;
	}
	switch(dir)
	{
		case DIR_UP:
		default:
		Room.CurrUnit++;
		if(Room.CurrUnit > Room.kaskadUnits)	Room.CurrUnit = Room.kaskadUnits;
		break;

		case DIR_DN:
		if(Room.CurrUnit)		Room.CurrUnit--;
		break;
	}
	return Room.CurrUnit;
}

void CurrUnitInc(void)
{
	Room.CurrUnit++;
	if(Room.CurrUnit >= Room.AllUnits)	Room.CurrUnit = 0;
}

uint8_t TestModeUnit(uint8_t addr)
{ // if test good (mode-remote & unit-online) -> return address, else return 0;
	if(((SelUnit(addr)->ba[ADDR_POINT_RR]) && RR_REMOTE_MASK) && (!(BIT_TEST(ClockRAM.config.lsb, ((SelUnit(addr)->ba[ADDR_POINT_BA])-1)))))
	{ // test remote mode & good link
		return addr;
	}
	else
	{
		return 0;
	}
}

void UnitOn(uint8_t addr)
{
	uint16_t val;

	val = (SelUnit(addr)->ba[ADDR_POINT_RC]) & RC_MASK;
//	BIT_SET(val, 0);	// clear avary
	BIT_SET(val, BIT_ON_OFF);
	BIT_CLR(val, BIT_PCONST_NOM);
	BIT_CLR(val, BIT_PCONST_MIN);
	Req.addr = addr;
	Req.cmd = WRITE_ONE_REG;	// cmd write
	Req.reg = ADDR_POINT_RC;	// addr write
	Req.len = val;	// data to write
	Req.state = REQ_UNIT_SEND;
}

void UnitSetT(uint8_t addr)
{
	Req.addr = addr;
	Req.cmd = WRITE_ONE_REG;
	Req.reg = ADDR_POINT_TUST;
	Req.len = ustPodachi;
	Req.state = REQ_UNIT_SEND;
}

void UnitPconst(uint8_t addr)
{
	uint16_t val;

	val = (SelUnit(addr)->ba[ADDR_POINT_RC]) & RC_MASK;
	BIT_SET(val, BIT_ON_OFF);
	BIT_SET(val, BIT_PCONST_NOM);
	BIT_CLR(val, BIT_PCONST_MIN);
	Req.addr = addr;
	Req.cmd = WRITE_ONE_REG;
	Req.reg = ADDR_POINT_RC;
	Req.len = val;
	Req.state = REQ_UNIT_SEND;
}

void UnitOff(uint8_t addr)
{
	uint16_t val;

	val = (SelUnit(addr)->ba[ADDR_POINT_RC]) & RC_MASK;
	if((val & RC_AUTO_FLAME) == RC_AUTO_FLAME)
	{ // off unit
		BIT_CLR(val, BIT_ON_OFF);
		BIT_CLR(val, BIT_PCONST_NOM);
		BIT_CLR(val, BIT_PCONST_MIN);
		Req.addr = addr;
		Req.cmd = WRITE_ONE_REG;
		Req.reg = ADDR_POINT_RC;
		Req.len = val;
		Req.state = REQ_UNIT_SEND;
	}
	else
	{ // set low power mode
	/*
		BIT_SET(val, BIT_PCONST_MIN);
		BIT_CLR(val, BIT_PCONST_NOM);
		Req.addr = addr;
		Req.cmd = WRITE_ONE_REG;
		Req.reg = ADDR_POINT_RC;
		Req.len = val;
		Req.state = REQ_UNIT_SEND;
	*/
	}
}

thermo_unit_t* SelUnit(uint8_t unit)
{ // select object from address
	if(unit == 1)			return &Unit1;
	else if(unit == 2)		return &Unit2;
	else if(unit == 3)		return &Unit3;
	else if(unit == 4)		return &Unit4;
	else if(unit == 5)		return &Unit5;
	else if(unit == 6)		return &Unit6;
	else if(unit == 7)		return &Unit7;
	else if(unit == 8)		return &Unit8;
	else if(unit == 9)		return &Unit9;
	else if(unit == 10)		return &Unit10;
	else 					return NULL;
}

void ReWriteArray(uint8_t *arr, uint8_t pos)
{ // change order of units, pos shift to end array
	uint8_t pi;

	for(pi=0; pi<MAX_COUNT_UNITS+1; pi++)	// pi<MAX_COUNT_UNITS+1
	{
		if(arr[pi] == 0)
		{
			arr[pi] = arr[pos];
			break;
		}
	}
	pi = pos;
	while(arr[pi+1])
	{
		arr[pi] = arr[pi+1];
		pi++;
	}
	arr[pi] = 0;
}

void ReadUnitReg(void)
{ // before read/write set structure Req, to run -> Req.state = REQ_UNIT_SEND;
//	uint8_t ci;

	switch(Req.state)
	{
		case REQ_UNIT_SEND:		// 1
//		Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
		UART_3.ok = 0;
		if((Req.addr > 0) && (Req.addr < 11))
		{
			SendCMDtoBA(Req.addr, Req.cmd, Req.reg, Req.len);
			Req.timeout = SMBUS_TIMEOUT;
			Req.state =	REQ_UNIT_READ;
		}
		else
		{
			Req.state = REQ_UNIT_WAIT;
		}
		break;

		case REQ_UNIT_READ:		// 2
		switch(UART_3.ok)
		{
			default:
			if(Req.timeout == 1)
			{
#ifdef _AUTOMAT_OUTPUT_UART
				if(log_debug)
				{
					Println(&huart1, ".");
				}
#endif
				ClearMemUnit(SelUnit(Req.addr));
				Req.timeout = 0;
				Req.ok = 3;		//  3-timeout
				Req.state =	REQ_TIMEOUT_READ;
			}
			break;

			case 1:		// 1-ok
			Req.timeout = 0;
			Req.ok = 1;
			Req.pause = REQUEST_PAUSE;
			Req.state = REQ_UNIT_PAUSE;
			break;

			case 2:		// 2-fail
			Req.timeout = 0;
			Req.ok = 2;
			Req.pause = REQUEST_PAUSE;
			Req.state =	REQ_UNIT_PAUSE;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nanswer fail");
			}
#endif
			break;
		}
		break;

		case REQ_UNIT_PAUSE:	// 3
		if(Req.pause)			Req.pause--;
		if(Req.pause == 1)
		{
			Req.pause = 0;
			Req.state =	REQ_TIMEOUT_READ;
		}
		break;

		case REQ_TIMEOUT_READ:	// 4
		Req.timeout = READ_TIMEOUT;
		Req.state =	REQ_WAIT_READ;
		break;

		case REQ_WAIT_READ:		// 5
		if(Req.timeout == 1)
		{ // error, not read answer
			Req.timeout = 0;
			Req.ok = 0;
			Req.state =	REQ_SET_STREAM;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				itoa(Req.addr, buff, 10);
				Println(&huart1, "\nerror timeout read, Unit ");
				Println(&huart1, buff);
			}
#endif
		}
		if(Req.ok == 0)
		{ // read ok
			Req.state =	REQ_SET_STREAM;
		}
		break;

		case REQ_SET_STREAM:	// 6
		if(scanState > INIT_UNIT_PRESEND)	Room.currStream++;
		else								Room.currStream = 0;
		if(Room.currStream > MAX_STREAM-1)	Room.currStream = 0;
		Room.stream = order_array[Room.currStream];
		Req.spaceCnt = 0;
		Req.state =	REQ_UNIT_WAIT;
		break;

		case REQ_UNIT_WAIT:		// 0
		default:
		Req.spaceCnt++;
		if(Req.spaceCnt > SPACE_CNT)	Req.state =	REQ_SET_STREAM;
		break;
	}
	if(Req.timeout)			Req.timeout--;
}

void UnitStream(void)
{
	switch(Room.stream)
	{
		default:
		case ORDER_SCAN_UNITS:
		ScanUnits();
		break;

		case ORDER_REG_KASKAD:
		RegKaskad();
		break;

		case ORDER_SEND_REQUEST:
		SendRequest();
		break;
	}
}

void ScanUnits(void)
{ // for scanning => scanState = SCAN_UNITS_START;
  // for read => scanState = INIT_UNIT_SEND;
	uint16_t val;

	switch(scanState)
	{
		case SCAN_UNITS_START:
		Room.State = ROOM_WAIT;
		Room.AllUnits = 0;
		Room.kaskadUnits = 0;
		memset(Room.addresses, 0, sizeof(Room.addresses)); // clear array address of units
		tstAddr = MIN_TEST_ADDR;
		scanState = SCAN_UNITS_SENDCMD;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nstart_scanning...");
		}
#endif
		break;

		case SCAN_UNITS_SENDCMD:
		if(Req.state == REQ_UNIT_WAIT)
		{
			Req.addr = tstAddr;
			Req.cmd = READ_IN_REG;
			Req.reg = ADDR_POINT_BA;
			Req.len = 1;
			Req.state = REQ_UNIT_SEND;
			scanState = SCAN_UNITS_READ;
		}
		break;

		case SCAN_UNITS_READ:
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			scanState = SCAN_UNITS_NEXT;
			val = tstAddr;
			Room.addresses[Room.AllUnits] = val;
			Room.AllUnits++;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nUnit online");
				Println(&huart1, ", address: 0x");
				itoa(val, buff, 16);
				Println(&huart1, buff);
			}
#endif
		}
		if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			scanState = SCAN_UNITS_NOTANSVER;
		}
		break;

		case SCAN_UNITS_NOTANSVER:
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\naddr: 0x");
				itoa(tstAddr, buff, 16);
				Println(&huart1, buff);
				Println(&huart1, " no answer");
			}
#endif
		scanState = SCAN_UNITS_NEXT;
		break;

		case SCAN_UNITS_NEXT:
		tstAddr++;
		if((tstAddr > MAX_TEST_ADDR) || (Room.AllUnits >= MAX_COUNT_UNITS))
		{
			scanState = SCAN_UNITS_STOP;
		}
		else		scanState = SCAN_UNITS_SENDCMD;
		break;

		case SCAN_UNITS_STOP:
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "\nend_scanning! cnt units: ");
				itoa(Room.AllUnits, buff, 10);
				Println(&huart1, buff);
				Println(&huart1, "\nRoom.State: ");
				itoa(Room.State, buff, 10);
				Println(&huart1, buff);
			}
#endif
		if(Room.AllUnits)
		{
			SetLSAregister();
			scanState = INIT_UNIT_PRESEND;
			switch(ClockRAM.config.RoomState)
			{
				case ROOM_STABLE:
				Room.State = ROOM_START;
				break;

				case ROOM_OFF:
				case ROOM_OFF+1:
				case ROOM_OFF+2:
				case ROOM_OFF+3:
				Room.State = ROOM_OFF;
				break;

				default:
				break;
			}
		}
		else
		{
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, ", Room.AllUnits = 0");
			}
#endif
			scanState =	SCAN_UNITS_WAIT;
		}
		break;

		case INIT_UNIT_PRESEND:
		memset(Room.kaskad, 0, sizeof(Room.kaskad)); // clear array kaskad
		memset(Room.addresses, 0, sizeof(Room.addresses)); // clear array address of units
		Room.readUnit = 0;
		Room.AllUnits = 0;
		Room.kaskadUnits = 0;
		for(Room.indUnit = 0; Room.indUnit < MAX_COUNT_UNITS; Room.indUnit++)	// Room.indUnit < MAX_COUNT_UNITS+1
		{
			if(BIT_TEST(ClockRAM.config.lsa, Room.indUnit))
			{
				Room.addresses[Room.AllUnits] = Room.indUnit+1;
				Room.kaskad[Room.AllUnits] = Room.indUnit+1;
				Room.AllUnits++;
			}
		}
		Room.kaskadUnits = Room.AllUnits;
		scanState = INIT_UNIT_SEND;
		break;

		case INIT_UNIT_SEND:
		if(Room.kaskad[Room.readUnit])
		{
			if(Req.state == REQ_UNIT_WAIT)
			{
				Req.addr = Room.kaskad[Room.readUnit];
				Req.cmd = READ_IN_REG;
				Req.reg = BEGIN_INIT_REG;
				Req.len = BEGIN_INIT_LEN;
				Req.state = REQ_UNIT_SEND;
				scanState =	INIT_UNIT_READ;
			}
		}
		else
		{
			scanState =	SCAN_UNITS_WAIT;
		}
		break;

		case INIT_UNIT_READ:
		if(Req.ok == 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			InitializeUnit(Room.kaskad[Room.readUnit]);
			if(Room.readUnit >= Room.kaskadUnits)
			{
				if(Room.kaskad[Room.kaskadUnits] != Room.kaskad[Room.readUnit])
				{
					change = Room.kaskad[Room.kaskadUnits];
					Room.kaskad[Room.kaskadUnits] = Room.kaskad[Room.readUnit];
					Room.kaskad[Room.readUnit] = change;
				}
				Room.kaskadUnits++;
			}
			if(TestModeUnit(Room.kaskad[Room.readUnit]))
			{
				Room.readUnit++;
				if(Room.kaskad[Room.readUnit] == 0)		Room.readUnit = 0;
				scanState = INIT_END_REQUEST;
			}
			else
			{
				scanState = INIT_UNIT_REWRITE;
			}
		}
		else if(Req.ok > 1)
		{
			Req.ok = 0;		// 0-send request, 1-ok, 2-fail, 3-timeout;
			scanState = INIT_UNIT_REWRITE;
		}
		break;

		case INIT_UNIT_REWRITE:
		if(Room.readUnit < Room.kaskadUnits)
		{
			ReWriteArray(Room.kaskad, Room.readUnit);
			if(Room.kaskadUnits)	Room.kaskadUnits--;
#ifdef _AUTOMAT_OUTPUT_UART
			if(log_debug)
			{
				Println(&huart1, "*");
			}
#endif
		}
		else
		{

		}
		Room.readUnit++;
		if(Room.kaskad[Room.readUnit] == 0)		Room.readUnit = 0;
		scanState = INIT_END_REQUEST;
		break;

		case INIT_END_REQUEST:
		scanState = INIT_UNIT_SEND;
		break;

		case SCAN_UNITS_WAIT:
		default:
		break;
	}
}

void SendRequest(void)
{
	if((Req.state == REQ_UNIT_WAIT) && (ReqCmd.state == REQ_UNIT_SEND))
	{
		Req.addr = ReqCmd.addr;
		Req.cmd = ReqCmd.cmd;		// cmd write
		Req.reg = ReqCmd.reg;		// addr write
		Req.len = ReqCmd.len;		// data to write
		Req.state = ReqCmd.state;	// REQ_UNIT_SEND;
		ReqCmd.state = REQ_UNIT_WAIT;
	}
}

uint8_t SetCntWork(void)
{ // count working units, SRK register, bits 2,3,4,5,6
	thermo_unit_t *unit;
	uint8_t ci, rez;

	rez = 0;
	for(ci=0; ci<Room.AllUnits; ci++)
	{
		unit = SelUnit(Room.addresses[ci]);
		if((unit->ba[ADDR_POINT_SRK]) & SRK_WORK_MASK)		rez++;
	}
	return rez;
}

///void InitializeUnit(thermo_unit_t *unit, uint8_t num)
void InitializeUnit(uint8_t addr)
{
//	uint8_t ci;
	thermo_unit_t *unit;

	if((addr > MAX_TEST_ADDR) || (addr < 1))
	{
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nincorrect address: ");
			itoa(addr, buff, 10);
			Println(&huart1, buff);
		}
#endif
		return;
	}
	unit = SelUnit(addr);
	if(((unit->ba[ADDR_POINT_BA]) < 1) || ((unit->ba[ADDR_POINT_BA]) > MAX_TEST_ADDR))
	{ // wait reading unit
		return;
	}
	BIT_CLR(ClockRAM.config.lsb, (addr-1));			// clear error connect
	unit->cntTestLine = ClockRAM.config.t11;		// reload counter for test line
	if(unit->oldALR != unit->ba[ADDR_POINT_ALR])
	{
		unit->oldALR = unit->ba[ADDR_POINT_ALR];
		if((unit->ba[ADDR_POINT_ALR]) != 0)
		{
			BIT_SET(ClockRAM.config.alr, 9);
		}
		else
		{
			if(BIT_TEST(ClockRAM.config.alr, 9))
			{
				BIT_SET(ClockRAM.config.alrMemory, 9);
				BIT_CLR(ClockRAM.config.alr, 9);
			}
		}
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", ALR: 0x");
			itoa(unit->ba[ADDR_POINT_ALR], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(unit->oldWRN != unit->ba[ADDR_POINT_WRN])
	{

		unit->oldWRN = unit->ba[ADDR_POINT_WRN];
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", WRN: 0x");
			itoa(unit->ba[ADDR_POINT_WRN], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(unit->oldSRK != unit->ba[ADDR_POINT_SRK])
	{
		unit->oldSRK = unit->ba[ADDR_POINT_SRK];
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", SRK: 0x");
			itoa(unit->ba[ADDR_POINT_SRK], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(unit->oldRR != unit->ba[ADDR_POINT_RR])
	{
		unit->oldRR = unit->ba[ADDR_POINT_RR];
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", RR: 0x");
			itoa(unit->ba[ADDR_POINT_RR], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(unit->oldRC != unit->ba[ADDR_POINT_RC])
	{
		unit->oldRC = unit->ba[ADDR_POINT_RC];
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", RC: 0x");
			itoa(unit->ba[ADDR_POINT_RC], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(unit->oldDT1 != unit->ba[ADDR_POINT_DT1])
	{
		unit->oldDT1 = unit->ba[ADDR_POINT_DT1];
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", DT1: 0x");
			itoa(unit->ba[ADDR_POINT_DT1], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(unit->oldTUST != unit->ba[ADDR_POINT_TUST])
	{
		unit->oldTUST = unit->ba[ADDR_POINT_TUST];
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", TUST: 0x");
			itoa(unit->ba[ADDR_POINT_TUST], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	if(unit->oldQcurr != unit->ba[ADDR_POINT_ZF])
	{
		unit->oldQcurr = unit->ba[ADDR_POINT_ZF];
		unit->oldQmax = unit->ba[ADDR_POINT_Q_MAX];
		unit->oldQmin = unit->ba[ADDR_POINT_Q_MIN];
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nUnit ");
			itoa(unit->ba[ADDR_POINT_BA], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, ", ZF: ");
			itoa(unit->ba[ADDR_POINT_ZF], buff, 10);
			Println(&huart1, buff);
			Println(&huart1, " %");
		}
#endif
	}
}

void TestUnits(void)
{
	Room.testUnit++;
	if(Room.testUnit > Room.AllUnits)		Room.testUnit = 0;
	if(SelUnit(Room.kaskad[Room.testUnit])->cntTestLine)		SelUnit(Room.kaskad[Room.testUnit])->cntTestLine--;
	if((SelUnit(Room.kaskad[Room.testUnit])->cntTestLine) == 1)
	{
		BIT_SET(ClockRAM.config.lsb, ((SelUnit(Room.kaskad[Room.testUnit])->ba[ADDR_POINT_BA])-1));
		SelUnit(Room.kaskad[Room.testUnit])->cntTestLine = 0;
	}
}

void ClearMemUnit(thermo_unit_t *unit)
{
	unit->ba[ADDR_POINT_RC] = 1;
	unit->ba[ADDR_POINT_WRN] = 0;
//	unit->cntTestLine = 0;
}

void ClearUnits(void)
{
	uint8_t	unit;

	for(unit=1; unit<=MAX_COUNT_UNITS; unit++)
	{
		ClearMemUnit(SelUnit(unit));
	}
}

void SetLSAregister(void)
{
	uint8_t li;

//	if(BIT_TEST(ClockRAM.config.cfg, 4))
//	{
		ClockRAM.config.lsa = 0;
		ClockRAM.config.lsb = 0;
		for(li=0; li<MAX_COUNT_UNITS; li++)
		{
			if(Room.addresses[li])
			{
				BIT_SET(ClockRAM.config.lsa, (Room.addresses[li]-1));
			}
		}
		BIT_CLR(ClockRAM.config.cfg, 4);		// clear flag init BAx procedure
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nset LSA: 0b");
			itoa(ClockRAM.config.lsa, buff, 2);
			Println(&huart1, buff);
		}
#endif
//	}
}


