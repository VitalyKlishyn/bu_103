/*
 * net.c
 *
 *  Created on: 22 мар. 2023 г.
 *      Author: vitaly
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "secure.h"
#include "bu_103_bus.h"
#include "automat.h"
#include "kaskad.h"
#include "socket.h"
#include "w5500.h"
#include "dhcp.h"
#include "net.h"
#include "table.h"

extern SPI_HandleTypeDef hspi1;
extern UART_HandleTypeDef huart1;
wiz_NetInfo gWIZNETINFO;
wiz_NetInfo getNETINFO;

void W5500_Server(socket_t* soc, modbus_t* mod)
{ // Modbus TCP, port 502
//	int32_t result, cnt;

	if(soc->tm_out)		soc->tm_out--;
	soc->state = getSn_SR(soc->num);
	if(soc->tm_out == 0)
	{
		soc->state = SOCKET_ERROR;
		soc->tm_out = SERVER_TIME_OUT;
	}
/*
	if((soc->state) != (soc->state_old))
	{
#ifdef _BUS_OUTPUT_UART

		if(log_debug)
		{
			Println(&huart1, "\nstate: 0x");
			itoa(soc->state, buff, 16);
			Println(&huart1, buff);
		}
#endif
		soc->state_old = soc->state;
	}
*/
	switch(soc->state)
	{
		case SOCKET_ERROR: // 0xF8
			W5500_Init();
			break;

		case SOCK_LISTEN: // 0x14
			soc->tm_out = SERVER_TIME_OUT;
			break;

		case SOCK_INIT: // 0x13
			if(listen(soc->num) != SOCK_OK)  soc->state = SOCK_CLOSED;
			break;

		case SOCK_CLOSE_WAIT: // 0x1C
		case SOCK_CLOSED: // 0x0
			SOCKET_Start(soc);
			soc->state = getSn_SR(soc->num);
			break;

		case SOCK_ESTABLISHED:
			soc->rx_size = getSn_RX_RSR(soc->num);
			break;

		case SOCK_FIN_WAIT:

			break;

		default:
			break;
	}
	if(soc->rx_size > 0)
	{
		soc->rx_size = getSn_RX_RSR(soc->num);
		if(recv(soc->num, soc->rx_buff, sizeof(soc->rx_buff)))
		{
			if(soc->rx_size > 10)	Parse(soc, mod);
			soc->rx_size = 0;
		}
		soc->tm_out = SERVER_TIME_OUT;
	}
}

void W5500_Client(socket_t* soc, uint8_t* buf)
{
	if(soc->tm_out)		soc->tm_out--;
	switch(soc->send_state)
	{
	case SEND_CLIENT_INIT:
		soc->state = socket(soc->num, soc->protokol, soc->port, soc->flag);
		soc->send_code = 0;
		if(soc->state == soc->num)
		{
			soc->send_state = SEND_CLIENT_CONNECT;
		}
		else
		{
			soc->send_code = 1;
			soc->send_state = SEND_CLIENT_RESULT;
		}
		break;

	case SEND_CLIENT_CONNECT:
		soc->state = connect(soc->num, ServerIP, soc->port);
		soc->tm_out = CONNECT_TIME_OUT;
		soc->send_state = SEND_CLIENT_CONNECT+1;
		break;

	case SEND_CLIENT_CONNECT+1:
		if(soc->state == SOCK_OK)
		{
			soc->send_state = SEND_CLIENT_DATA;
		}
		if(soc->tm_out == 0)
		{
			soc->send_code = 2;
			soc->send_state = SEND_CLIENT_RESULT;
		}
		break;

	case SEND_CLIENT_DATA:
		soc->state = send(soc->num, buf, strlen((char*)buf));
		if(soc->state > 0)
		{
			soc->tm_out = CLIENT_TIME_OUT;
			soc->send_state = SEND_CLIENT_RECV;
		}
		else
		{
			soc->send_code = 3;
			soc->send_state = SEND_CLIENT_RESULT;
		}
		break;

	case SEND_CLIENT_RECV:
		soc->rx_size = getSn_RX_RSR(soc->num);
		if(soc->rx_size > 0)
		{ // receiv data
			memset(soc->rx_buff, 0, sizeof(soc->rx_buff));
			if(soc->rx_size > DATA_BUF_SIZE)		soc->rx_size = DATA_BUF_SIZE;
			recv(soc->num, soc->rx_buff, soc->rx_size);
			soc->send_state = SEND_CLIENT_OK;
		}
		if(soc->tm_out == 0)
		{ // time out receiv
			soc->send_code = 4;
			soc->send_state = SEND_CLIENT_RESULT;
		}
		break;

	case SEND_CLIENT_OK:
		soc->send_code = 0;
		soc->send_state = SEND_CLIENT_RESULT;
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nanswer: ");
			Println(&huart1, (char*)soc->rx_buff);
		}
#endif
		break;

	case SEND_CLIENT_RESULT:
		disconnect(soc->num);
		close(soc->num);
		soc->send_state = SEND_CLIENT_WAIT;
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			switch(soc->send_code)
			{
			case 0: // client ok
				break;

			case 1:	// create socket error
				Println(&huart1, "\ncreate socket error");
				break;

			case 2: // create connect error
				Println(&huart1, "\ncreate connection error");
				break;

			case 3: // send client error
				Println(&huart1, "\nsend client error");
				break;

			case 4: // time out client
				Println(&huart1, "\ntime out client");
				break;

			default:
				break;
			}
		}
#endif
		break;

	case SEND_CLIENT_WAIT:
	default:
		break;
	}
}

void W5500_Greetings(socket_t* soc)
{
	Println(&huart1, "\nset port: ");
	itoa(soc->port, buff, 10);
	Println(&huart1, buff);
	memset(soc->tx_buff, 0, sizeof(soc->tx_buff));
	strcat((char*)soc->tx_buff, (char*)send_get);
	strcat((char*)soc->tx_buff, "greetings/?register=0x002C&value=");
	itoa(AddressBU103, buff, 10);
	strcat((char*)soc->tx_buff, buff);

	strcat((char*)soc->tx_buff, (char*)send_headers);
	Println(&huart1, "\n ");
	Println(&huart1, (char*)soc->tx_buff);
	soc->send_state = 1;  // start sending
}

uint8_t Parse(socket_t*soc, modbus_t*mod)
{
	uint16_t ci;
	uint16_t cb, cv, cval;
	thermo_unit_t *unit;

	mod->nm_bt = soc->rx_buff[4] << 8;
	mod->nm_bt |= soc->rx_buff[5];
	mod->st_reg = soc->rx_buff[8] << 8;
	mod->st_reg |= soc->rx_buff[9];
	mod->err = 0;
	if((mod->nm_bt < 1) || (mod->nm_bt > 252))	mod->err = 2;	// length bytes check error
	if((soc->rx_buff[6] == 0) || (soc->rx_buff[6] == (AddressBU103 & 0xFF)))
	{ // address BU103 is match
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nreceive:");
			for(ci=0; ci<((mod->nm_bt)+6); ci++)
			{
				Println(&huart1, " 0x");
				itoa(soc->rx_buff[ci], buff, 16);
				Println(&huart1, buff);
			}
		}
#endif
		switch(soc->rx_buff[7])
		{ // read/write command
		case READ_HOLD_REG:	// 0x03
		case READ_IN_REG:	// 0x04
			mod->nm_reg = soc->rx_buff[10] << 8;
			mod->nm_reg |= soc->rx_buff[11];
			CheckAddress(soc->rx_buff[7], mod->st_reg, mod->nm_reg, (soc->rx_buff+12));
			memcpy(soc->tx_buff, soc->rx_buff, 8);
			cb = 9;							// index output_buff data
			switch(CalcReq.unit)
			{
			case 0:		// read BU103 registers
				for(ci=0; ci<CalcReq.len; ci++)
				{
					if((ClockRAM.config.state_BU103 == WAIT_STATE) && ((CalcReq.reg+ci == 2) || (CalcReq.reg+ci == 3)))
					{		// wrn & alr answer zero
						soc->tx_buff[cb++] = 0;
						soc->tx_buff[cb++] = 0;
					}
					else
					{
						cval = *ptr_reg[CalcReq.reg+ci];
						soc->tx_buff[cb++] = (uint8_t)((cval >> 8) & 0xFF);
						soc->tx_buff[cb++] = (uint8_t)(cval & 0xFF);
					}
				}
				break;

			case 1:		  // read BAx registers
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				unit = SelUnit(CalcReq.unit);
				for(ci=0; ci<CalcReq.len; ci++)
				{
					cval = unit->ba[CalcReq.reg+ci];
					soc->tx_buff[cb++] = (uint8_t)((cval >> 8) & 0xFF);
					soc->tx_buff[cb++] = (uint8_t)(cval & 0xFF);
				}
				break;

			default:
				mod->err = MODBUS_ADDRESS_REGISTERS_ERROR;
				break;
			}
			if(mod->err == MODBUS_OK)
			{
				soc->tx_buff[8] = ci << 1;
				soc->tx_buff[5] = soc->tx_buff[8] + 3;
				send(soc->num, soc->tx_buff, cb);
			}
			else
			{
				soc->tx_buff[5] = 3;
				soc->tx_buff[6] = AddressBU103;
				soc->tx_buff[7] |= 0x80;
				soc->tx_buff[8] = mod->err;
				send(soc->num, soc->tx_buff, 9);
			}
			break;

		case WRITE_ONE_COIL:	// 0x05
		case WRITE_ONE_REG:		// 0x06
			CheckAddress(WRITE_ONE_REG, mod->st_reg, 1, (soc->rx_buff+10));
			memcpy(soc->tx_buff, soc->rx_buff, 8);
			switch(CalcReq.unit)
			{
			case 0:		// BU
				mod->err = WriteRegisterBU(CalcReq.reg, CalcReq.len);
				break;

			case 1:		// BAx
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				WriteRegisterBA(CalcReq);
				mod->err = MODBUS_OK;
				break;

			default:
				mod->err = MODBUS_ADDRESS_REGISTERS_ERROR;
				break;
			}
			if(mod->err == MODBUS_OK)
			{
				soc->tx_buff[5] = 6;
				soc->tx_buff[7] = soc->rx_buff[7];			// bytes to answer
				soc->tx_buff[8] = soc->rx_buff[8];
				soc->tx_buff[9] = soc->rx_buff[9];
				soc->tx_buff[10] = soc->rx_buff[10];
				soc->tx_buff[11] = soc->rx_buff[11];
				send(soc->num, soc->tx_buff, 12);
			}
			else
			{
				soc->tx_buff[5] = 3;
				soc->tx_buff[6] = AddressBU103;
				soc->tx_buff[7] |= 0x80;
				soc->tx_buff[8] = mod->err;
				send(soc->num, soc->tx_buff, 9);
			}
			break;

		case WRITE_MULTI_REG:	// 0x10
			mod->nm_reg = soc->rx_buff[10] << 8;
			mod->nm_reg |= soc->rx_buff[11];
			CheckAddress(WRITE_MULTI_REG, mod->st_reg, mod->nm_reg, (soc->rx_buff+13));
			memcpy(soc->tx_buff, soc->rx_buff, 8);
			switch(CalcReq.unit)
			{
			case 0:		// BU
				cv = 0;		// bytes counter
				for(ci=0; ci<CalcReq.len; ci++)
				{
					cval = CalcReq.data[cv++] << 8;
					cval |= CalcReq.data[cv++];
					mod->err = WriteRegisterBU(CalcReq.reg+ci, cval);
					if(cv > soc->rx_buff[12])				break;
				}
				ci = cv >> 1;
				break;

			case 1:		// BAx
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				WriteRegisterBA(CalcReq);
				ci = ReqCmd.len;	// length in words
				mod->err = MODBUS_OK;
				break;

			default:
				mod->err = MODBUS_ADDRESS_REGISTERS_ERROR;
				break;
			}

			if(mod->err == MODBUS_OK)
			{
				soc->tx_buff[5] = 6;
				soc->tx_buff[8] = (uint8_t)((mod->st_reg) >> 8);
				soc->tx_buff[9] = (uint8_t)mod->st_reg;
				soc->tx_buff[10] = (uint8_t)(ci >> 8);
				soc->tx_buff[11] = (uint8_t)ci;
				send(soc->num, soc->tx_buff, 12);
			}
			else
			{
				soc->tx_buff[5] = 3;
				soc->tx_buff[6] = AddressBU103;
				soc->tx_buff[7] |= 0x80;
				soc->tx_buff[8] = mod->err;
				send(soc->num, soc->tx_buff, 9);
			}

		default:
			break;
		}

#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nsend:");
			for(ci=0; ci<((soc->tx_buff[5])+6); ci++)
			{
				Println(&huart1, " 0x");
				itoa(soc->tx_buff[ci], buff, 16);
				Println(&huart1, buff);
			}
		}
#endif
	}
	else
	{
		mod->err = 3;	// fail address, no answer send
	}
	return mod->err;
}

void W5500_CSlow(void)
{
	HAL_GPIO_WritePin(ENC_CS_GPIO_Port, ENC_CS_Pin, GPIO_PIN_RESET);
}

void W5500_CShigh(void)
{
	HAL_GPIO_WritePin(ENC_CS_GPIO_Port, ENC_CS_Pin, GPIO_PIN_SET);
}

void W5500_ReadBuff(uint8_t* buff,uint16_t len)
{
	HAL_SPI_Receive(&hspi1, buff, len, TIMEOUT_SPI);
}

void W5500_WriteBuff(uint8_t* buff,uint16_t len)
{
	HAL_SPI_Transmit(&hspi1, buff, len, TIMEOUT_SPI);
}

uint8_t W5500_ReadByte(void)
{
	uint8_t val;
	W5500_ReadBuff(&val, sizeof(val));
	return val;
}

void W5500_WriteByte(uint8_t val)
{
	W5500_WriteBuff(&val, sizeof(val));
}

void NET_Init(void)
{
	W5500_Init();
	HAL_Delay(300);
	W5500_getInit();
	if(presentW5500)
	{
		Sockets_Init();
		W5500_Send_GW();
		W5500_Greetings(&socketTCP);
	}
	else
	{
		Println(&huart1, "\nINIT_W5500_ERROR");
	}
}

void SOCKET_Start(socket_t *soc)
{
	soc->state = socket(soc->num, soc->protokol, soc->port, soc->flag);
	if(soc->state != soc->num)
	{
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nsocket ");
			itoa(soc->num, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, " fail, state = ");
			itoa(soc->state, buff, 10);
			Println(&huart1, buff);
		}
#endif
		soc->state = SOCKET_ERROR;
	}
	else
	{
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nsocket ");
			itoa(soc->num, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, " created");
		}
#endif
	}
}

void W5500_Send_GW(void)
{
	int rez;

	rez = socket(TCP_SOCKET, Sn_MR_TCP, TCP_PORT, 0);
	if(rez != TCP_SOCKET)		return;
	rez = connect(TCP_SOCKET, MyGW, TCP_PORT);
	if(rez != SOCK_OK)
	{
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nconnect_GW_fail, ");
			itoa(rez, buff, 10);
			Println(&huart1, buff);
		}
#endif
		return;
	}
	rez = send(TCP_SOCKET, answer_ok, sizeof(answer_ok));
	if(rez > 1)
	{
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nsend_GW_ok");
		}
#endif
	}
	disconnect(TCP_SOCKET);
	close(TCP_SOCKET);
}

void W5500_Reset(void)
{
	W5500_CShigh();
	HAL_GPIO_WritePin(ENC_RES_GPIO_Port, ENC_RES_Pin, GPIO_PIN_RESET);
	HAL_Delay(50);
	HAL_GPIO_WritePin(ENC_RES_GPIO_Port, ENC_RES_Pin, GPIO_PIN_SET);
	HAL_Delay(1000);
}

void Sockets_Init(void)
{
	socketTCP.state = SOCK_CLOSED;
	socketTCP.num = TCP_SOCKET;
	socketTCP.port = ServerPort;	// 502
	socketTCP.protokol = Sn_MR_TCP;
	socketTCP.flag = 0;
	socketTCP.tm_out = SERVER_TIME_OUT;
// BU server
/*
	socketBU.num = BU_SOCKET;
	socketBU.port = TCP_PORT;		// 80
	socketBU.protokol = Sn_MR_TCP;
	socketBU.flag = 0;
	SOCKET_Start(&socketBU);
*/
// BU client
	socketSEND.state = SOCK_CLOSED;
	socketSEND.num = SEND_SOCKET;
	socketSEND.port = ServerPort;
	socketSEND.protokol = Sn_MR_TCP;
	socketSEND.flag = 0;
	socketSEND.tm_out = CLIENT_TIME_OUT;
}

void W5500_Init(void)
{
	W5500_Reset();
	SetAddresses();

	reg_wizchip_cs_cbfunc(W5500_CSlow, W5500_CShigh);
	reg_wizchip_spi_cbfunc(W5500_ReadByte, W5500_WriteByte);
	reg_wizchip_spiburst_cbfunc(W5500_ReadBuff, W5500_WriteBuff);

	uint8_t rx_tx_buff_sizes[] = {2, 2, 2, 2, 2, 2, 2, 2};
	wizchip_init(rx_tx_buff_sizes, rx_tx_buff_sizes);

	ctlnetwork(CN_SET_NETINFO, (void*) &gWIZNETINFO);
}

void W5500_getInit(void)
{
	ctlnetwork(CN_GET_NETINFO, (void*) &getNETINFO);

	if(getNETINFO.mac[0] == gWIZNETINFO.mac[0])		presentW5500 = 1;
	else											presentW5500 = 0;
	if(gWIZNETINFO.ip[0] == 0)
	{
		presentW5500 = 0;
		Println(&huart1, "\nIP_address_fail");
	}
}

void SetAddresses(void)
{
	uint8_t MyIP[4];
	uint8_t MyIP_MAC[6];
	uint8_t MyIP_MASK[4];
	uint8_t MyIP_DNS[4] = {0, 0, 0, 0};

	MyIP_MAC[0] = 0xF0;
	MyIP_MAC[1] = 0xC4;
	MyIP_MAC[2] = (uint8_t)(ClockRAM.config.mac2_3 >> 8);
	MyIP_MAC[3] = (uint8_t)ClockRAM.config.mac2_3;
	MyIP_MAC[4] = (uint8_t)(ClockRAM.config.mac4_5 >> 8);
	MyIP_MAC[5] = (uint8_t)ClockRAM.config.mac4_5;

	ServerIP[0] = (uint8_t)(ClockRAM.config.serverHi >> 8);
	ServerIP[1] = (uint8_t)ClockRAM.config.serverHi;
	ServerIP[2] = (uint8_t)(ClockRAM.config.serverLow >> 8);
	ServerIP[3] = (uint8_t)ClockRAM.config.serverLow;

	MyIP[0] = (uint8_t)(ClockRAM.config.ipHi >> 8);
	MyIP[1] = (uint8_t)ClockRAM.config.ipHi;
	MyIP[2] = (uint8_t)(ClockRAM.config.ipLow >> 8);
	MyIP[3] = (uint8_t)ClockRAM.config.ipLow;

	MyGW[0] = (uint8_t)(ClockRAM.config.gwHi >> 8);
	MyGW[1] = (uint8_t)ClockRAM.config.gwHi;
	MyGW[2] = (uint8_t)(ClockRAM.config.gwLow >> 8);
	MyGW[3] = (uint8_t)ClockRAM.config.gwLow;

	MyIP_MASK[0] = (uint8_t)(ClockRAM.config.maskHi >> 8);
	MyIP_MASK[1] = (uint8_t)ClockRAM.config.maskHi;
	MyIP_MASK[2] = (uint8_t)(ClockRAM.config.maskLow >> 8);
	MyIP_MASK[3] = (uint8_t)ClockRAM.config.maskLow;

	ServerPort = ClockRAM.config.ipPort;

	memcpy(gWIZNETINFO.ip, MyIP, sizeof(MyIP));
	memcpy(gWIZNETINFO.sn, MyIP_MASK, sizeof(MyIP_MASK));
	memcpy(gWIZNETINFO.gw, MyGW, sizeof(MyGW));
	memcpy(gWIZNETINFO.dns, MyIP_DNS, sizeof(MyIP_DNS));
	memcpy(gWIZNETINFO.mac, MyIP_MAC, sizeof(MyIP_MAC));

	gWIZNETINFO.dhcp = NETINFO_STATIC;

#ifdef _BUS_OUTPUT_UART
	uint8_t ci;
	if(log_debug)
	{
		Println(&huart1, "\nmy_MAC: 0x");
		for(ci=0; ci<6; ci++)
		{
			utoa(gWIZNETINFO.mac[ci], buff, 16);
			Println(&huart1, buff);
			if(ci < 5)	Println(&huart1, ":0x");
		}
		Println(&huart1, "\nserver: ");
		for(ci=0; ci<4; ci++)
		{
			itoa(ServerIP[ci], buff, 10);
			Println(&huart1, buff);
			if(ci < 3)	Println(&huart1, ".");
		}
		Println(&huart1, "\nbu_addr: ");
		for(ci=0; ci<4; ci++)
		{
			itoa(gWIZNETINFO.ip[ci], buff, 10);
			Println(&huart1, buff);
			if(ci < 3)	Println(&huart1, ".");
		}
		Println(&huart1, "\ngateway: ");
		for(ci=0; ci<4; ci++)
		{
			itoa(gWIZNETINFO.gw[ci], buff, 10);
			Println(&huart1, buff);
			if(ci < 3)	Println(&huart1, ".");
		}
		Println(&huart1, "\nmask: ");
		for(ci=0; ci<4; ci++)
		{
			itoa(gWIZNETINFO.sn[ci], buff, 10);
			Println(&huart1, buff);
			if(ci < 3)	Println(&huart1, ".");
		}
		Println(&huart1, "\ndns: ");
		for(ci=0; ci<4; ci++)
		{
			itoa(gWIZNETINFO.dns[ci], buff, 10);
			Println(&huart1, buff);
			if(ci < 3)	Println(&huart1, ".");
		}
		Println(&huart1, "\nport: ");
		itoa(ServerPort, buff, 10);
		Println(&huart1, buff);
	}
#endif
}


