
#include "main.h"
#include <stdlib.h>
#include <string.h>
#include "at25df.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "secure.h"
#include "bu_103_bus.h"
#include "automat.h"

extern SPI_HandleTypeDef hspi1;


void writeEnable(void)
{
	uint8_t TxBuff[8];

	TxBuff[0] = AT25DF_STATUS_WRITE_COMMAND;
	TxBuff[1] = 0;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 2, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();
	TxBuff[0] = AT25DF_WRITE_ENABLE_COMMAND;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 1, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();
}

void writeDisable(void)
{
	uint8_t TxBuff[8];

	TxBuff[0] = AT25DF_WRITE_DISABLE_COMMAND;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 1, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();
}

void sectorProtect(uint32_t addr)
{
	uint8_t TxBuff[8];

	writeEnable();
	TxBuff[0] = AT25DF_SECTOR_PROTECT;
	TxBuff[1] = (addr >> 16) & 0xFF;
	TxBuff[2] = (addr >> 8) & 0xFF;
	TxBuff[3] = addr & 0xFF;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 4, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();
}

void sectorUnprotect(uint32_t addr)
{
	uint8_t TxBuff[8];

	writeEnable();
	TxBuff[0] = AT25DF_SECTOR_UNPROTECT;
	TxBuff[1] = (addr >> 16) & 0xFF;
	TxBuff[2] = (addr >> 8) & 0xFF;
	TxBuff[3] = addr & 0xFF;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 4, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();
}

uint8_t readStatusRegister()
{
    uint8_t RxBuff[4], TxBuff[4];

    TxBuff[0] = AT25DF_STATUS_READ_COMMAND;
    TxBuff[1] = 0xFF;
    TxBuff[2] = 0xFF;
    TxBuff[3] = 0xFF;
    RxBuff[0] = 0xFF;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 1, TIME_OUT_SPI);
    HAL_SPI_TransmitReceive(&hspi1, TxBuff+1, RxBuff, 2, TIME_OUT_SPI);
    AT25DF_SPI_DISABLE();
    statusOne = RxBuff[0];
    return RxBuff[0];
}

void at25df_init(void) 
{
	uint8_t TxBuff[8];

	TxBuff[0] = AT25DF_RESUME_COMMAND;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 1, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();
/*
 * // read manufactured ID
 * //	uint8_t RxBuff[RAM_CONFIG_LEN_BYTES];
	TxBuff[0] = AT25DF_MANUFACTURER_INFO_COMMAND;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 1, TIME_OUT_SPI);
	HAL_SPI_Receive(&hspi1, RxBuff, 5, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();

	Println(&huart1, "\nmanufactured ID:");
	for(TxBuff[3]=0; TxBuff[3]<5; TxBuff[3]++)
	{
		Println(&huart1, " 0x");
		itoa((int)*(RxBuff+TxBuff[3]), buff, 16);
		Println(&huart1, buff);
	}
*/
}

void at25df_pageProgram(uint32_t addr, uint8_t *buff_mem, uint16_t len)
{
	uint8_t TxBuff[8];

	AT25DF_WAIT_UNTIL_DONE();
	writeEnable();
	TxBuff[0] = AT25DF_BYTE_PROGRAM;
	TxBuff[1] = (addr >> 16) & 0xFF;
	TxBuff[2] = (addr >> 8) & 0xFF;
	TxBuff[3] = addr & 0xFF;
	AT25DF_SPI_ENABLE();
	HAL_SPI_Transmit(&hspi1, TxBuff, 4, TIME_OUT_SPI);
	HAL_SPI_Transmit(&hspi1, buff_mem, len, TIME_OUT_SPI);
	AT25DF_SPI_DISABLE();
	AT25DF_WAIT_UNTIL_DONE();
}

void at25df_bulkErase(void)
{
	uint8_t TxBuff[8];

	TxBuff[0] = AT25DF_CHIP_ERASE_COMMAND;
	AT25DF_WAIT_UNTIL_DONE();
    AT25DF_SPI_ENABLE();
    HAL_SPI_Transmit(&hspi1, TxBuff, 1, TIME_OUT_SPI);
    AT25DF_SPI_DISABLE();
}

void at25df_eraseSector(uint32_t addr)
{
	uint8_t TxBuff[8];

	TxBuff[0] = AT25DF_BLOCK_ERASE_4KB;
	TxBuff[1] = (addr >> 16) & 0xFF;
	TxBuff[2] = (addr >> 8) & 0xFF;
	TxBuff[3] = addr & 0xFF;
	AT25DF_WAIT_UNTIL_DONE();
    writeEnable();
    AT25DF_SPI_ENABLE();
    HAL_SPI_Transmit(&hspi1, TxBuff, 4, TIME_OUT_SPI);
    AT25DF_SPI_DISABLE();
}

void at25df_read(uint32_t addr, uint8_t* buff_mem, uint16_t len)
{
	uint8_t TxBuff[6];

	AT25DF_WAIT_UNTIL_DONE();
    TxBuff[0] = AT25DF_READ_ARRAY_COMMAND;
    TxBuff[1] = (addr >> 16) & 0xFF;
    TxBuff[2] = (addr >> 8) & 0xFF;
    TxBuff[3] = addr & 0xFF;
    TxBuff[4] = 0xFF;	// 1st don`t care for FAST
    TxBuff[5] = 0xFF;	// 2 don`t care for HIGH
    AT25DF_SPI_ENABLE();
    HAL_SPI_Transmit(&hspi1, TxBuff, 4, TIME_OUT_SPI);
    HAL_SPI_Receive(&hspi1, buff_mem, len, TIME_OUT_SPI);
    AT25DF_SPI_DISABLE();
}

// Write len bytes (len <= 256) to flash at addr
void at25df_write(uint32_t addr, uint8_t *buff_mem, uint16_t len)
{
    uint8_t *bufCopy;
    uint16_t safeLen, pageOffset;

    if (len > AT25DF_PAGE_SIZE) len = AT25DF_PAGE_SIZE;
    // if buffer tail goes over page boundaries, split to two writes
    // each page is 256 byte long
    bufCopy = buff_mem;
    pageOffset = (uint16_t) (addr & 0x000000FF);
    if ((pageOffset + len) > AT25DF_PAGE_SIZE) 
    {
        safeLen = AT25DF_PAGE_SIZE - pageOffset;
        at25df_pageProgram(addr, bufCopy, safeLen);
        // write remaining bytes in the beginning of the next page
        addr = (addr & 0xffffff00) + AT25DF_PAGE_SIZE;
        len -= safeLen;
        bufCopy += safeLen;
    }
    at25df_pageProgram(addr, bufCopy, len);
}

void AT25DF_WAIT_UNTIL_DONE(void)
{ // 0-ready, 1-busy
	while (readStatusRegister() & AT25DF_STATUS_DONE_MASK);
}

void AT25DF_SPI_ENABLE(void)
{
	HAL_GPIO_WritePin(CS_M_GPIO_Port, CS_M_Pin, GPIO_PIN_RESET); //
//	HAL_GPIO_WritePin(ENC_CS_GPIO_Port, ENC_CS_Pin, GPIO_PIN_RESET); /// debug
}

void AT25DF_SPI_DISABLE(void)
{
	HAL_GPIO_WritePin(CS_M_GPIO_Port, CS_M_Pin, GPIO_PIN_SET); //
//	HAL_GPIO_WritePin(ENC_CS_GPIO_Port, ENC_CS_Pin, GPIO_PIN_SET); /// debug
}

