/*
 * bu_103_bus.c
 *
 *  Created on: 21 янв. 2023 г.
 *      Author: vitaly
 */
#include <string.h>
#include <stdlib.h>
#include "stm32f0xx_hal.h"
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "secure.h"
#include "automat.h"
#include "bu_103_bus.h"
#include "kaskad.h"
#include "at25df.h"
#include "net.h"
#include "table.h"

extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef 	huart3;

void InitializeBus(void)
{
	Setup_UARTs();
	AddressBU103 = ClockRAM.config.AM;
	itoa(CURRENT_VERSION, buff, 10);
	Println(&huart1, "\nCURRENT_VERSION: ");
	if(strlen(buff) < 4)	Println(&huart1, "0");
	Println(&huart1, buff);
	Println(&huart1, " (month, day)");
	Println(&huart1, "\nmodbus address 0x");
	itoa(AddressBU103, buff, 16);
	Println(&huart1, buff);
/*
#ifdef _BUS_OUTPUT_UART
	if(log_debug)
	{
		Println(&huart1, "\n------- Initialize_after_reset BUS ----------");
		Println(&huart1, "\nmodbus address 0x");
		itoa(AddressBU103, buff, 16);
		Println(&huart1, buff);
	}
#endif
*/
}

void Setup_UARTs(void)
{
	USART1->CR1 |= USART_CR1_RXNEIE;
	UART_1.input_buff[0] = USART1->RDR;
	USART3->CR1 |= USART_CR1_RXNEIE;
	UART_3.input_buff[0] = USART3->RDR;

	HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_RESET);
// slave port
	UART_1.cntReceive = 0;
	UART_1.dataReady = 0;
	UART_1.dataOver = 0;
	UART_1.waitTimer = 0;
	UART_1.cntTestLine = ClockRAM.config.t11;
	UART_1.tstLine = 0;
// master port
	UART_3.cntReceive = 0;
	UART_3.dataReady = 0;
	UART_3.dataOver = 0;
	UART_3.waitTimer = 0;
	UART_3.cntTestLine = 0;
	UART_3.tstLine = 0;
}

void TimeOutReceive_10ms(void)
{
	if(UART_1.waitTimer)		UART_1.waitTimer--;
	if(UART_1.waitTimer == 1)	UART_1.dataReady++;
	if(UART_3.waitTimer)		UART_3.waitTimer--;
	if(UART_3.waitTimer == 1)	UART_3.dataReady++;
	ReadUART1();
	ReadUART3();
	if(UART_1.cntTimeOut)	UART_1.cntTimeOut--;
	if(UART_1.cntTimeOut == 1)
	{
		UART_1.cntTimeOut = 0;
		UART_1.dataReady = 0;
	}
	if(UART_3.cntTimeOut)	UART_3.cntTimeOut--;
	if(UART_3.cntTimeOut == 1)
	{
		UART_3.cntTimeOut = 0;
		UART_3.dataReady = 0;
	}
}

void ReadUART1(void)
{
	if(UART_1.dataReady)
	{
		UART_1.num = 1;
		ParseInputSlave(&UART_1);
		UART_1.dataReady = 0;
	}
}

void ReadUART3(void)
{
	if(UART_3.dataReady)
	{
		UART_3.num = 3;
		UART_3.ok = ParseInputMaster(&UART_3);
		UART_3.dataReady = 0;
	}
}

uint8_t ParseInputMaster(config_uart_t *uart)
{
	thermo_unit_t *unit;
	uint8_t	 ret;
	uint16_t ci, cb;
//	uint16_t cval;
	uint32_t cv;

	ret = 0;
	if(uart->cntReceive < 4)
	{
		ClearUartBuff(uart);
		return	ret;
	}

	ci = uart->cntReceive;
	cv = uart->input_buff[ci-1];
	cv = cv << 8;
	cv |= uart->input_buff[ci-2];
	cb = CalculateCRC16(uart->input_buff, ci-2);
	if(cv != cb)
	{
		ClearUartBuff(uart);
		return ret;
	}

//	uart->cntTestLine = ClockRAM.config.t11;		// reload counter for test line
	ret = 1;
	unit = SelUnit(uart->input_buff[0]);
	switch(uart->input_buff[1])
	{
	case READ_HOLD_REG:			// cmd	0x03 read registers
//			Println(&huart1, "\ncmd 0x03 send.");
	case READ_IN_REG:			// cmd	0x04 read registers
//			Println(&huart1, "\ncmd 0x04 send.");
		cb = BEGIN_INIT_REG;
		uart->cntBytes = uart->input_buff[2];
		for(ci=0; ci<uart->cntBytes; ci+=2)
		{
			unit->ba[cb] = (uart->input_buff[ci+3]) << 8;
			unit->ba[cb] |= uart->input_buff[ci+4];
			cb++;
			if(cb > BA_REGISTERS)	cb = BA_REGISTERS;
		}
	break;

	case WRITE_ONE_COIL:		// cmd	0x05
//			Println(&huart1, "\ncmd 0x05 send.");
	case WRITE_ONE_REG:			// cmd	0x06
//			Println(&huart1, "\ncmd 0x06 send.");
		smBus_buff[0] = (uart->input_buff[ci+2]) << 8;
		smBus_buff[0] |= uart->input_buff[ci+3];
		smBus_buff[1] = (uart->input_buff[ci+4]) << 8;
		smBus_buff[1] |= uart->input_buff[ci+5];
		break;

	case WRITE_MULTI_REG:		// cmd	0x10
//			Println(&huart1, "\ncmd 0x10 send.");
		break;

	case REPORT_ID:				// cmd	0x11
		GetReportId(uart);
		break;

	default:
		break;
	}
	if(uart->input_buff[1] & 0x80)
	{
		ret = 2;
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\nerror_cmd: 0x");
			itoa(uart->input_buff[1], buff, 16);
			Println(&huart1, buff);
			Println(&huart1, ", code: 0x");
			itoa(uart->input_buff[2], buff, 16);
			Println(&huart1, buff);
		}
#endif
	}
	ClearUartBuff(uart);
	return ret;
}

void ClearUartBuff(config_uart_t *uart)
{
	uart->cntReceive = 0;
	uart->input_buff[2] = 0;
	uart->input_buff[3] = 0;
	uart->input_buff[4] = 0;
	uart->input_buff[5] = 0;
}

void ParseInputSlave(config_uart_t *uart)
{ // from host to BU
	uint32_t cb, cv;
	uint16_t ci, cval;
	uint8_t  errcode;
	thermo_unit_t *unit;

	if(uart->cntReceive < 4)
	{
		ClearUartBuff(uart);
		return;
	}

	errcode = MODBUS_OK;
#ifdef _BUS_OUTPUT_UART
	len_bf = uart->cntReceive;
	if(log_debug)
	{
		memcpy(input_bf, uart->input_buff, len_bf);
	}
#endif
	ci = uart->cntReceive;
	cv = uart->input_buff[ci-1];
	cv = cv << 8;
	cv |= uart->input_buff[ci-2];
	cb = CalculateCRC16(uart->input_buff, ci-2);
	if(cv != cb)
	{
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			cval = cv >> 8;
			cv = cv << 8;
			cval |= cv;
			itoa(cval, buff, 16);
			Println(&huart1, "\nInput check sum cv: 0x");
			Println(&huart1, buff);
			cval = cb >> 8;
			cb = cb << 8;
			cval |= cb;
			itoa(cval, buff, 16);
			Println(&huart1, "\nCalculate check sum: 0x");
			Println(&huart1, buff);

			itoa(uart->cntReceive, buff, 10);
			Println(&huart1, "\ndata len: ");
			Println(&huart1, buff);

			Println(&huart1, "\nInput buff: ");
			for(cval=0; cval<len_bf; cval++)
			{
				itoa(input_bf[cval], buff, 16);
				if(strlen(buff) == 1)	Println(&huart1, "0");
				Println(&huart1, buff);
				Println(&huart1, " ");
			}
		}
#endif
		ClearUartBuff(uart);
		return;
	}
	uart->cntTestLine = ClockRAM.config.t11;		// reload counter for test line
	if((uart->input_buff[0] == (AddressBU103 & 0xFF)) || (uart->input_buff[0] == 0))
	{
		uart->startReg = (uart->input_buff[2]) << 8;
		uart->startReg |= uart->input_buff[3];
		uart->lenReg = (uart->input_buff[4]) << 8;
		uart->lenReg |= uart->input_buff[5];
		switch(uart->input_buff[1])
		{
			case READ_HOLD_REG:			// cmd	0x03 read register
//			Println(&huart1, "\ncmd 0x03 send.");
			case READ_IN_REG:			// cmd	0x04 read register
//			Println(&huart1, "\ncmd 0x04 send.");
				CheckAddress(uart->input_buff[1], uart->startReg, uart->lenReg, uart->input_buff+6);
				uart->output_buff[0] = AddressBU103;
				uart->output_buff[1] = uart->input_buff[1];
				uart->output_buff[2] = 0;		// bytes counter
				cb = 3;							// index output_buff data
				switch(CalcReq.unit)
				{
				case 0:		// read BU103 registers
					for(ci=0; ci<CalcReq.len; ci++)
					{
						if((ClockRAM.config.state_BU103 == WAIT_STATE) && ((CalcReq.reg+ci == 2) || (CalcReq.reg+ci == 3)))
						{		// wrn & alr answer zero
							uart->output_buff[cb++] = 0;
							uart->output_buff[cb++] = 0;
						}
						else
						{
							cval = *ptr_reg[CalcReq.reg+ci];
							uart->output_buff[cb++] = (uint8_t)((cval >> 8) & 0xFF);
							uart->output_buff[cb++] = (uint8_t)(cval & 0xFF);
						}
					}
					break;

				case 1:		  // read BAx registers
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
				case 8:
				case 9:
				case 10:
					unit = SelUnit(CalcReq.unit);
					for(ci=0; ci<CalcReq.len; ci++)
					{
						cval = unit->ba[CalcReq.reg+ci];
						uart->output_buff[cb++] = (uint8_t)((cval >> 8) & 0xFF);
						uart->output_buff[cb++] = (uint8_t)(cval & 0xFF);
					}
					break;

				default:
					errcode = MODBUS_ADDRESS_REGISTERS_ERROR;
					break;
				}
				if(errcode == MODBUS_OK)
				{
					uart->output_buff[2] = ci << 1;
					CalculateCRC16(uart->output_buff, cb);
					UARTsend(uart, cb+2);
				}
				else
				{
					uart->output_buff[0] = AddressBU103;
					uart->output_buff[1] = uart->input_buff[1] | 0x80;
					uart->output_buff[2] = errcode;
					CalculateCRC16(uart->output_buff, 3);
					UARTsend(uart, 5);
				}
				break;

			case WRITE_ONE_REG:			// cmd	0x06
	//			Println(&huart1, "\ncmd 0x06 send.");
				CheckAddress(WRITE_ONE_REG, uart->startReg, 1, uart->input_buff+4);
				switch(CalcReq.unit)
				{
				case 0:		// BU
					errcode = WriteRegisterBU(CalcReq.reg, CalcReq.len);
					break;

				case 1:		// BAx
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
				case 8:
				case 9:
				case 10:
					WriteRegisterBA(CalcReq);
					errcode = MODBUS_OK;
					break;

				default:
					errcode = MODBUS_ADDRESS_REGISTERS_ERROR;
					break;
				}
				if(errcode == MODBUS_OK)
				{
					uart->output_buff[0] = AddressBU103;
					uart->output_buff[1] = uart->input_buff[1];
					uart->output_buff[2] = (uart->startReg) >> 8;			// bytes to answer
					uart->output_buff[3] = uart->startReg;
					uart->output_buff[4] = (uart->lenReg) >> 8;
					uart->output_buff[5] = uart->lenReg;
					CalculateCRC16(uart->output_buff, 6);
					UARTsend(uart, 8);
				}
				else
				{
					uart->output_buff[0] = AddressBU103;
					uart->output_buff[1] = uart->input_buff[1] | 0x80;
					uart->output_buff[2] = errcode;
					CalculateCRC16(uart->output_buff, 3);
					UARTsend(uart, 5);
				}
				break;

			case LOOP_TEST:				// cmd 	0x08
	//			Println(&huart1, "\ncmd 0x08 send.");
				for(ci=0; ci<uart->cntReceive; ci++)
				{
					uart->output_buff[ci] = uart->input_buff[ci];
				}
				UARTsend(uart, ci);
				break;

			case WRITE_MULTI_REG:		// cmd	0x10
	//			Println(&huart1, "\ncmd 0x10 send.");
				CheckAddress(WRITE_MULTI_REG, uart->startReg, uart->lenReg, uart->input_buff+7);
				switch(CalcReq.unit)
				{
				case 0:		// BU
					cv = 0;		// bytes counter
					for(ci=0; ci<CalcReq.len; ci++)
					{
						cval = CalcReq.data[cv++] << 8;
						cval |= CalcReq.data[cv++];
						errcode = WriteRegisterBU(CalcReq.reg+ci, cval);
						if(cv > uart->input_buff[6])		break;
					}
					break;

				case 1:		// BAx
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
				case 8:
				case 9:
				case 10:
					WriteRegisterBA(CalcReq);
					ci = ReqCmd.len;	// length in words
					errcode = MODBUS_OK;
					break;

				default:
					errcode = MODBUS_ADDRESS_REGISTERS_ERROR;
					break;
				}

				if(errcode == MODBUS_OK)
				{
					uart->output_buff[0] = AddressBU103;
					uart->output_buff[1] = uart->input_buff[1];
					uart->output_buff[2] = (uart->startReg) >> 8;
					uart->output_buff[3] = uart->startReg;
					uart->output_buff[4] = ci >> 8;
					uart->output_buff[5] = ci;
					CalculateCRC16(uart->output_buff, 6);
					UARTsend(uart, 8);
				}
				else
				{
					uart->output_buff[0] = AddressBU103;
					uart->output_buff[1] = WRITE_MULTI_REG | 0x80;
					uart->output_buff[2] = errcode;
					CalculateCRC16(uart->output_buff, 3);
					UARTsend(uart, 5);
				}
				break;

			case REPORT_ID:				// cmd	0x11
				GetReportId(uart);
				break;

	//////////////// Debug command //////////////////////////////////////////

			case TEST_CMD_0:		// cmd 0xA0
			// set default settings
				SetConfigDefault();
				Println(&huart1, "\nrestore_default_data...");
				break;

			case TEST_CMD_1:			// cmd	0xA2
	// clear all units
#ifdef _BUS_OUTPUT_UART
					Println(&huart1, "\nclear units...");
					ClearUnits();
#endif
					break;

			case TEST_CMD_2:			// cmd	0xA4, 01 A4 01 9B
	// read input data
				itoa(inputData, buff, 16);
				Println(&huart1, "\nInput data: 0x");
				Println(&huart1, buff);
				itoa(DIO, buff, 16);
				Println(&huart1, "\ndio: 0x");
				Println(&huart1, buff);
				itoa(ALR, buff, 16);
				Println(&huart1, "\nalr: 0x");
				Println(&huart1, buff);
				itoa(U_input, buff, 10);
				Println(&huart1, "\nInput voltage: ");
				Println(&huart1, buff);
				itoa(T_hot, buff, 10);
				Println(&huart1, "\nTemperatura podachi: ");
				Println(&huart1, buff);
				Println(&huart1, " *C");
				itoa(T_cold, buff, 10);
				Println(&huart1, "\nTemperatura obratki: ");
				Println(&huart1, buff);
				Println(&huart1, " *C");
				itoa(T_out, buff, 10);
				Println(&huart1, "\nTemperatura ulizy: ");
				Println(&huart1, buff);
				Println(&huart1, " *C");
				itoa(T_in, buff, 10);
				Println(&huart1, "\nTemperatura kotelnoi: ");
				Println(&huart1, buff);
				Println(&huart1, " *C");
				Println(&huart1, "\nlsa: 0b");
				itoa(ClockRAM.config.lsa, buff, 2);
				Println(&huart1, buff);
				Println(&huart1, "; lsb: 0b");
				itoa(ClockRAM.config.lsb, buff, 2);
				Println(&huart1, buff);
				break;

			case TEST_CMD_4:			// cmd	0xA8, 01 A8 00 01 41 f8
#ifdef _BUS_OUTPUT_UART
			// off all units
			if(Room.State == ROOM_WAIT)
			{
				Room.State = ROOM_OFF;
				Println(&huart1, "\noff all units");
			}
			else
			{
				Println(&huart1, "\nRoom.State: ");
				itoa(Room.State, buff, 10);
				Println(&huart1, buff);
				Println(&huart1, "\nRoom.AllUnits: ");
				itoa(Room.AllUnits, buff, 10);
				Println(&huart1, buff);
				Println(&huart1, ", Room.kaskadUnits: ");
				itoa(Room.kaskadUnits, buff, 10);
				Println(&huart1, buff);
				Println(&huart1, "\nRoom.addresses{ ");
				for(cnt=0; cnt<Room.AllUnits; cnt++)
				{
					itoa(Room.addresses[cnt], buff, 10);
					Println(&huart1, buff);
					Println(&huart1, " ");
				}
				Println(&huart1, "}");
				Println(&huart1, "; Room.kaskad{ ");
				for(cnt=0; cnt<Room.AllUnits; cnt++)
				{
					itoa(Room.kaskad[cnt], buff, 10);
					Println(&huart1, buff);
					Println(&huart1, " ");
				}
				Println(&huart1, "}");
			}
#endif
				break;

			case TEST_CMD_5:			// cmd	0xAA
#ifdef _BUS_OUTPUT_UART
				// control output log
				log_debug = uart->input_buff[3];
				ClockRAM.config.log_debug_state = log_debug;
				if(log_debug)
				{
					Println(&huart1, "\nDebug message ON");
				}

				else
				{
					Println(&huart1, "\nDebug message OFF");
				}
#endif
			break;

			case TEST_CMD_6:			// cmd	0xAC
	// read registers of unit
#ifdef _BUS_OUTPUT_UART
				Println(&huart1, "\nUnit ");
				itoa(uart->input_buff[3], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, ", ALR: 0x");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_ALR], buff, 16);
				Println(&huart1, buff);
				Println(&huart1, ", WRN: 0x");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_WRN], buff, 16);
				Println(&huart1, buff);
				Println(&huart1, ", SRK: 0x");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_SRK], buff, 16);
				Println(&huart1, buff);
				Println(&huart1, ", RR: 0x");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_RR], buff, 16);
				Println(&huart1, buff);
				Println(&huart1, ", RC: 0x");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_RC], buff, 16);
				Println(&huart1, buff);
				Println(&huart1, ", DT1: ");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_DT1], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, ", TUST: ");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_TUST], buff, 10);
				Println(&huart1, buff);
				Println(&huart1, ", ZF: ");
				itoa(SelUnit(uart->input_buff[3])->ba[ADDR_POINT_ZF], buff, 10);
				Println(&huart1, buff);
#endif
				break;

			case TEST_CMD_7: // 0xAE
// client GET to server
#ifdef _BUS_OUTPUT_UART
				if(uart->cntReceive > 4)
				{
					socketSEND.port = (uart->input_buff[2]) << 8;
					socketSEND.port += uart->input_buff[3];
				}
				W5500_Greetings(&socketTCP);
#endif
				break;

			default:
				uart->output_buff[0] = AddressBU103;
				uart->output_buff[1] = uart->input_buff[1] | 0x80;
				uart->output_buff[2] = MODBUS_FUNCTION_NOT_SUPPORT;	// errcode command
				CalculateCRC16(uart->output_buff, 3);
				UARTsend(uart, 5);
				break;
		}
		ClearUartBuff(uart);
	}
	else
	{ // no match address
		ClearUartBuff(uart);
	}
}

void GetReportId(config_uart_t *uart)
{
	uart->output_buff[0] = AddressBU103;
	uart->output_buff[1] = REPORT_ID;
	uart->output_buff[2] = 8;		// length
	uart->output_buff[3] = '"';
	uart->output_buff[4] = 'B';
	uart->output_buff[5] = 'U';
	uart->output_buff[6] = '-';
	uart->output_buff[7] = '1';
	uart->output_buff[8] = '0';
	uart->output_buff[9] = '3';
	uart->output_buff[10] = '"';
	CalculateCRC16(uart->output_buff, 11);
	UARTsend(uart, 13);
}

uint8_t WriteRegisterBU(uint16_t addr, uint16_t val)
{ // write register BU103
	switch(addr)
	{
		case 0x07:	// rrk
			val = val & 0x0001;
			if(BIT_TEST(val, 0) == 0)
			{ // manual pump mode
				BIT_CLR(ClockRAM.config.wrn, 6);	// clear pump warning
			}
			*ptr_reg[addr] = val;
			break;

		case 0x08:	// dc
			if((BIT_TEST(ClockRAM.config.dc, 0) == 0) && (BIT_TEST(val, 0)))
			{ // Включение котельной
				ClockRAM.config.state_BU103 = GO_WORK_STATE;
			}
			if(BIT_TEST(ClockRAM.config.dc, 0) && (BIT_TEST(val, 0) == 0))
			{ // Выключение котельной
				Room.State = ROOM_OFF;		// off all RegKaskad();
				ClockRAM.config.state_BU103 = GO_WAIT_STATE;
			}
			if(BIT_TEST(val, 1))
			{ // Сброс аварий
				ClockRAM.config.alrMemory = 0;
				BIT_CLR(val, 1);
			}
			if(BIT_TEST(val, 2) != BIT_TEST(ClockRAM.config.dc, 2))
			{ // выбор oсновного насоса в автоматическом режиме
				BIT_CLR(ClockRAM.config.wrn, 6);	// clear pump warning
				if(BIT_TEST(val, 2) && BIT_TEST(ClockRAM.config.rrk, 0))
				{ // select pump 2 in automatic mode
					BIT_SET(ClockRAM.config.dc, 2);
					if(BIT_TEST(ClockRAM.config.dc, 3))
					{ // if pump 1 work it, run pump 2
						ControlPumps.statePumps = START_PRIMARY_PUMP;
					}
				}
				if((BIT_TEST(val, 2) == 0) && BIT_TEST(ClockRAM.config.rrk, 0))
				{ // select pump 1 in automatic mode
					BIT_CLR(ClockRAM.config.dc, 2);
					if(BIT_TEST(ClockRAM.config.dc, 4))
					{ // if pump 2 work it, run pump 1
						ControlPumps.statePumps = START_PRIMARY_PUMP;
					}
				}
			}
			if((val & DC_PUMPS_MASK) != (ClockRAM.config.dc & DC_PUMPS_MASK))
			{ // bits 3, 4
				if((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0)
				{	// manual mode
					BIT_CLR(ClockRAM.config.wrn, 6);	// clear pump warning
					if(BIT_TEST(ClockRAM.config.dc, 3) || BIT_TEST(ClockRAM.config.dc, 4))
					{
						switch(val & DC_PUMPS_MASK)
						{
							default:
							BIT_CLR(val, 3);
							BIT_CLR(val, 4);
							if(BIT_TEST(ClockRAM.config.dc, 3))		BIT_SET(val, 3);
							if(BIT_TEST(ClockRAM.config.dc, 4))		BIT_SET(val, 4);
							return ERROR_BUS_SET_DATA;
							break;

							case 0:
							BIT_CLR(ClockRAM.config.dc, 3);		// off pump 1
							BIT_CLR(ClockRAM.config.dc, 4);		// off pump 2
							break;
						}
					}
					else if((BIT_TEST(ClockRAM.config.dc, 3) == 0) && (BIT_TEST(ClockRAM.config.dc, 4) == 0))
					{
						switch(val & DC_PUMPS_MASK)
						{
							case 0x08:	// pump 1 on
							BIT_SET(ClockRAM.config.dc, 3);		// on pump 1
							break;

							case 0x10:	// pump 2 on
							BIT_SET(ClockRAM.config.dc, 4);		// on pump 2
							break;

							default:
							BIT_CLR(val, 3);
							BIT_CLR(val, 4);
							return ERROR_BUS_SET_DATA;
							break;
						}
					}
				}
				else
				{ // automatic mode
					BIT_CLR(val, 3);
					BIT_CLR(val, 4);
					if(BIT_TEST(ClockRAM.config.dc, 3))		BIT_SET(val, 3);
					if(BIT_TEST(ClockRAM.config.dc, 4))		BIT_SET(val, 4);
					return ERROR_BUS_SET_DATA;
				}
			}
			if((BIT_TEST(ClockRAM.config.dc, 5) == 0) && BIT_TEST(val, 5))
			{ // ohrana on
				if(ReadSensorOhr() == SENSOR_OHR_CLOSE)		ohrState = OHR_WAIT_SENSOR_CLOSE;
				else  										ohrState = OHR_WAIT_SENSOR_OPEN;
			}
			if(BIT_TEST(ClockRAM.config.dc, 5) && (BIT_TEST(val, 5) == 0))
			{ // ohrana off
				ohrState = OHR_GO_OFF;
			}
			*ptr_reg[addr] = val;
			break;

		case 0x09:		// cfg
			if(BIT_TEST(val, 4))
			{
				ClockRAM.config.lsa = 0;
				ClockRAM.config.lsb = 0;
				BIT_CLR(ClockRAM.config.alr, 9);		// reset alarm BA
				BIT_CLR(ClockRAM.config.alrMemory, 9);	// reset alarm BA
				BIT_CLR(ClockRAM.config.wrn, 10);		// reset alarm BA
				BIT_CLR(val, 4);
				scanState = SCAN_UNITS_START;	// scanning units start ScanUnits();
			}
			*ptr_reg[addr] = val;
#ifdef _BUS_OUTPUT_UART
			if(log_debug)
			{
				if((val & 0x0001) == 0x0001)
				{ // on/off anti froze
					Println(&huart1, "\nanti_froze_on");
				}
				else
				{
					Println(&huart1, "\nanti_froze_off");
				}
				if((val & 0x0002) == 0x0002)
				{ // on/off reg pogoda
					Println(&huart1, "\nreg_pogoda_on");
				}
				else
				{
					Println(&huart1, "\nreg_pogoda_off");
				}
				if((val & 0x0004) == 0x0004)
				{ // on/off reg kaskad
					Println(&huart1, "\nreg_kaskad_on");
				}
				else
				{
					Println(&huart1, "\nreg_kaskad_off");
				}
			}
#endif
			break;

		case 0x0C:	// tdi
			*ptr_reg[addr] = val;
			InitInputs();
			break;

		case 0x11:	// T31, Tust manual
			if((val < T_PODACHI_MIN) || (val > T_PODACHI_MAX))	return ERROR_BUS_SET_DATA;
			else												*ptr_reg[addr] = val;
			break;

		case 0x13:	// t33, shnek off time
			if(val > 6000)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x14:	// t34, shnek on time
			if(val > 600)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x15:	// N34, kurva
			if((val < 2) || (val > 40))		return ERROR_BUS_SET_DATA;
			else							*ptr_reg[addr] = val;
			break;

		case 0x16:	// T35,
			if(((int16_t)val < -10) || ((int16_t)val > 10))		return ERROR_BUS_SET_DATA;
			else												*ptr_reg[addr] = val;
			break;

		case 0x17:	// t37
			if(val > 60)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x18:	// t38
			if(val > 720)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x19:	// T41,
			if(val > 100)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x1A:	// T42,
			if(val > 100)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x1B:	// T43
			if(val > 170)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x1C:	// T44
			if(((int16_t)val < -100) || ((int16_t)val > 0))		return ERROR_BUS_SET_DATA;
			else												*ptr_reg[addr] = val;
			break;

		case 0x1D:	// T45
			if(val > 170)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x1E:	// T46
			if(((int16_t)val < -100) || ((int16_t)val > 0))		return ERROR_BUS_SET_DATA;
			else												*ptr_reg[addr] = val;
			break;

		case 0x1F:	// T47
			if(((int16_t)val < -10) || ((int16_t)val > 50))		return ERROR_BUS_SET_DATA;
			else												*ptr_reg[addr] = val;
			break;

		case 0x20:	// delta_T41
			if(val > 10)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x21:	// delta_T42
			if(val > 10)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x22:	// delta_T47
			if(val > 10)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x23:	// t54
			if(val > 10)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x24:	// t63
			if(val > 255)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x25:	// t71
			if(val > 255)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x26:	// t72
			if(val > 600)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x27:	// N73
			if(val > 255)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x28:	// t81
			if((val < 1) || (val > 255))		return ERROR_BUS_SET_DATA;
			else								*ptr_reg[addr] = val;
			break;

		case 0x29:	// t82
			if((val < 1) || (val > 255))		return ERROR_BUS_SET_DATA;
			else								*ptr_reg[addr] = val;
			break;

		case 0x2A:	// t83
			if(val > 255)		return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x2B:	// t11
			if((val < 1) || (val > 255))		return ERROR_BUS_SET_DATA;
			else								*ptr_reg[addr] = val;
			break;

		case 0x2C:	// address
			if((val < 1) || (val > 10))		return ERROR_BUS_SET_DATA;
			else							*ptr_reg[addr] = val;
			break;

		case 0x2E:	// server ip hi
		case 0x2F:	// server ip low
		case 0x30:  // port
		case 0x31:	// bu ip hi
		case 0x32:	// bu ip low
		case 0x33:	// mask ip hi
		case 0x34:	// mask ip low
		case 0x35:	// gw ip hi
		case 0x36:	// gw ip low
		case 0x37:	// mac 2, 3
		case 0x38:	// mac 4, 5
			*ptr_reg[addr] = val;
			break;

		case 0x39:	// T36
			if((val < 20) || (val > 70))	return ERROR_BUS_SET_DATA;
			else							*ptr_reg[addr] = val;
			break;

		default:
			return ERROR_INCORRECT_WRITING;
			break;
		}
	return NO_ERRORS;
}

void CheckAddress(uint8_t cmd, uint16_t reg, uint16_t len, uint8_t *val)
{ // create calc_addr_t structure for unit BA(1...10), BU(0), 0x80 - fail address

	CalcReq.unit = ERROR_CALC_ADDRESS;
	CalcReq.cmd = cmd;
	CalcReq.len = 0;
	CalcReq.reg = 0;
	memset(CalcReq.data, 0, sizeof(CalcReq.data));
	if((reg > 0) && (reg < REGISTERS))
	{
		if((reg + len) > REGISTERS)
		{ // error check
			CalcReq.unit = ERROR_CALC_ADDRESS;
		}
		else
		{
			CalcReq.unit = 0;	// BU103
			CalcReq.reg = reg;
			CalcReq.len = len;
		}
	}
	else if((reg > BASE_UNIT_1) && (reg < (BASE_UNIT_1+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 0)))
	{
		CalcReq.unit = 1;
		CalcReq.reg = reg-BASE_UNIT_1;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_2) && (reg < (BASE_UNIT_2+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 1)))
	{
		CalcReq.unit = 2;
		CalcReq.reg = reg-BASE_UNIT_2;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_3) && (reg < (BASE_UNIT_3+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 2)))
	{
		CalcReq.unit = 3;
		CalcReq.reg = reg-BASE_UNIT_3;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_4) && (reg < (BASE_UNIT_4+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 3)))
	{
		CalcReq.unit = 4;
		CalcReq.reg = reg-BASE_UNIT_4;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_5) && (reg < (BASE_UNIT_5+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 4)))
	{
		CalcReq.unit = 5;
		CalcReq.reg = reg-BASE_UNIT_5;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_6) && (reg < (BASE_UNIT_6+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 5)))
	{
		CalcReq.unit = 6;
		CalcReq.reg = reg-BASE_UNIT_6;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_7) && (reg < (BASE_UNIT_7+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 6)))
	{
		CalcReq.unit = 7;
		CalcReq.reg = reg-BASE_UNIT_7;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_8) && (reg < (BASE_UNIT_8+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 7)))
	{
		CalcReq.unit = 8;
		CalcReq.reg = reg-BASE_UNIT_8;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_9) && (reg < (BASE_UNIT_9+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 8)))
	{
		CalcReq.unit = 9;
		CalcReq.reg = reg-BASE_UNIT_9;
		CalcReq.len = len;
	}
	else if((reg > BASE_UNIT_10) && (reg < (BASE_UNIT_10+1+BA_REGISTERS)) && (BIT_TEST(ClockRAM.config.lsa, 9)))
	{
		CalcReq.unit = 10;
		CalcReq.reg = reg-BASE_UNIT_10;
		CalcReq.len = len;
	}
	else
	{ // error check
		CalcReq.unit = ERROR_CALC_ADDRESS;
	}
	if((CalcReq.reg + CalcReq.len) > BA_REGISTERS)
	{
		CalcReq.unit = ERROR_CALC_ADDRESS;
	}
	switch(cmd)
	{
	case READ_HOLD_REG:
	case READ_IN_REG:

		break;

	case WRITE_ONE_COIL:
	case WRITE_ONE_REG:
		CalcReq.len = val[0] << 8;		// value for write
		CalcReq.len |= val[1];
		break;

	case WRITE_MULTI_REG:
		CalcReq.len = len;
		switch(CalcReq.unit)
		{
		case 0:		// BU
			if((CalcReq.reg + CalcReq.len) < REGISTERS)
			{
				memcpy(CalcReq.data, val, len*2);		// value for write
			}
			else
			{
				CalcReq.unit = ERROR_CALC_ADDRESS;
			}
			break;

		case 1:		// BAx
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
			if((CalcReq.reg + CalcReq.len) < (BA_REGISTERS+1))
			{
				memcpy(CalcReq.data, val, len*2);		// value for write
			}
			else
			{
				CalcReq.unit = ERROR_CALC_ADDRESS;
			}
			break;

		default:
			break;
		}
		break;

	default:
		break;
	}
}

void WriteRegisterBA(calc_addr_t req)
{
	ReqCmd.addr = req.unit;
	ReqCmd.cmd = req.cmd;				// cmd write
	ReqCmd.reg = req.reg;				// addr write
	switch(req.cmd)
	{
	case READ_HOLD_REG:
	case READ_IN_REG:

		break;

	case WRITE_ONE_COIL:
	case WRITE_ONE_REG:
		ReqCmd.len = req.len;				// data to write
		ReqCmd.state = REQ_UNIT_SEND;
		break;

	case WRITE_MULTI_REG:
		ReqCmd.len = req.len;
		memcpy(ReqCmd.data, req.data, sizeof(ReqCmd.data));	// data to write
		ReqCmd.state = REQ_UNIT_SEND;
		break;

	default:
		break;
	}
}

void UARTsend(config_uart_t *uart, uint16_t len)
{
	switch(uart->num)
	{
	default:
		break;

	case 1:
		HAL_UART_Transmit(&huart1, uart->output_buff, len, UART_TIMEOUT);
		break;

	case 3:
		HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_SET);
		HAL_UART_Transmit(&huart3, uart->output_buff, len, UART_TIMEOUT);
		HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_RESET);
		break;
	}
}

void InitEEPROM(void)
{
#ifdef _MEMORY_25_SERIES
///	at25df_bulkErase();
	cntEeRamAddr = START_ADDR;
	at25df_init();
#endif

#ifdef _MEMORY_24_SERIES
	uint8_t buf[8];

#ifdef _BUS_OUTPUT_UART
	Println(&huart1, "\ninit 24 series memory");
#endif
	if(HAL_I2C_Master_Receive(&hi2c1, MEM_ADDR, buf, 4, TIMEOUT_I2C) != HAL_OK)
	{
#ifdef _BUS_OUTPUT_UART
		Println(&huart1, " fail!");
#endif
	}
	else
	{
#ifdef _BUS_OUTPUT_UART
		Println(&huart1, " ok...");
#endif
	}
#endif
}

void SendCMDtoBA(uint8_t addr, uint8_t cmd, uint16_t reg, uint16_t len)
{ // ansver/data in smBus_buff[]
	uint16_t ci, cb;

//	memset(UART_3.input_buff, 0xFF, sizeof(UART_3.input_buff));
	switch(cmd)
	{
		case READ_HOLD_REG:			// cmd	0x03 read registers
		case READ_IN_REG:			// cmd	0x04 read registers
		case WRITE_ONE_COIL:		// cmd	0x05
		case WRITE_ONE_REG:			// cmd	0x06
		UART_3.num = 3;
		UART_3.output_buff[0] = addr;
		UART_3.output_buff[1] = cmd;
		UART_3.output_buff[2] = reg >> 8;
		UART_3.output_buff[3] = reg;
		UART_3.output_buff[4] = len >> 8;
		UART_3.output_buff[5] = len;
		CalculateCRC16(UART_3.output_buff, 6);
		UARTsend(&UART_3, 8);
		break;

		case WRITE_MULTI_REG:			// cmd	0x10
		// before write data to smBus_buff[]!!!
		UART_3.num = 3;
		UART_3.output_buff[0] = addr;
		UART_3.output_buff[1] = cmd;
		UART_3.output_buff[2] = reg >> 8;	// start register
		UART_3.output_buff[3] = reg;
		UART_3.output_buff[4] = len >> 8;	// lengh words
		UART_3.output_buff[5] = len;
		UART_3.output_buff[6] = len << 1;	// lengh bytes
		cb = 6;
		for(ci=0; ci<len; ci++)
		{
			cb++;
			UART_3.output_buff[cb] = (smBus_buff[ci] >> 8);
			cb++;
			UART_3.output_buff[cb] = (uint8_t)smBus_buff[ci];
		}
		cb++;
		CalculateCRC16(UART_3.output_buff, cb);
		cb += 2;
		UARTsend(&UART_3, cb);
		break;

		default:
		break;
	}
}

uint16_t CalculateCRC16(uint8_t * line, uint16_t len)
{
    uint8_t  j;
    uint16_t CRC16, tmp, i;

    CRC16 = 0xFFFF; // CRC - начальное значение
    for (i = 0; i < len; i++)
    {
        CRC16 ^= line[i];
        for (j = 0; j < 8; j++)
        {
            tmp = CRC16 & 0x0001;
            CRC16 >>= 1;
            if (tmp == 1)
            {
                CRC16 ^= 0xA001; // тоже или полиномиальный
            }
        }
    }
    line[i++] = (uint8_t)CRC16;
    line[i++] = (uint8_t)(CRC16 >> 8);
	return CRC16;
}



