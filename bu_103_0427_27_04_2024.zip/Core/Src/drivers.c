/*
 * drivers.c
 * buttons input, LED output, data serial input (597), data serial output (595)
 *  Created on: 6 дек. 2022 г.
 *      Author: vitaly
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "secure.h"
#include "bu_103_bus.h"
#include "automat.h"
#include "net.h"
#include "dhcp.h"
#include "kaskad.h"
#include "at25df.h"

extern I2C_HandleTypeDef	hi2c1;

void InitDrivers(void)
{
	secLogCnt = 0;
	event_1sec_drv = 0;
	event_1mS_drv = 0;
	trueValue = 0;

	relayData = 0;
	countADC = 1;

	OE_LED_UNSET();
	OE_OUT_UNSET();
	OE_IN_LOAD();
	SDLED_CLR();
	SDOUT_CLR();
	SCLOCK();
	SLATCH();

	ledDisplay.LedOhrana = OHRANA_OFF;
	ledDisplay.LedState = STATE_OFF;
	ledDisplay.Flashing = 0;
	ledDisplay.pulseCnt = 0;
	ledDisplay.stateInd = 1;
	Display("---", OHRANA_OFF, STATE_OFF, FLASH_DIGIT);

	InitEEPROM();
	InitAutomat();			// 1-ste! read memory to ram
	InitializeOhr();
	InitializeBus();
	scanState = INIT_UNIT_PRESEND;	//  ScanUnits();

	NET_Init();
}

void Drivers(void)
{ // 1 mSec running
//	LEDs();		//indication + adc conversion, in stm32f0xx_it.c
	ReadKeys();
	BeepRun();
	Meassure();
	OutputToRegister();
	if(Tick10ms > 9)
	{ 	// 10 mSec.
		Tick10ms = 0;
		CompareEEpromRAM();		// write data to clock RAM memory
		if(Menu.CurrMenu < CURR_SERVICE)
		{
			TimeOutReceive_10ms();		// reading UARTs
			Event_10ms();		// secure.c
		}
	}
	if(Tick50ms > 49)
	{ 	// 50 mSec.
		Tick50ms = 0;
		ReadControlPin();	// ohrana
		ReadUnitReg();
		UnitStream();
	}
	if(Tick250ms > 249)
	{ 	// 250 mSec.
		Tick250ms = 0;
		RunMenu();
	}
	Tick10ms++;
	Tick50ms++;
	Tick250ms++;
}

void Working(void)
{ // 1 second running
	Delays();
	if((Menu.CurrMenu < CURR_SERVICE) && (trueValue > TRUE_VALUE_DELAY))
	{
		RunOhr();
		TestInputs();
		SetState();
		AntiFroze();
		SetAvary();
		PogodaTemp();
		TestUnits();
		Pump();
		ZoloDel();
	}
}

void Delays(void)
{
	if(UART_1.cntTestLine)	UART_1.cntTestLine--;
	if(UART_3.cntTestLine)	UART_3.cntTestLine--;
	if(timeoutService)		timeoutService--;
	if(timeoutService == 1)
	{ /// off timeout for debug
		exitService();
		Menu.CurrMenu = CURR_AUTH;
		Beep(BEEP_PULSE_2);

	}
	if(timeoutAutomat)		timeoutAutomat--;
	if(timeoutAutomat == 1)
	{ /// off timeout for debug
		if(Menu.RunMenu != RUN_MENU_MIN)
		{
			Menu.CurrMenu = RUN_MENU;
			Beep(BEEP_PULSE_2);
		}
		if(Menu.CurrMenu == RUN_MENU)		Menu.RunMenu = RUN_MENU_MIN;
	}
	if(DA11.delay)		DA11.delay--;
	if(DA12.delay)		DA12.delay--;
	if(DA13.delay)		DA13.delay--;
	if(DA14.delay)		DA14.delay--;
	if(DA15.delay)		DA15.delay--;
	if(DA16.delay)		DA16.delay--;
	if(DA17.delay)		DA17.delay--;
	if(DA18.delay)		DA18.delay--;
	if(Room.timeCounter > 1)		Room.timeCounter--;
	if(ControlPumps.cntTimeDiff)	ControlPumps.cntTimeDiff--;
	if(ControlPumps.pumpDelay)		ControlPumps.pumpDelay--;
}

void Display(char *buff, uint8_t ohrana, uint8_t state, uint8_t flash)
{
	if(ohrana != OHRANA_CURR)		ledDisplay.LedOhrana = ohrana;
	if(state != STATE_CURR)			ledDisplay.LedState = state;
	ledDisplay.Flashing = flash;

	ledDisplay.Digit1 = Decode(buff[0]);
	if((indPoints) && (Menu.CurrMenu == AVARY_MENU))		ledDisplay.Digit1 |= DIGIT_POINT;
	ledDisplay.Digit2 = Decode(buff[1]);
	if(Menu.ServiceMenu == SERVICE_UIN && Menu.CurrMenu == SUB_MENU_SERVICE)	ledDisplay.Digit2 |= DIGIT_POINT;
	if((indPoints) && (Menu.CurrMenu == AVARY_MENU))		ledDisplay.Digit2 |= DIGIT_POINT;
	ledDisplay.Digit3 = Decode(buff[2]);
	if((indPoints) && (Menu.CurrMenu == AVARY_MENU))		ledDisplay.Digit3 |= DIGIT_POINT;
	if((Menu.CurrMenu == SUB_RUN_MENU) && (Menu.RunMenu == RUN_SET_UST))	ledDisplay.Digit1 = Decode('t');
	if((Menu.CurrMenu == RUN_MENU) && (Menu.RunMenu == RUN_SET_UST))		ledDisplay.Digit1 = Decode('t');
}

void Relays(uint8_t chan, uint8_t state)
{
	if(state)	BIT_SET(relayData, chan);
	else		BIT_CLR(relayData, chan);
}

void RelayAlarm(uint8_t val)
{
	if(val)		BIT_SET(relayData, RELAY_ALARM);
	else		BIT_CLR(relayData, RELAY_ALARM);
#ifdef _AUTOMAT_OUTPUT_UART
	if(log_debug)
	{
		if(val)		Println(&huart1, "\nRelay ALARM on");
		else		Println(&huart1, "\nRelay ALARM off");
	}
#endif
}

void LEDs(void)
{ // flasing bit0,1,2-display, bit4-state, bit5-ohrana
	if(ledDisplay.pulseCnt)		ledDisplay.pulseCnt--;
	if(ledDisplay.pulseCnt == 0)
	{
		switch(ledDisplay.stateInd)
		{
			case 1:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_DIGIT1) == FLASH_DIGIT1))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.Digit1, relayData);
			}
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_SET);
			break;

			case 2:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_DIGIT2) == FLASH_DIGIT2))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.Digit2, relayData);
			}
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_SET);
			break;

			case 3:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_DIGIT3) == FLASH_DIGIT3))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.Digit3, relayData);
			}
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_SET);
			break;

			case 4:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_STATE) == FLASH_STATE))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.LedState, relayData);
			}
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_SET);
			break;

			case 5:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_OHRANA) == FLASH_OHRANA))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.LedOhrana, relayData);
			}
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_SET);
			break;

			default:
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_CLR);
			break;
		}
		if(ledDisplay.stateInd)				ledDisplay.stateInd++;
		if(ledDisplay.stateInd > IND_DIGIT)	ledDisplay.stateInd = 1;
		ledDisplay.pulseCnt = IND_PULSE_LEN;
		if(ledDisplay.periodFlash)			ledDisplay.periodFlash--;
		else
		{
			ledDisplay.periodFlash = FLASH_PERIOD;
			ledDisplay.flagFlash++;
		}
	}
}

uint8_t LoadData(uint8_t led, uint8_t rel)
{
	uint8_t ci, rez;

	rez = 0;
	OE_IN_LOAD();
	OE_LED_UNSET();
	OE_OUT_UNSET();
	for(ci=0; ci<8; ci++)
	{
		rez = rez << 1;			// input, 597
		if(HAL_GPIO_ReadPin(SDIN_GPIO_Port, SDIN_Pin))
		{
			rez |= 0x01;
		}
		if (led & 0x80)  SDLED_SET();
		else             SDLED_CLR();
		if (rel & 0x80)  SDOUT_SET();
		else             SDOUT_CLR();
		SCLOCK();
		led = led << 1;			// output, 595
		rel = rel << 1;			// output, 595
	}
	SLATCH();
	OE_LED_SET();
	OE_OUT_SET();
	return rez;
}

void ReadKeys(void)
{
	switch(Keyboard())
	{
	// short press
	    case 0x01:	// short up
    	keyboard = 0x01;
    	keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
    		cntDisplayAvary	= GetCntDisplayAvary(cntDisplayAvary, 1);
    		DisplayAvary(cntDisplayAvary);	// 1-increment
    		break;

    		case RUN_MENU:
    		if(Menu.RunMenu >= RUN_MENU_MIN)		Menu.RunMenu--;
    		if(Menu.RunMenu < RUN_MENU_MIN)			Menu.RunMenu = RUN_MENU_MAX;
    		timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_ACTIVE:
    			break;

    			case RUN_SET_UST:
    			ClockRAM.config.T31++;
    			if(ClockRAM.config.T31 > T_PODACHI_MAX)		ClockRAM.config.T31 = T_PODACHI_MAX;
    			break;

    			case RUN_SEL_PUMP:
    			ControlPumps.selPump = 0;
    			break;

    			case RUN_SEL_MODE:
    			ControlPumps.selMode = 0;	// set manual pump mode
    			break;

    			case RUN_PUMP_1:
    			if(((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0) && (BIT_TEST(ClockRAM.config.dc, 4) == 0))
    			{
    				Menu.Param++;
    			}
       			Menu.Param &= 0x0001;
       			break;

    			case RUN_PUMP_2:
    			if(((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0) && (BIT_TEST(ClockRAM.config.dc, 3) == 0))
    			{
    				Menu.Param++;
    			}
    			Menu.Param &= 0x0001;
    			break;

    			default:
    			break;
    		}
    		timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;

    		case CURR_SERVICE:
       		if(Menu.ServiceMenu >= SERVICE_MIN)		Menu.ServiceMenu--;
       		if(Menu.ServiceMenu < SERVICE_MIN)		Menu.ServiceMenu = SERVICE_MAX;
    		timeoutService = ClockRAM.config.t63;
    		break;

    		case SUB_MENU_SERVICE:
       		switch(Menu.ServiceMenu)
       		{
				case SERVICE_UZO:  // outputs
				case SERVICE_N1:
				case SERVICE_N2:
				case SERVICE_AVR:
				case SERVICE_SZO:
				case SERVICE_RZV:
	       		Menu.Param = 1;
	       		break;

       			default:
       			break;
       		}
       		timeoutService = ClockRAM.config.t63;
    		break;

       		default:
       		break;
    	}
		break;

		case 0x02:	// short down
		keyboard = 0x02;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
        	cntDisplayAvary	= GetCntDisplayAvary(cntDisplayAvary, 2);
        	DisplayAvary(cntDisplayAvary);	// 2-decrement
    		break;

    		case RUN_MENU:
    		Menu.RunMenu++;
    		if(Menu.RunMenu > RUN_MENU_MAX)			Menu.RunMenu = RUN_MENU_MIN;
    		timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_ACTIVE:
    			break;

    			case RUN_SET_UST:
    			if(ClockRAM.config.T31 > T_PODACHI_MIN)		ClockRAM.config.T31--;
    			if(ClockRAM.config.T31 < T_PODACHI_MIN)		ClockRAM.config.T31 = T_PODACHI_MIN;
    			break;

    			case RUN_SEL_PUMP:
    			ControlPumps.selPump = 1;
    			break;

    			case RUN_SEL_MODE:
    			ControlPumps.selMode = 1;	// automatic mode
    			break;

    			case RUN_PUMP_1:
       			if(((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0) && (BIT_TEST(ClockRAM.config.dc, 4) == 0))
       			{
       				Menu.Param++;
       			}
       			Menu.Param &= 0x0001;
       			break;

    			case RUN_PUMP_2:
    			if(((ClockRAM.config.rrk & RRK_MODE_PUMP_MASK) == 0) && (BIT_TEST(ClockRAM.config.dc, 3) == 0))
    			{
    				Menu.Param++;
    			}
    			Menu.Param &= 0x0001;
    			break;

    			default:
    			break;
    		}
    		timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;

    		case CURR_SERVICE:
        	Menu.ServiceMenu++;
        	if(Menu.ServiceMenu > SERVICE_MAX)		Menu.ServiceMenu = SERVICE_MIN;
    		timeoutService = ClockRAM.config.t63;
    		break;

    		case SUB_MENU_SERVICE:
    		switch(Menu.ServiceMenu)
    		{
				case SERVICE_UZO:  // outputs
				case SERVICE_N1:
				case SERVICE_N2:
				case SERVICE_AVR:
				case SERVICE_SZO:
				case SERVICE_RZV:
    			Menu.Param = 0;
    			break;

				default:
				break;
    		}
    		timeoutService = ClockRAM.config.t63;
    		break;

    		default:
    		break;
    	}
		break;

		case 0x03:		// short enter
		keyboard = 0x04;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		default:
    		case CURR_AUTH:
    		break;

    		case CURR_SERVICE:
    		break;

    		case SUB_MENU_SERVICE:
    		Menu.CurrMenu = CURR_SERVICE;
    		timeoutService = ClockRAM.config.t63;
    		break;

    		case SUB_RUN_MENU:
       		switch(Menu.RunMenu)
       		{
       			case RUN_SEL_PUMP:
       			ControlPumps.statePumps = CHANGE_PRIMARY_PUMP;
       			if(ControlPumps.selPump)	BIT_SET(ClockRAM.config.dc, 2);
       			else						BIT_CLR(ClockRAM.config.dc, 2);
       			BIT_CLR(ClockRAM.config.wrn, 6); // clear warning pump DA13
       			BIT_CLR(ClockRAM.config.alr, 2); // clear avary pump DA13
       			break;

       			case RUN_SEL_MODE:
       			if(ControlPumps.selMode)
       			{ // automatic mode
       				BIT_SET(ClockRAM.config.rrk, 0);
       				BIT_CLR(ClockRAM.config.wrn, 6); // clear warning pump DA13
       				BIT_CLR(ClockRAM.config.alr, 2); // clear avary pump DA13
       				ControlPumps.statePumps = CHANGE_PRIMARY_PUMP;
       			}
       			else
       			{ // manual mode
       				BIT_CLR(ClockRAM.config.rrk, 0);
       				BIT_CLR(ClockRAM.config.wrn, 6); // clear warning pump DA13
       				BIT_CLR(ClockRAM.config.alr, 2); // clear avary pump DA13
       			}
        		break;

        		case RUN_PUMP_1:
        		if(BIT_TEST(ClockRAM.config.dc, 4) == 0)
        		{ // if pump 2 is off
        			if(Menu.Param)
					{ // set pump 1 on
						BIT_SET(ClockRAM.config.dc, 3);		// Pump1 ON;
					}
					else
					{
						BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
						BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
					}
        		}
        		break;

        		case RUN_PUMP_2:
           		if(BIT_TEST(ClockRAM.config.dc, 3) == 0)
           		{ // if pump 1 is off
           			if(Menu.Param)
           			{ // set pump 2 on
           				BIT_SET(ClockRAM.config.dc, 4);		// Pump2 ON;
           			}
					else
					{	// Pump1 OFF;	// Pump2 OFF;
						BIT_CLR(ClockRAM.config.dc, 3);	// Pump1 OFF;
						BIT_CLR(ClockRAM.config.dc, 4);	// Pump2 OFF;
					}
           		}
        		break;

        		default:
        		break;
        	}
        	Menu.CurrMenu = RUN_MENU;
        	timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;
    	}
		break;

		case 0x04:		// short escape
		keyboard = 0x08;
		keyPress = 0;
		beepPick.State = 2;		// beep off
		if(ClockRAM.config.alr == 0)
		{	// reset avary memory
			BIT_CLR(ClockRAM.config.alrMemory, cntDisplayAvary);
		}
		if(ohrState == OHR_ALARM)
		{
			Sygnalization(SYGNAL_MODE_LEDR1_BUZ0_LEDSZOI5_BUZSZO0);		// secure.c
		}
		break;

		// long press
		case 0x11:		// long up
		keyboard = 0x11;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		default:
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
    		break;

    		case CURR_SERVICE:
    		Menu.CurrMenu = SUB_MENU_SERVICE;
    		Menu.Param = 0;
    		timeoutService = ClockRAM.config.t63;
    		break;

    		case RUN_MENU:
    		Menu.CurrMenu = SUB_RUN_MENU;
    		timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_SET_UST:
    			if(cntLongPress == 0)
    			{
    				cntLongPress = COUNT_AUTO_PUSH;
        			ClockRAM.config.T31++;
        			if(ClockRAM.config.T31 > T_PODACHI_MAX)		ClockRAM.config.T31 = T_PODACHI_MAX;
    			}
    			break;

       			default:
        		break;
        	}
        	timeoutAutomat = ClockRAM.config.timeout_automat;
        	break;

    	}
		break;

		case 0x12:		// long down
		keyboard = 0x22;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		default:
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
    		break;

    		case CURR_SERVICE:
    		Menu.CurrMenu = SUB_MENU_SERVICE;
    		Menu.Param = 0;
    		timeoutService = ClockRAM.config.t63;
    		break;

    		case RUN_MENU:
    		Menu.CurrMenu = SUB_RUN_MENU;
     		timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_SET_UST:
    			if(cntLongPress == 0)
    			{
    				cntLongPress = COUNT_AUTO_PUSH;
    				ClockRAM.config.T31--;
    				if(ClockRAM.config.T31 < T_PODACHI_MIN)		ClockRAM.config.T31 = T_PODACHI_MIN;
    			}
     			break;

       			default:
        		break;
        	}
        	timeoutAutomat = ClockRAM.config.timeout_automat;
        	break;
    	}
		break;

		case 0x13:	// long enter
		keyboard = 0x44;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:
    		Menu.CurrMenu = RUN_MENU;
    		Menu.RunMenu = RUN_MENU_MIN;
    		BIT_SET(ClockRAM.config.dc, 0);
    		ClockRAM.config.state_BU103 = GO_WORK_STATE;
    		timeoutAutomat = ClockRAM.config.timeout_automat;
    		break;

    		case RUN_MENU:
    		Menu.CurrMenu = CURR_AUTH;
    		if(ClockRAM.config.lsa)		Room.State = ROOM_OFF;		// off all RegKaskad();
    		else						Room.State = ROOM_WAIT;
    		BIT_CLR(ClockRAM.config.dc, 0);
    		ClockRAM.config.state_BU103 = GO_WAIT_STATE;
    		break;

    		case AVARY_MENU:
    		Menu.CurrMenu = CURR_AUTH;
    		if(ClockRAM.config.lsa)		Room.State = ROOM_OFF;		// off all RegKaskad();
    		else						Room.State = ROOM_WAIT;
    		ClockRAM.config.state_BU103 = GO_WAIT_STATE;
    		break;

    		case CURR_SERVICE:
    		Menu.CurrMenu = CURR_AUTH;
    		exitService();
    		break;

    		case SUB_MENU_SERVICE:
    		break;
    	}
		break;

		case 0x14:	// long escape
		keyboard = 0x88;
		keyPress = 0;

		if(ClockRAM.config.alr == 0)
		{	// reset avary memory
			ClockRAM.config.alrMemory = 0;
		}
		break;

		case 0x15:	// long up+dn+ent
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:
    		Menu.CurrMenu = IN_TO_SERVICE;
    		rm_counter = 0;
    		break;

    		case CURR_SERVICE:
    		break;

    		case SUB_MENU_SERVICE:
    		break;
    	}
		break;

		default:
		break;
	}
}

uint16_t Keyboard(void)
{ //0-no press, 1-press up, 2-press down, 3-press escape, 4-press enter
	uint16_t keyCode;

	keyCode = 0;
	keyNow = (GPIOA->IDR) & KEY_RELEASED;
	if(keyNow != keyOld)
	{
		if(keyNow == KEY_RELEASED)
		{ // all keys released
			cntPress = 0;
			cntLongPress = 0;
			if(keyPress)			keyCode = keyPress;
		}
		else
		{
			cntPress = TIME_PRESS_DLY;
			cntLongPress = LONG_PRESS_DLY;
			keyPress = 0;
		}
		keyOld = keyNow;
	}
	else
	{
		if(cntPress == 1)
		{
			cntPress = 0;
			if(keyNow == KEY_UP_PRESS)
			{ // key up pressed
				keyPress = 0x01;
			}
			if(keyNow == KEY_DN_PRESS)
			{ // key down pressed
				keyPress = 0x02;
			}
			if(keyNow == KEY_ESC_PRESS)
			{ // key escape pressed
				keyPress = 0x03;
			}
			if(keyNow == KEY_ENT_PRESS)
			{ // key enter pressed
				keyPress = 0x04;
			}
			Beep(BEEP_PULSE_1);
		}
		if(cntLongPress == 1)
		{
			cntLongPress = 0;
			if(keyNow == KEY_UP_PRESS)
			{ // key up pressed
				keyCode = 0x11;
			}
			if(keyNow == KEY_DN_PRESS)
			{ // key down pressed
				keyCode = 0x12;
			}
			if(keyNow == KEY_ESC_PRESS)
			{ // key escape pressed
				keyCode = 0x13;
			}
			if(keyNow == KEY_ENT_PRESS)
			{ // key enter pressed
				keyCode = 0x14;
			}
			if(keyNow == KEY_UP_DN_ENT_PRESS)
			{ // key up, down, enter pressed
				if(BIT_TEST(ClockRAM.config.sro, 1))
				{ // snyato s ohrany
					keyCode = 0x15;
				}
			}
			if(Menu.RunMenu != RUN_SET_UST)		Beep(BEEP_PULSE_1);
		}
	}
	if(cntPress)			cntPress--;
	if(cntLongPress)		cntLongPress--;
	return keyCode;
}

uint8_t Decode(uint8_t val)
{ // fagc  .deb      1010 0110
	uint8_t rez;

	switch(val)
	{
		case 0x30:
		rez = 0xD7;			// 0
		break;

		case 0x31:
		rez = 0x11;			// 1
		break;

		case 0x32:
		rez = 0x67;			// 2
		break;

		case 0x33:
		rez = 0x75;			// 3
		break;

		case 0x34:
		rez = 0xB1;			// 4
		break;

		case 's':
		case 'S':
		case 0x35:
		rez = 0xF4;			// 5, S
		break;

		case 0x36:
		rez = 0xF6;			// 6
		break;

		case 0x37:
		rez = 0x51;			// 7
		break;

		case 0x38:
		rez = 0xF7;			// 8
		break;

		case 0x39:
		rez = 0xF5;			// 9
		break;

		case 0x20:
		rez = DIGIT_OFF;	// space
		break;

		case '-':
		rez = 0x20;			// -
		break;

		case '_':
		rez = 0x04;			// _
		break;

		case 'a':
		case 'A':
		rez = 0xF3;			// A
		break;

		case 'b':
		case 'B':
		rez = 0xB6;			// b
		break;

		case 'c':
		case 'C':
		rez = 0xC6;			// C
		break;

		case 'd':
		case 'D':
		rez = 0x37;			// d
		break;

		case 'e':
		case 'E':
		rez = 0xE6;			// E
		break;

		case 'f':
		case 'F':
		rez = 0xE2;			// F
		break;

		case 'h':
		rez = 0xB2;			// h
		break;

		case 'H':
		rez = 0xB3;			// H
		break;

		case 'i':
		case 'I':
		rez = 0x02;			// i
		break;

		case 'n':
		case 'N':
		rez = 0x32;			// n
		break;

		case 'o':
		case 'O':
		rez = 0x36;			// o
		break;

		case 'p':
		case 'P':
		rez = 0xE3;			// P
		break;

		case 'r':
		case 'R':
		rez = 0x22;			// r
		break;

		case 't':
		case 'T':
		rez = 0xA6;			// t
		break;

		case 'u':
		rez = 0x16;			// u
		break;

		case 'U':
		rez = 0x97;			// U
		break;

		case 'y':
		case 'Y':
		rez = 0xB5;			// Y
		break;

		case 'z':
		rez = 0x32;			// п
		break;

		case 'Z':
		rez = 0xD3;			// П
		break;

		default:
		rez = DIGIT_OFF;
		break;
	}
	return rez;
}

int ConvTemperature(int vadc)
{
	double tmp;
	int rez;

	if (vadc >= 1700)
	{	// y(x)=x/10.7-119
		tmp = vadc / 10.7;
		rez = (int)(tmp - 119);
	}
	if ((vadc < 1700) && (vadc > 1200))
	{	// y(x)=x/9.8-135
		tmp = vadc / 9.8;
		rez = (int)(tmp - 135);
	}
	if (vadc <= 1200)
	{	// y(x)=x/8.6-152
		tmp = vadc / 8.6;
		rez = (int)(tmp - 152);
	}
	return rez;
}

void Meassure(void)
{
	int ci;
	uint32_t tmp0, tmp1, tmp2, tmp3, tmp4;
	double rez;

	Single();
	if(countSample > 6)
	{ // one cycle measuring
		UIN[countADC] = ADC_result[0];
		NTC_Hot[countADC] = ADC_result[1];
		NTC_Cold[countADC] = ADC_result[2];
		NTC_Out[countADC] = ADC_result[3];
		NTC_In[countADC] = ADC_result[4];
		countADC++;
		if(countADC > (ADC_BUFF_LEN-2))
		{
			countADC = 1;
			trueValue++;
			if(trueValue > 100)		trueValue = 100;
		}
		tmp0 = 0;
		tmp1 = 0;
		tmp2 = 0;
		tmp3 = 0;
		tmp4 = 0;
		for(ci = 1; ci < (ADC_BUFF_LEN-1); ci++)
		{
			tmp0 += UIN[ci];
			tmp1 += NTC_Hot[ci];
			tmp2 += NTC_Cold[ci];
			tmp3 += NTC_Out[ci];
			tmp4 += NTC_In[ci];
		}
		NTC_Hot[0] = tmp1 >> 4;
		NTC_Cold[0] = tmp2 >> 4;
		NTC_Out[0] = tmp3 >> 4;
		NTC_In[0] = tmp4 >> 4;
		tmp1 = 0;
		tmp2 = 0;
		tmp3 = 0;
		tmp4 = 0;
		for(ci = 1; ci < (ADC_BUFF_LEN-1); ci++)
		{
			if(abs(NTC_Hot[ci] - NTC_Hot[0]) < ADC_FILTER_VAL)		tmp1 += NTC_Hot[ci];
			else													tmp1 += NTC_Hot[0];
			if(abs(NTC_Cold[ci] - NTC_Cold[0]) < ADC_FILTER_VAL)	tmp2 += NTC_Cold[ci];
			else													tmp2 += NTC_Cold[0];
			if(abs(NTC_Out[ci] - NTC_Out[0]) < ADC_FILTER_VAL)		tmp3 += NTC_Out[ci];
			else													tmp3 += NTC_Out[0];
			if(abs(NTC_In[ci] - NTC_In[0]) < ADC_FILTER_VAL)		tmp4 += NTC_In[ci];
			else													tmp4 += NTC_In[0];
		}
		UIN[0] = tmp0 >> 4;
		rez = ADC_KU_12 * UIN[0];
		rez += 300;				// +300 mV compensation shottky diode
		rez = rez / 100;
		U_input = (uint16_t)rez;
		NTC_Hot[0] = tmp1 >> 4;
		rez = NTC_Hot[0] * ADC_KU_3;
		ci = ConvTemperature((int)rez);
		T_hot = TestNTCsensor(ci, 11);		// DT11
		NTC_Cold[0] = tmp2 >> 4;
		rez = NTC_Cold[0] * ADC_KU_3;
		ci = ConvTemperature((int)rez);
		T_cold = TestNTCsensor(ci, 12);		// DT12
		NTC_Out[0] = tmp3 >> 4;
		rez = NTC_Out[0] * ADC_KU_3;
		ci = ConvTemperature((int)rez);
		T_out = TestNTCsensor(ci, 13);		// DT13
		NTC_In[0] = tmp4 >> 4;
		rez = NTC_In[0] * ADC_KU_3;
		ci = ConvTemperature((int)rez);
		T_in = TestNTCsensor(ci, 14);		// DT14
	}
}

void OutputToRegister(void)
{
	if(BIT_TEST(relayData, RELAY_PUMP1))	BIT_SET(DIO, 9);
	else									BIT_CLR(DIO, 9);
	if(BIT_TEST(relayData, RELAY_PUMP2))	BIT_SET(DIO, 10);
	else									BIT_CLR(DIO, 10);
	if(BIT_TEST(relayData, RELAY_SHNEK))	BIT_SET(DIO, 8);
	else									BIT_CLR(DIO, 8);
	if(BIT_TEST(relayData, RELAY_ALARM))	BIT_SET(DIO, 11);
	else									BIT_CLR(DIO, 11);
	if(BIT_TEST(relayData, RELAY_SZO_BUZ))	BIT_SET(DIO, 12);
	else									BIT_CLR(DIO, 12);
//	if(BIT_TEST(relayData, RELAY_SZO_LED))	BIT_SET(DIO, 12);
//	else									BIT_CLR(DIO, 12);
	if(BIT_TEST(relayData, RELAY_REZERV))	BIT_SET(DIO, 13);
	else									BIT_CLR(DIO, 13);
}

int TestNTCsensor(int val, uint16_t nbit)
{
	if(trueValue > TRUE_VALUE_DELAY)
	{
		switch(nbit)
		{
			case 11:	// DT11
			if(val > (int16_t)ClockRAM.config.T43)
			{
				BIT_SET(tempDIO, 0);
				if(BIT_TEST(ClockRAM.config.cfg, 3))
				{ // scenary 1
					val = SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_DT1];
				}
			}
			else									BIT_CLR(tempDIO, 0);
			if(val < (int16_t)ClockRAM.config.T44)
			{
				BIT_SET(tempDIO, 1);
				if(BIT_TEST(ClockRAM.config.cfg, 3))
				{ // scenary 1
					val = SelUnit(Room.kaskad[Room.CurrUnit])->ba[ADDR_POINT_DT1];
				}
			}
			else									BIT_CLR(tempDIO, 1);
			break;

			case 12:	// DT12
			if(val > (int16_t)ClockRAM.config.T45)	BIT_SET(ClockRAM.config.wrn, 0);
			else									BIT_CLR(ClockRAM.config.wrn, 0);
			if(val < (int16_t)ClockRAM.config.T46)	BIT_SET(ClockRAM.config.wrn, 1);
			else									BIT_CLR(ClockRAM.config.wrn, 1);
			break;

			case 13:	// DT13
			if(val > (int16_t)ClockRAM.config.T45)	BIT_SET(ClockRAM.config.wrn, 2);
			else									BIT_CLR(ClockRAM.config.wrn, 2);
			if(val < (int16_t)ClockRAM.config.T46)	BIT_SET(ClockRAM.config.wrn, 3);
			else									BIT_CLR(ClockRAM.config.wrn, 3);
			break;

			case 14:	// DT14
			if(val > (int16_t)ClockRAM.config.T45)	BIT_SET(ClockRAM.config.wrn, 4);
			else									BIT_CLR(ClockRAM.config.wrn, 4);
			if(val < (int16_t)ClockRAM.config.T46)	BIT_SET(ClockRAM.config.wrn, 5);
			else									BIT_CLR(ClockRAM.config.wrn, 5);
			break;

			default:
			break;
		}
	}
	return val;
}

void ResetPumpsTimers(void)
{
	Pump1.cntTimePump = 0;
	Pump1.workTimePump = 0;
	Pump2.cntTimePump = 0;
	Pump2.workTimePump = 0;
#ifdef _AUTOMAT_OUTPUT_UART
	if(log_debug)
	{
		Println(&huart1, "\nreset_pumps_timers");
	}
#endif
}

void ReadEEtoRAM(uint32_t addr, uint8_t *buf, uint16_t len)
{
#ifdef _MEMORY_24_SERIES
	HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, len, TIMEOUT_I2C);
#endif

#ifdef _MEMORY_25_SERIES
	at25df_read(addr, buf, len);
#endif
}

void WriteRAMtoEE(uint32_t addr, uint8_t *buf, uint16_t len)
{
#ifdef _MEMORY_24_SERIES
	if(len <= 64)
	{
		HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, len, TIMEOUT_I2C);
		HAL_Delay(TIMEOUT_I2C);
	}
	else if((len > 64) && (len <= 128))
	{
		HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, 64, TIMEOUT_I2C);
		HAL_Delay(TIMEOUT_I2C);
		len -= 64;
		buf += 64;
		HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, len, TIMEOUT_I2C);
		HAL_Delay(TIMEOUT_I2C);
	}
#endif

#ifdef _MEMORY_25_SERIES
//	sectorUnprotect(START_ADDR);
	at25df_eraseSector(START_ADDR);
	at25df_write(addr, buf, len);
#endif
}

void CompareEEpromRAM(void)
{
#ifdef _MEMORY_24_SERIES

	uint8_t val[6];

	memset(val, 0, sizeof(val));
	HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, cntEeRamAddr, I2C_MEMADD_SIZE_16BIT, val, 4, TIMEOUT_I2C);
	if(val[0] != ClockRAM.data8[cntEeRamAddr-START_ADDR])
	{
		val[0] = ClockRAM.data8[cntEeRamAddr-START_ADDR];
		HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, cntEeRamAddr, I2C_MEMADD_SIZE_16BIT, val, 1, TIMEOUT_I2C);
//		HAL_Delay(TIMEOUT_I2C);
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\neeprom_24 [");
			itoa(cntEeRamAddr, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, "] = ");
			itoa(val[0], buff, 10);
			Println(&huart1, buff);
		}
#endif
	}
#endif

#ifdef _MEMORY_25_SERIES

	uint8_t  buff_at25df[RAM_CONFIG_LEN_BYTES];

	at25df_read(START_ADDR, buff_at25df, RAM_CONFIG_LEN_BYTES);
	if(buff_at25df[cntEeRamAddr-START_ADDR] != ClockRAM.data8[cntEeRamAddr-START_ADDR])
	{
		RefreshEEpromData();
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println(&huart1, "\neeprom_25 [0x");
			itoa(cntEeRamAddr, buff, 16);
			Println(&huart1, buff);
			Println(&huart1, "] = ");
			itoa(buff_at25df[cntEeRamAddr-START_ADDR], buff, 10);
			Println(&huart1, buff);
		}
#endif
	}
#endif
	cntEeRamAddr++;
	if(cntEeRamAddr > (RAM_CONFIG_LEN_BYTES+START_ADDR))	cntEeRamAddr = START_ADDR;
}

void Beep(uint8_t pulse)
{
	if(beepPick.State)	return;
	switch(pulse)
	{
		case BEEP_PULSE_1:		// short beep
		beepPick.Lengh = BEEP_SHORT;
		beepPick.State = 1;
		break;

		case BEEP_PULSE_2:		// middle beep
		beepPick.Lengh = BEEP_MIDLE;
		beepPick.State = 1;
		break;

		case BEEP_PULSE_3:		// long beep
		beepPick.Lengh = BEEP_LONG;
		beepPick.State = 1;
		break;

		case BEEP_PULSE_4:
		beepPick.Lengh = BEEP_LONG;
		beepPick.cnt = 0;
		beepPick.State = 3;
		break;

		case BEEP_PULSE_5:
		beepPick.Lengh = BEEP_LONG;
		beepPick.cnt = 5;
		beepPick.State = 16;
		break;

		default:
		beepPick.State = 2;		// beep off
		break;
	}
}

void BeepRun(void)
{
	if(ohrBuzzerFlags.inUse == 1)
	{
		beepPick.State = 0;
		return;
	}
	switch(beepPick.State)
	{
	case 1:
		if(beepPick.Lengh)
		{
			Buzzer(BUZZER_PIN_ON);
			beepPick.Lengh--;
		}
		else				beepPick.State++;
		break;

	case 2:
		Buzzer(BUZZER_PIN_OFF);
		beepPick.State = 0;
		break;

	case 3:
		beepPick.Lengh = BEEP_LONG;
		beepPick.State++;
		break;

	case 4:		// 1-st pulse
		Buzzer(BUZZER_PIN_ON);
		if(beepPick.Lengh)	beepPick.Lengh--;
		else				beepPick.State++;
		break;

	case 5:
		beepPick.Pause = BEEP_PAUSE;
		beepPick.State++;
		break;

	case 6:
		Buzzer(BUZZER_PIN_OFF);
		if(beepPick.Pause)	beepPick.Pause--;
		else				beepPick.State++;
		break;

	case 7:
		beepPick.Lengh = BEEP_LONG;
		beepPick.State++;
		break;

	case 8:		// 2-st pulse
		Buzzer(BUZZER_PIN_ON);
		if(beepPick.Lengh)	beepPick.Lengh--;
		else				beepPick.State++;
		break;

	case 9:
		beepPick.Pause = BEEP_PAUSE;
		beepPick.State++;
		break;

	case 10:
		Buzzer(BUZZER_PIN_OFF);
		if(beepPick.Pause)	beepPick.Pause--;
		else				beepPick.State++;
		break;

	case 11:
		beepPick.Lengh = BEEP_LONG;
		beepPick.State++;
		break;

	case 12:		// 3-st pulse
		Buzzer(BUZZER_PIN_ON);
		if(beepPick.Lengh)	beepPick.Lengh--;
		else				beepPick.State++;
		break;

	case 13:
		beepPick.Pause = BEEP_PAUSE;
		beepPick.State++;
		break;

	case 14:
		Buzzer(BUZZER_PIN_OFF);
		if(beepPick.cnt == 0)
		{
			if(beepPick.Pause)	beepPick.Pause--;
			else				beepPick.State++;
		}
		else if(beepPick.cnt == 1)
		{		// end series
			beepPick.Pause = 0;
			beepPick.State = 2;
		}
		else if(beepPick.cnt > 1)
		{		// next series
			beepPick.Pause = BEEP_SERIES_PAUSE;
			beepPick.State = 16;
		}
		if(beepPick.cnt)		beepPick.cnt--;
		break;

	case 15:
		beepPick.State = 0;
		break;

	case 16:
		if(beepPick.Pause)	beepPick.Pause--;
		else				beepPick.State = 3;
		break;

	case 0:
	default:
		break;
	}
}

void exitService(void)
{
	Relays(RELAY_REZERV, 0);
	Relays(RELAY_SZO_LED, 0);
	Relays(RELAY_SZO_BUZ, 0);
	Relays(RELAY_ALARM, 0);
	Relays(RELAY_SHNEK, 0);
	Relays(RELAY_PUMP2, 0);
	Relays(RELAY_PUMP1, 0);
	timeoutService = 0;
}

void Buzzer(int state)
{
	if(state == BUZZER_PIN_ON)
	{
		HAL_GPIO_WritePin(BUZ_GPIO_Port, BUZ_Pin, BUZZER_PIN_ON); // buzzer on
	}
	else
	{
		HAL_GPIO_WritePin(BUZ_GPIO_Port, BUZ_Pin, BUZZER_PIN_OFF); // buzzer off
	}
}

void PrintTick(void)
{ // send socond tick
	char str[16];

	str[0] = '\0';
	strcat(str, "\ntick: ");
	itoa(secLogCnt, buff, 10);
	strcat(str, buff);
	HAL_UART_Transmit(&huart1, (uint8_t *) str, strlen(str), UART_TIMEOUT);
}

void Println(UART_HandleTypeDef *huart, char _out[])
{
	HAL_UART_Transmit(huart, (uint8_t *) _out, strlen(_out), UART_TIMEOUT);
}


