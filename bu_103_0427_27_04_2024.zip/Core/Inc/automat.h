/*
 * automat.h
 *
 *  Created on: 25 февр. 2023 г.
 *      Author: vitaly
 */

#ifndef INC_AUTOMAT_H_
#define INC_AUTOMAT_H_

#define    _AUTOMAT_OUTPUT_UART

//#define		_MEMORY_25_SERIES		// for save local parameters
#define		_MEMORY_24_SERIES		// for save local parameters

#define		CURRENT_VERSION		    427		//  27/04/2024

#define		RAM_CONFIG_LEN_BYTES	120	// 120 bytes -> 60 words,

#define		THRESHOLD_ANTIFROZE		5
#define		DELTA_ANTIFROZE			2

#define		TEMPERATURE_CORR		0		// +/- deltaT in room, T35
#define		TEMPERATURE_KOEF		10		// kurva 10 -> 1.0, whitout point, N34
#define		TEMPERATURE_MINIMAL		40		// pogoda temperature minimal value, T36

#define     LOW_TEMPERATURE			5
#define		LOW_HYSTERESIS			2
#define		T_PODACHI_DEF			50	// in (C)
#define		T_PODACHI_MAX			75	// in (C)
#define		T_PODACHI_MIN			40	// in (C)
#define		THRESHOLD_T42			95	// in (C)
#define		THRESHOLD_T41			80	// in (C)
#define		DELTA_T41				5	// in (C)
#define		DELTA_T42				5	// in (C)
#define		T_HOT_IND_MIN			0	// in (C)
#define		T_HOT_IND_MAX			100	// in (C)
#define		TIME_SHNEK_OFF			600		// in second
#define		TIME_SHNEK_ON			60		// in second

#define		PINTYPE_NO				0
#define		PINTYPE_NC				1
#define		DEFAULT_CFG_TYPE		0			// type only, NO
#define		DEFAULT_CFG_DELAY		0x0001		// delay only, 1 sec.
#define		DEFAULT_CFG_BITS		0x000F		// control bits

#define		DISPLAY_AVARY_MIN		0
#define		DISPLAY_AVARY_MAX		12

// menu constant
#define		CURR_AUTH				0x0
#define		RUN_MENU				0x01
#define		SUB_RUN_MENU			0x02
#define		AVARY_MENU				0x04
#define		CURR_SERVICE			0x40
#define		SUB_MENU_SERVICE		0x41
#define		IN_TO_SERVICE			0x80	// display "CEP" one second
// menu automat
#define		RUN_MENU_MIN			1
#define		RUN_ACTIVE				1
#define		RUN_SET_UST				2
#define		RUN_SEL_PUMP			3
#define		RUN_SEL_MODE			4
#define		RUN_PUMP_1				5
#define		RUN_PUMP_2				6
#define		RUN_MENU_MAX			6
/// menu service
#define		SERVICE_MIN				101
#define		SERVICE_UZO				101		// shnek - bit5
#define     SERVICE_N1				102		// nasos1 - bit7
#define		SERVICE_N2				103		// nasos2 - bit6
#define		SERVICE_AVR				104		// avaria - bit4
#define		SERVICE_SZO				105		// led - bit2; buzz - bit3
#define		SERVICE_RZV				106		// rezerv - bit1
#define		SERVICE_TPOD			107
#define		SERVICE_TOBR			108
#define		SERVICE_TOUT			109
#define		SERVICE_TIN				110
#define		SERVICE_UIN				111
#define		SERVICE_CC				112
#define		SERVICE_CO				113
#define		SERVICE_7C				114
#define		SERVICE_PV				115
#define		SERVICE_NV				116
#define		SERVICE_NN				117
#define		SERVICE_NC				118
#define		SERVICE_OC				119
#define		SERVICE_PC				120
#define		SERVICE_NR				121
#define		SERVICE_NZ				122
#define		SERVICE_MAX				122

#define		STOP_STATE				0	// after Initialize
#define		WAIT_STATE				1	// dejurny
#define		GO_WORK_STATE			2	//
#define		WORK_STATE				3
#define		GO_AVARY_STATE			4
#define		AVARY_STATE				5
#define		SERVICE_STATE			6	// service state
#define		GO_WAIT_STATE			7

#define		RRK_INIT				0 // 0x0001
#define		SRK_INIT				0x0001
#define		SRK_DEJURNY				0x0002
#define		SRK_WORK				0x0004
#define		SRK_SERVICE				0x0008
#define		SRK_ALARM				0x0010
#define		SRK_CONFIG				0x0020

#define		RRK_MODE_PUMP_MASK		0x0001
#define		DC_ACTIVE_PUMP_MASK		0x0004		// bit 2
#define		DC_PUMPS_MASK			0x0018		// bits 3, 4
#define		WRN_PUMP_AVARY_MASK		0x0040		// bit 6
#define		BA_AVARY_MASK_SCS_0		0x0CFF		// bit 0...7,10,11 select
#define		BA_AVARY_MASK_SCS_1		0x00FF		// bit 0...7 select

#define		WAIT_PUMP				0
#define		START_PRIMARY_PUMP		1
#define		TIMEOUT_PRIMARY			2
#define		PRIMARY_PUMP			3
#define		TIMER_CHANGE_PUMP		4
#define		CHANGE_PUMP				5
#define		ERROR_PRIMARY_PUMP		6
#define		TIMER_ERROR_PUMP		7
#define		TIMEOUT_REZERV			8
#define		REZERV_PUMP				9
#define		ALARM_PUMP				10
#define		CHANGE_PRIMARY_PUMP		11

#define		ZOLO_WAIT				0
#define		ZOLO_WAIT_DLY_OFF		1
#define		ZOLO_WAIT_DLY_ON		2
#define		ZOLO_RUN				1
#define		ZOLO_STOP				0

#define     PUMP_2_MASK				0x10	// bit 4
#define     PUMP_1_MASK				0x08	// bit 3
#define		PUMP_CFG_DELAY			3	 // in second
#define		PUMP_TIME_CHANGE		168	 // in hours
#define		PUMP_SWITCH_DELAY		5    // in seconds

#define		DA13_AVARY_MASK			0x08

#define     ALARM_ON				1
#define     ALARM_OFF				0

typedef struct
{
	uint8_t   RunMenu;			// automatic menu pointer
//	uint8_t   SubRunMenu;		//
	uint8_t   ServiceMenu;		// service menu pointer
	uint16_t  Param;
	uint8_t   CurrMenu;			// 0-no menu, 1,2-service menu, 3,4-run menu, 0x80-input to service menu
} main_menu_t;

main_menu_t		Menu;

typedef struct
{
	uint8_t  state;			// pin current state
	uint16_t delay;			// delay counter
	uint8_t	 type;			// input type, read from registers
} input_t;

input_t		DA11;
input_t		DA12;
input_t		DA13;
input_t		DA14;
input_t		DA15;	// sensor security
input_t		DA16;
input_t		DA17;
input_t		DA18;

typedef struct
{
	uint8_t  selMode;			// variable for select mode manual/automat pump in menu
	uint8_t  selPump;			// variable for select active pump in menu
	uint8_t  pumpDelay;			// change pump delay
	uint8_t  cntTimeDiff;		// time out DA13 avary
	uint8_t  statePumps;		// switch step pumps
	uint8_t  alrCnt;			// time for alr to alrMemory, PUMP_SWITCH_DELAY (5 sec.)
}control_pump_t;

control_pump_t  ControlPumps;

typedef struct
{
//	uint8_t  controlPump;		// 0-off pump, 1-on pump, 1-(ClockRAM.config.dc, 3), 2-(ClockRAM.config.dc, 4)
//	uint8_t  avaryPump;			// 0-good, 1-avary
	uint16_t cntTimePump;   	// in seconds
	uint16_t workTimePump;   	// in hours
} pump_t;

pump_t Pump1;	// (ClockRAM.config.dc, 3)
pump_t Pump2;	// (ClockRAM.config.dc, 4)

typedef struct 				// memory RAM in microcontroller
{	// RAM_CONFIG_LEN_BYTES = 120
	uint16_t  alr;						// 0_1, alarms
	uint16_t  alrMemory;				// 2_3,
	uint16_t  wrn;						// 4_5, warnings
	uint16_t  srk;						// 6_7, state BU103
	uint16_t  state_BU103;				// 8_9, current state BU103
	uint16_t  sro;						// 10_11, ohrana,
	uint16_t  sroMemory;				// 12_13, ohrana,
	uint16_t  srn;						// 14_15, state pump
	uint16_t  rrk;						// 16_17, pumpMode, 1-auto; 0-manual;
	uint16_t  dc;						// 18_19, state control security
	uint16_t  cfg;						// 20_21, bits options
	uint16_t  lsa;						// 22_23, used BA103
	uint16_t  lsb;						// 24_25, avary connections to BA103
	uint16_t  tdi;						// 26_27
	uint16_t  T31;						// 28_29, T_ust
	uint16_t  t33;						// 30_31, t shnek zolo time off
	uint16_t  t34;						// 32_33, t shnek zolo time on
	uint16_t  N34;						// 34_35, kryva, koeficient pogodnoi regulirovki
	uint16_t  T35;						// 36_37, +/- deltaT in room -10...+10
	uint16_t  t37;						// 38_39, timeout kaskad regul temperature, 5 min.
	uint16_t  t38;						// 40_41, timeout fog change unit, 24 hour
	uint16_t  T41;						// 42_43, threshold avary DA11 low
	uint16_t  T42;						// 44_45, threshold avary DA11 high
	uint16_t  T43;						// 46_47, threshold open DT11
	uint16_t  T44;						// 48_49, threshold short DT11
	uint16_t  T45;						// 50_51, threshold open DT12, DT13, DT14
	uint16_t  T46;						// 52_53, threshold short DT12, DT13, DT14
	uint16_t  T47;						// 54_55, threshold
	uint16_t  delta_T41;				// 56_57
	uint16_t  delta_T42;				// 58_59
	uint16_t  delta_T47;				// 60_61
	uint16_t  t54;						// 62, 63 digital input delay
	uint16_t  t63;						// 64, 65, timeout menu service
	uint16_t  timeout_automat;			// 66, 67, timeout menu service
	uint16_t  t71;						// 68, 69, AlarmParam1, 20 sec.
	uint16_t  t72;						// 70_71, AlarmParam2, 60 sec.
	uint16_t  N73;						// 72_73, AlarmParam3, 5 cycles
	uint16_t  version;					// 74_75, current version
	uint16_t  t81;						// 76_77, timeChange, time for change pump in automatic mode
	uint16_t  t82;						// 78_79, pumpDelay, delay for pump change, 5 sec.
	uint16_t  t83;						// 80_81, InputCfgDelay, avary delay, 3 sec.
	uint16_t  t11;						// 82_83, test line timeout
	uint16_t  AM;						// 84_85, address BU103, 1
	uint16_t  ipHi;						// 86,87
	uint16_t  ipLow;					// 88,89
	uint16_t  ipPort;					// 90,91
	uint16_t  serverHi;					// 92,93
	uint16_t  serverLow;				// 94,95
	uint16_t  maskHi;					// 96,97
	uint16_t  maskLow;					// 98,99
	uint16_t  gwHi;						// 100,101
	uint16_t  gwLow;					// 102,103
	uint16_t  mac2_3;					// 104,105
	uint16_t  mac4_5;					// 106,107
	uint16_t  T36;						// 108,109

	uint16_t  RoomState;			// state of boiler room
	uint16_t  statePumps;			// state pumps (primary/secondary) in automatic mode
	uint16_t  log_debug_state;		/// debug
	uint16_t  null;					//
} Registers_var;

union CLOCKRAM
{
	Registers_var		config;
	uint8_t				data8[RAM_CONFIG_LEN_BYTES];
} ClockRAM;

char 	 buff[8];
uint16_t ustPodachi;
uint16_t cntDisplayAvary;
uint8_t  indPoints;			// 0-no point, 1-display points
uint16_t T1;
uint16_t T2;
uint16_t T3;
uint16_t T4;
uint16_t ALR;				// ALR = ClockRAM.config.alr | ClockRAM.config.alrMemory;
uint16_t DIO;				// input/output state, i/o bits,  0-7bits DA1x sensors,
uint16_t tempDIO;			// 0-1bits DT11 sensors
uint16_t alarmState_old;
uint16_t warning_old;
int16_t  lsb_old;
uint16_t dc_old;

uint8_t  bu_state_old;		/// debug
uint16_t di_old;			/// debug
uint16_t alarm_old;			/// debug
uint16_t ustPodachi_old;	/// debug
uint8_t  log_debug;			/// debug

void InitAutomat(void);
void SetState(void);
void InitState(void);
void ReadEEtoRegisters(void);
void RefreshEEpromData(void);
void LoadSettings(void);
void SaveSettings(void);
void SetConfigDefault(void);
void RunMenu(void);
char* ToDisplay(int16_t);
void IndexingRegisters(void);
void InitInputs(void);
void TestInputs(void);
void InitD(input_t*, uint16_t, uint8_t);
void TestD(input_t*, uint16_t, uint16_t);
void SetAvary(void);
void AntiFroze(void);
void Warnings(void);
void AvaryDA11(void); // 1, APV
void AvaryDA12(void); // 2, ANV
void AvaryDA13(void); // 3, ANN
void AvaryDA14(void); // 4, ANS, net
void AvaryDA11DT11(void); // 5, NPV
void AvaryDT11DA11(void); // 6, NtP, 11, OtP, 12, ZtP
void AvaryDA16(void); // 7, APS
void AvaryDA17(void); // 8, ANP
void AvaryDA18(void); // 9, ANZ
void AvaryBA(void);  // 10, ABA
void DisplayAvary(uint16_t);
uint16_t GetCntDisplayAvary(uint16_t, uint8_t);
void InitPumps(void);
void Pump(void);
void WaitingMode(void);
uint8_t BitCalc(uint16_t);
void PogodaTemp(void);
void ZoloDel(void);
void RoomOff(void);

#endif /* INC_AUTOMAT_H_ */
