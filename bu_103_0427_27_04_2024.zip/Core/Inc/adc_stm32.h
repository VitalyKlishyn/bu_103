
ADC_HandleTypeDef hadc;

extern uint16_t countSample;
extern uint16_t ADC_result[6];

// ADC converting, (5^2+1^2+0.5^2)^0.5 ~ 5%, +-1.3 V
// 5%-рез.делитель, 1%-источник опорнрго нанряжения(питания), 0,5%-дискретность АЦП
// ADC-12 bit, Uref=3V3, K=4,681, R1=22k, R2=4k7, Skale=15,45V, ADC_KU=4096/Scale
#define ADC_KU_12			4.68		// Uizm = data * ADC_KU_12, Ubat, Uin
#define ADC_KU_3			0.8			// Uizm = data * ADC_KU_3, Uthemperature
#define U_REF_ADC			3300		// in mV

void adcInit(void);
uint16_t adcRead(void);
void Single(void);
