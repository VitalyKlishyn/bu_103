/*
 * secure.h
 *
 *  Created on: 6 дек. 2022 г.
 *      Author: vitaly
 */

#ifndef INC_SECURE_H_
#define INC_SECURE_H_

//#define   _SECURITY_OUTPUT_UART

#define LED_SZO_ON           1
#define LED_SZO_OFF		     0
#define LED_OHR_RED			 2
#define LED_OHR_GREEN        1
#define LED_OHR_OFF		     0
#define BUZZER_ON    	     1
#define BUZZER_OFF		     0
#define SENSOR_OHR_CLOSE     0
#define SENSOR_OHR_OPEN      !SENSOR_OHR_CLOSE
#define CONTROL_OHR_ACTIVE   0
#define CONTROL_OHR_OFF      !CONTROL_OHR_ACTIVE

#define LED_OHR_PIN			5		// DIG5_Pin, RED-0x02, GREEN-0x04

#define COUNT_LED_ON_P1			15		// 25*timebase = 250 mSec
#define COUNT_LED_OFF_P1		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_ON_P1		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_OFF_P1		15		// 25*timebase = 250 mSec
#define COUNT_PAUSE_P1			100		// 100*timebase = 1 Sec
#define COUNT_LED_ON_P2			15		// 25*timebase = 250 mSec
#define COUNT_LED_OFF_P2		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_ON_P2		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_OFF_P2		15		// 25*timebase = 250 mSec
#define COUNT_PAUSE_P2			100		// 100*timebase = 1 Sec
#define COUNT_CYCLES_P2			2000	// 20 Sec
#define DELTA_PAUSE_SHORT_P2 	6		// for 20 Sec, 50 mSec
#define COUNT_LED_ON_P3			7		// 7*timebase = 70 mSec
#define COUNT_BUZZER_ON_P3		10		// 10*timebase = 100 mSec
#define COUNT_LED_ON_P4			7		// 7*timebase = 70 mSec
#define COUNT_LED_OFF_P4		10		// 10*timebase = 100 mSec
#define COUNT_BUZZER_ON_P4		7		// 7*timebase = 70 mSec
#define COUNT_BUZZER_OFF_P4		10		// 10*timebase = 100 mSec
#define COUNT_LED_ON_P5			50		// 50*timebase = 500 mSec
#define COUNT_LED_OFF_P5		50		// 50*timebase = 500 mSec
#define COUNT_BUZZER_ON_P5		50		// 50*timebase = 500 mSec
#define COUNT_BUZZER_OFF_P5		50		// 50*timebase = 500 mSec
#define COUNT_TIMER_ALARM		60		// 60 Sec
#define ALARM_CYCLES_TRESHOLD	5		// 5 cycles of alarm
#define COUNT_WAIT_ALARM		20		// 20 Sec

#define SYGNAL_MODE_OFF									0
#define SYGNAL_MODE_LEDGI1_BUZI1_LEDSZOI1_BUZSZO0		5
#define SYGNAL_MODE_LEDGI1_BUZI1_LEDSZOI1_BUZSZOI3		10
#define SYGNAL_MODE_LEDG1_BUZ0_LEDSZO1_BUZSZO0			15
#define SYGNAL_MODE_LEDGI2_BUZI2_LEDSZOI2_BUZSZO0		20
#define SYGNAL_MODE_LED0_BUZ0_LEDSZO0_BUZSZOI4			25
#define SYGNAL_MODE_LEDR1_BUZ1_LEDSZOI5_BUZSZO1			30
#define SYGNAL_MODE_LEDR1_BUZ0_LEDSZOI5_BUZSZO0			35

#define ALWAYS_ON_OHR				1
#define ALWAYS_ON_GREEN				2
#define ALWAYS_ON_RED				3
#define PULSE_1_OHR					10
#define PULSE_2_OHR					20
#define PULSE_3_OHR					30
#define PULSE_4_OHR					40
#define PULSE_5_OHR					50

/// ohrState
#define OHR_ACTIVE					0		// охрана
#define OHR_GO_ACTIVE				1
#define OHR_WAIT_ALARM				2
#define OHR_GO_ALARM				3
#define OHR_ALARM					4
#define OHR_WAIT_SENSOR_CLOSE		5
#define OHR_WAIT_SENSOR_OPEN		6
#define OHR_GO_OFF					7
#define OHR_OFF						8		// снято с охраны

#define BEGIN_OFF					0
#define OHR_CONTROL_MASK			0x0020		// ClockRAM.config.dc, bit 5

uint8_t ohrState;
uint16_t delay_tmp;
uint16_t timerAlarm;
uint16_t waitAlarm;
uint16_t countAlarmCycles;
uint8_t hello[32];
uint8_t oldControlPin;

typedef struct
{
	bool inUse;	             // '1'-led or buzzer is active
	bool currentState;		 // current state led or buzzer
	bool pauseState;		 // '1'-in pause state
	bool changeOk;			 // modify parameter is success
	int  stepCount;          // running led or buzzer state, '0'-is stopped
	int  countCycles;        // counter cycles led or buzzer, '0'-stopped
	int  countPause;		 // time counter on, off
} ohrFlags;

ohrFlags ohrLedFlags;
ohrFlags ohrBuzzerFlags;
ohrFlags ohrLedSZOFlags;
ohrFlags ohrBuzzerSZOFlags;

/*
typedef struct
{
	uint16_t	di_bu103;
	uint16_t	dim_bu103;
	uint16_t	alarm_cmd;
	uint16_t	AlarmParam1;
	uint16_t	AlarmParam2;
	uint16_t	AlarmParam3;
	uint16_t	version;
} Registers_t;

Registers_t   registers;
*/
void Event_10ms(void);
void InitializeOhr(void);
void BeginOhr(void);
void RunOhr(void);
void Sygnalization(uint8_t);
bool ReadSensorOhr(void);
bool ReadControlOhr(void);
void ReadControlPin(void);
void SetLedSZO(uint8_t);
void SetBuzzerSZO(uint8_t);
void SetBuzzer(uint8_t);
void SetLed(uint8_t);

#endif /* INC_SECURE_H_ */
