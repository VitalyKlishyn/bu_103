/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
#define 	bool		 uint8_t
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SEC_Pin GPIO_PIN_13
#define SEC_GPIO_Port GPIOC
#define BUZ_Pin GPIO_PIN_14
#define BUZ_GPIO_Port GPIOC
#define DT11_TPOD_Pin GPIO_PIN_0
#define DT11_TPOD_GPIO_Port GPIOC
#define DT12_TOBR_Pin GPIO_PIN_1
#define DT12_TOBR_GPIO_Port GPIOC
#define DT13_TOUT_Pin GPIO_PIN_2
#define DT13_TOUT_GPIO_Port GPIOC
#define DT14_TIN_Pin GPIO_PIN_3
#define DT14_TIN_GPIO_Port GPIOC
#define KB_UP_Pin GPIO_PIN_0
#define KB_UP_GPIO_Port GPIOA
#define KB_DOWN_Pin GPIO_PIN_1
#define KB_DOWN_GPIO_Port GPIOA
#define KB_ENT_Pin GPIO_PIN_2
#define KB_ENT_GPIO_Port GPIOA
#define KB_ESC_Pin GPIO_PIN_3
#define KB_ESC_GPIO_Port GPIOA
#define ENC_CS_Pin GPIO_PIN_4
#define ENC_CS_GPIO_Port GPIOA
#define ENC_SCK_Pin GPIO_PIN_5
#define ENC_SCK_GPIO_Port GPIOA
#define ENC_MISO_Pin GPIO_PIN_6
#define ENC_MISO_GPIO_Port GPIOA
#define ENC_MOSI_Pin GPIO_PIN_7
#define ENC_MOSI_GPIO_Port GPIOA
#define ENC_RES_Pin GPIO_PIN_0
#define ENC_RES_GPIO_Port GPIOB
#define UIN_Pin GPIO_PIN_1
#define UIN_GPIO_Port GPIOB
#define INT_E_Pin GPIO_PIN_2
#define INT_E_GPIO_Port GPIOB
#define INT_E_EXTI_IRQn EXTI2_3_IRQn
#define DIG1_Pin GPIO_PIN_11
#define DIG1_GPIO_Port GPIOB
#define DIG2_Pin GPIO_PIN_12
#define DIG2_GPIO_Port GPIOB
#define DIG3_Pin GPIO_PIN_13
#define DIG3_GPIO_Port GPIOB
#define DIG4_Pin GPIO_PIN_14
#define DIG4_GPIO_Port GPIOB
#define DIG5_Pin GPIO_PIN_15
#define DIG5_GPIO_Port GPIOB
#define DIR3_Pin GPIO_PIN_6
#define DIR3_GPIO_Port GPIOC
#define CS_M_Pin GPIO_PIN_7
#define CS_M_GPIO_Port GPIOC
#define SCLK_Pin GPIO_PIN_15
#define SCLK_GPIO_Port GPIOA
#define SDIN_Pin GPIO_PIN_10
#define SDIN_GPIO_Port GPIOC
#define SDLED_Pin GPIO_PIN_11
#define SDLED_GPIO_Port GPIOC
#define SDOUT_Pin GPIO_PIN_12
#define SDOUT_GPIO_Port GPIOC
#define LATCH_Pin GPIO_PIN_2
#define LATCH_GPIO_Port GPIOD
#define OE_IN_Pin GPIO_PIN_3
#define OE_IN_GPIO_Port GPIOB
#define OE_LED_Pin GPIO_PIN_4
#define OE_LED_GPIO_Port GPIOB
#define OE_OUT_Pin GPIO_PIN_5
#define OE_OUT_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
#define		TIMEOUT_SPI		10

void Task_drivers(void);
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
