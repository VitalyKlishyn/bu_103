
#ifndef INC_AT25DF_H_
#define INC_AT25DF_H_

#define		AT25DF_MANUFACTURER_INFO_COMMAND 		0x9F
#define		AT25DF_STATUS_READ_COMMAND 		 		0x05
#define 	AT25DF_STATUS_WRITE_COMMAND		 		0x01
#define 	AT25DF_CHIP_ERASE_COMMAND 		 		0xC7
#define 	AT25DF_BLOCK_ERASE_4KB 			 		0x20
#define 	AT25DF_BLOCK_ERASE_32KB 		 		0x52
#define 	AT25DF_BLOCK_ERASE_64KB 		 		0xD8
#define 	AT25DF_WRITE_ENABLE_COMMAND 	 		0x06
#define 	AT25DF_WRITE_DISABLE_COMMAND 	 		0x04
#define 	AT25DF_READ_ARRAY_HIGH_COMMAND 	 		0x1B
#define 	AT25DF_READ_ARRAY_FAST_COMMAND 	 		0x0B
#define 	AT25DF_READ_ARRAY_COMMAND 		 		0x03 // slower
#define 	AT25DF_BYTE_PROGRAM 			 		0x02
#define 	AT25DF_RESUME_COMMAND 					0xAB
#define 	AT25DF_SECTOR_PROTECT 					0x36
#define 	AT25DF_SECTOR_UNPROTECT 				0x39

#define 	AT25DF_STATUS_DONE_MASK 			 	0x01

#define TIME_RDPD  		30  // usec to standby mode
#define TIME_EDPD  		1  // usec to deep power down
#define TIME_OUT_SPI	10

// minimal unit that can be erased
#define AT25DF_SECTOR_SIZE    (4 * 1024)  // sector size is 64kb, but 4kb blocks can be erased
// maximal unit that can be written
#define AT25DF_PAGE_SIZE      256
#define AT25DF_SECTOR_COUNT   512
//#define BUFFER_AT25DF_SIZE	  256

//uint8_t  tx_buff_at25df[BUFFER_AT25DF_SIZE];
//uint8_t  rx_buff_at25df[BUFFER_AT25DF_SIZE];
uint8_t  statusOne;

// initialize pin directions and SPI in general. Enter low power mode afterwards
void at25df_init(void);
// Read a block of data from addr
void at25df_read(uint32_t addr, uint8_t* buff, uint16_t len);
// Write len bytes (len <= 256) to flash at addr
// Block can split over multiple sectors/pages
void at25df_write(uint32_t addr, uint8_t *buff, uint16_t len);
// Erase the entire flash
void at25df_bulkErase(void);
// Erase on sector, containing address addr. Addr is not the number of sector,
// rather an address (any) inside the sector
void at25df_eraseSector(uint32_t addr);

void AT25DF_WAIT_UNTIL_DONE(void);
void AT25DF_SPI_ENABLE(void);
void AT25DF_SPI_DISABLE(void);

uint8_t readStatusRegister(void);
void writeEnable(void);
void writeDisable(void);
void sectorProtect(uint32_t);
void sectorUnprotect(uint32_t);

/**
 * \brief Save a whole page of data to the memory.
 * \param page the memory page number to write to.
 * \param buffer a pointer to the data to copy
 */
#define at25df_savePage(page, buffer)  at25df_page_program(((uint32_t) (page)) << 8, (buffer), 256)

/**
 * \brief Read data from the memory
 * \param page the memory page number to read from.
 * \param buffer a pointer to the buffer to store the data to.
 */
#define at25df_loadPage(page, buffer)  at25df_read(((uint32_t) (page)) << 8, (buffer), 256)


#endif
