/*
 * table.h
 *
 *  Created on: 25 февр. 2023 г.
 *      Author: vitaly
 */

#ifndef INC_TABLE_H_
#define INC_TABLE_H_

#define		MAX_STREAM				8

uint8_t answer_ok[66];
uint8_t send_get[5];
uint8_t send_post[6];
uint8_t send_headers[112];

const uint8_t order_array[MAX_STREAM];
const uint8_t pogoda_array[41][51];



#endif


