/*
 * kaskad.h
 *
 *  Created on: 24 июн. 2023 г.
 *      Author: vitaly
 */

#ifndef INC_KASKAD_H_
#define INC_KASKAD_H_

#endif /* INC_KASKAD_H_ */

#define		MIN_TEST_ADDR			0x01	// 0-all, no address for master
#define		MAX_TEST_ADDR			0x0A
#define		MAX_COUNT_UNITS			10
#define		ADDR_POINT_BA			0x0047
#define		ADDR_POINT_ALR			0x0002
#define		ADDR_POINT_WRN			0x0003
#define		ADDR_POINT_SRK			0x0004
#define		ADDR_POINT_RR			0x0005
#define		ADDR_POINT_RC			0x0006
#define		ADDR_POINT_DT1			0x0007
#define		ADDR_POINT_DT2			0x0008
#define		ADDR_POINT_TUST			0x000C
#define		ADDR_POINT_ZF			0x000D
#define		ADDR_POINT_Q_MIN		0x0020
#define		ADDR_POINT_Q_MAX		0x0021
#define		ALR_MASK				0x07FF
#define		WRN_MASK				0x03FF
#define		SRK_MASK				0x07FF
#define		SRK_WORK_MASK			0x007C		// bits 2,3,4,5,6 select
#define		SRK_WORK_ONLY			0x0010		// bit 4 select
#define		SRK_OFF_MASK			0x0001		// bit 0 select
#define		RR_MASK					0x001F
#define		RC_MASK					0x01FF
#define		RC_AUTO_FLAME			0x0004
#define		ROOM_WORK_MASK			0x0012
#define		ROOM_ON_MASK			0x0002
#define		RR_REMOTE_MASK			0x0002
#define		DIR_UP					0
#define		DIR_DN					1

#define		ROOM_TIMEOUT_T37		5 // 600		// in minut.
#define		ORDER_SEND_REQUEST		2 // 0-ScanUnits, 1-RegKaskad, 2-SendRequest
#define		ORDER_REG_KASKAD		1 // 0-ScanUnits, 1-RegKaskad, 2-SendRequest
#define		ORDER_SCAN_UNITS		0 // 0-ScanUnits, 1-RegKaskad, 2-SendRequest

#define		DELTA_T					2			// temp (C)

#define		BEGIN_INIT_REG			1			// heater unit BA103
#define		BEGIN_INIT_LEN			75			// heater unit BA103
#define		CHANGE_TIME_UNIT_T38	24		// in hour
#define		BIT_ON_OFF				1		// RC reg
#define		BIT_PCONST_NOM			4		// RC reg
#define     BIT_PCONST_MIN			7		// RC reg

#define		ROOM_WAIT				0
#define		ROOM_START				1	// 1, 2
#define		ROOM_SET_T				3
#define		ROOM_SET_DLY			4
#define		ROOM_STABLE				5	// 5, 6, 7
#define		ROOM_INC_UNIT			8	// 8, 9, 10, 11
#define		ROOM_DEC_UNIT			12	// 12, 13, 14, 15, 16, 17
#define		ROOM_OFF				18	// 18, 19, 20, 21

#define		SMBUS_TIMEOUT			50		// N*10  mSec
#define		READ_TIMEOUT			30		// N*10  mSec
#define		SCAN_UNITS_WAIT			0
#define		SCAN_UNITS_START		1
#define		SCAN_UNITS_SENDCMD		2
#define		SCAN_UNITS_READ			3
#define		SCAN_UNITS_NOTANSVER	4
#define		SCAN_UNITS_NEXT			5
#define		SCAN_UNITS_STOP			6
#define		INIT_UNIT_PRESEND		7
#define		INIT_UNIT_SEND			8
#define		INIT_UNIT_READ			9
#define		INIT_UNIT_REWRITE		10
#define		INIT_END_REQUEST		11

#define		REQ_UNIT_WAIT			0
#define		REQ_UNIT_SEND			1
#define		REQ_UNIT_READ			2
#define		REQ_UNIT_PAUSE			3
#define 	REQ_TIMEOUT_READ		4
#define 	REQ_WAIT_READ			5
#define		REQ_SET_STREAM			6

#define		REQUEST_PAUSE			20	// default-20, in 50 mSec., 20*50->1 sec.
#define		REQUEST_FAIL_CNT		20	// default-20, ~20 sec.
#define		REMOTE_MODE				0x0002
//#define		MAX_STREAM				8 // table.h
#define		SPACE_CNT				3

typedef struct
{
	uint16_t	ba[BA_REGISTERS+2];
	uint16_t	oldALR;
	uint16_t	oldWRN;
	uint16_t	oldSRK;
	uint16_t	oldRR;
	uint16_t	oldRC;
	uint16_t	oldDT1;
	uint16_t	oldTUST;
	uint16_t	oldQcurr;	// current power unit
	uint16_t	oldQmax;	// maximal power unit
	uint16_t	oldQmin;	// minimal power unit
	uint16_t	cntTestLine;
} thermo_unit_t;

thermo_unit_t Unit1;
thermo_unit_t Unit2;
thermo_unit_t Unit3;
thermo_unit_t Unit4;
thermo_unit_t Unit5;
thermo_unit_t Unit6;
thermo_unit_t Unit7;
thermo_unit_t Unit8;
thermo_unit_t Unit9;
thermo_unit_t Unit10;

typedef struct
{
	uint8_t		state;	// 0-stop
	uint8_t		addr;
	uint8_t		cmd;
	uint16_t	reg;
	uint16_t	len;
	uint8_t  	data[BA_REGISTERS*2];
	uint8_t		ok;
	uint16_t	timeUnit;	// counter time of working (hour)
	uint16_t    tcnt;		// counter sec.
	uint16_t 	timeout;
	uint16_t	pause;
	uint8_t		spaceCnt;
	uint16_t	failCnt;	// 50 mSec. connt
} request_t;

request_t	Req;
request_t   ReqCmd;

typedef struct
{
	uint8_t  currStream;					// index stream array (table.c)
	uint8_t	 stream;						// 0-scan, 1-kaskad, 2-request
	uint8_t  State;
	uint8_t  oldState;
	uint8_t	 AllUnits;						// counter used units (0...9 units)
	uint8_t	 kaskadUnits;					// counter kaskad units (0...9 units)
	uint8_t  CurrUnit;						// number current unit kaskad
	uint8_t  readUnit;						// index for reading unit
	uint8_t  testUnit;						// index for test connection unit
	uint8_t  addresses[MAX_COUNT_UNITS+2];	// addresses used units
	uint8_t  kaskad[MAX_COUNT_UNITS+2];		// addresses used in kaskad units
	uint8_t  indUnit;						// temporary index of addresses array
	uint16_t timeCounter;
	uint8_t  zoloState;						// shnek work state
	uint8_t  working;						// counter units in state "RABOTA"
	uint8_t	 shnekCntr;						// 0 - shnek off, 1 - shnek on
	uint16_t shnekTimeOff;					// time OFF shnek, = t33/working
	uint16_t shnekTimeOn;					// time ON shnek, = t34
} boiler_t;

boiler_t Room;

uint8_t  scanState;
uint16_t tstAddr;
uint16_t tmpReg;
uint8_t  CurrUnit;

uint8_t	 change;				// temporary position
uint8_t  readUnit;					/// debug


void ReadUnitReg(void);
void ScanUnits(void);
void RegKaskad(void);
void SendRequest(void);
uint8_t ChangeUnit(uint8_t);
void CurrUnitInc(void);
uint8_t TestModeUnit(uint8_t);
void UnitOn(uint8_t);
void UnitSetT(uint8_t);
void UnitOff(uint8_t);
void UnitPconst(uint8_t);
thermo_unit_t* SelUnit(uint8_t);
void InitializeUnit(uint8_t);
void ClearMemUnit(thermo_unit_t*);
void ClearUnits(void);
void TestUnits(void);
void SetLSAregister(void);
void ReWriteArray(uint8_t*, uint8_t);
uint8_t SetCntWork(void);



