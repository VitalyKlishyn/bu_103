/*
 * drivers.h
 *
 *  Created on: 6 дек. 2022 г.
 *      Author: vitaly
 */

#ifndef INC_DRIVERS_H_
#define INC_DRIVERS_H_

#define  TRUE_VALUE_DELAY	16		// in cycles count measuring

#define  DA11_MASK_PIN		0x01
#define  DA12_MASK_PIN		0x02
#define  DA13_MASK_PIN		0x04
#define  DA14_MASK_PIN		0x08
#define  OHR_MASK_PIN		0x10
#define  DA16_MASK_PIN		0x20
#define  DA17_MASK_PIN		0x40
#define  DA18_MASK_PIN		0x80

#define  BUZZER_PIN_ON		1
#define  BUZZER_PIN_OFF		0

#define  RELAY_PUMP1		7
#define  RELAY_PUMP2		6
#define  RELAY_SHNEK		5
#define  RELAY_ALARM		4
#define  RELAY_SZO_BUZ		3
#define  RELAY_SZO_LED		2
#define  RELAY_REZERV		1

#define  IND_PULSE_LEN		3		//  3 mSec
#define  IND_DIGIT			5		//  count digit leds
#define  DIGIT_SET			1
#define  DIGIT_CLR			0
#define  DIGIT_OFF			0
#define	 LED				0
#define  RELAY				1

#define  ADC_BUFF_LEN		18
#define  ADC_FILTER_VAL		4		// pick for skip value
#define  NTC_SENSOR_SHORT	-30		// -30(C) for testing NTC sensors
#define  NTC_SENSOR_OPEN	150		// 150(C) for testing NTC sensors

#define	SCLOCK()		HAL_GPIO_WritePin(SCLK_GPIO_Port, SCLK_Pin, GPIO_PIN_SET); HAL_GPIO_WritePin(SCLK_GPIO_Port, SCLK_Pin, GPIO_PIN_RESET)
#define	SLATCH()		HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_RESET); HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_SET)
#define OE_LED_SET()	HAL_GPIO_WritePin(OE_LED_GPIO_Port, OE_LED_Pin, GPIO_PIN_RESET)
#define OE_LED_UNSET()	HAL_GPIO_WritePin(OE_LED_GPIO_Port, OE_LED_Pin, GPIO_PIN_SET)
#define OE_OUT_SET()	HAL_GPIO_WritePin(OE_OUT_GPIO_Port, OE_OUT_Pin, GPIO_PIN_RESET)
#define OE_OUT_UNSET()	HAL_GPIO_WritePin(OE_OUT_GPIO_Port, OE_OUT_Pin, GPIO_PIN_SET)
#define OE_IN_LOAD()	HAL_GPIO_WritePin(OE_IN_GPIO_Port, OE_IN_Pin, GPIO_PIN_RESET); HAL_GPIO_WritePin(OE_IN_GPIO_Port, OE_IN_Pin, GPIO_PIN_SET)
#define SDOUT_SET()		HAL_GPIO_WritePin(SDOUT_GPIO_Port, SDOUT_Pin, GPIO_PIN_SET)
#define SDOUT_CLR()		HAL_GPIO_WritePin(SDOUT_GPIO_Port, SDOUT_Pin, GPIO_PIN_RESET)
#define SDLED_SET()		HAL_GPIO_WritePin(SDLED_GPIO_Port, SDLED_Pin, GPIO_PIN_SET)
#define SDLED_CLR()		HAL_GPIO_WritePin(SDLED_GPIO_Port, SDLED_Pin, GPIO_PIN_RESET)

#define	KEY_RELEASED		0x0000000F
#define KEY_UP_PRESS		0x0000000E
#define KEY_DN_PRESS		0x0000000D
#define KEY_ESC_PRESS		0x0000000B
#define KEY_ENT_PRESS		0x00000007
#define KEY_UP_DN_ENT_PRESS 0x00000008
#define TIME_PRESS_DLY		50			// in millisecond
#define LONG_PRESS_DLY		2000		// in millisecond
#define UP_SHORT			0x01
#define UP_LONG				0x11
#define DN_SHORT			0x02
#define DN_LONG				0x22
#define ENT_SHORT			0x04
#define ENT_LONG			0x44
#define ESC_SHORT			0x08
#define ESC_LONG			0x88
#define TIMEOUT_SERVICE		60			// in second -1
#define TIMEOUT_AUTOMAT		10			// in second -1
#define COUNT_AUTO_PUSH		150			// in mSec.

#define OHRANA_RED			0x02
#define OHRANA_GREEN		0x04
#define OHRANA_YELLOW		0x06
#define OHRANA_OFF			0
#define OHRANA_CURR			1
#define STATE_GREEN			0x20
#define STATE_RED			0x40
#define STATE_YELLOW		0x60
#define STATE_OFF			0
#define STATE_CURR			0x10

#define	FLASH_DIGIT1		0x01
#define	FLASH_DIGIT2		0x02
#define	FLASH_DIGIT3		0x04
#define FLASH_STATE			0x10
#define FLASH_OHRANA		0x20
#define	FLASH_DIGREG		0x17
#define	FLASH_DIGSTAT		0x27
#define	FLASH_DIGIT			0x07
#define	FLASH_ALL			0x37
#define	FLASH_OFF			0
#define FLASH_PERIOD		150			// in mSec*3.
#define DIGIT_POINT			0x08

#define BEEP_PULSE_1		1			// short beep
#define BEEP_PULSE_2		2			// middle beep
#define BEEP_PULSE_3		3			// long beep
#define BEEP_PULSE_4		4			// 3 long beep
#define BEEP_PULSE_5		5			// 5 x 3 long beep

#define BEEP_SHORT			10			// in mSec
#define BEEP_MIDLE			25			// in mSec
#define BEEP_LONG			500			// in mSec
#define BEEP_PAUSE			200			// in mSec
#define BEEP_SERIES_PAUSE	1000		// in mSec

// MACROS BITS
#define	BIT_SET(port, n)	(port |= (1 << n))
#define BIT_CLR(port, n) 	(port &= ~(1 << n))
#define BIT_INV(port, n) 	(port ^= (1 << n))
#define BIT_TEST(port, n) 	(port & (1 << n))

extern UART_HandleTypeDef huart1;
extern RTC_HandleTypeDef hrtc;

RTC_TimeTypeDef time;
RTC_DateTypeDef date;
HAL_StatusTypeDef res;

uint16_t countSample;			// for ADC
uint8_t  countADC;
uint8_t  trueValue;
uint16_t ADC_result[6];
uint16_t UIN[ADC_BUFF_LEN];
uint16_t NTC_Hot[ADC_BUFF_LEN];
uint16_t NTC_Cold[ADC_BUFF_LEN];
uint16_t NTC_Out[ADC_BUFF_LEN];
uint16_t NTC_In[ADC_BUFF_LEN];
int      U_input;
int      T_hot;
int      T_cold;
int      T_out;
int      T_in;

uint32_t  event_1mS_drv;
uint32_t  event_1sec_drv;
uint8_t  Tick10ms;
uint8_t  Tick50ms;
uint16_t Tick250ms;
uint16_t timeoutService;	// in second
uint16_t timeoutAutomat;	// in second

uint16_t keyNow;
uint16_t keyOld;
uint16_t keyPress;
uint16_t cntPress;
uint16_t cntLongPress;
uint8_t  keyboard;		// 0,1,2,3-short, 4,5,6,7-long
uint8_t  tmp_pump;

uint8_t  inputData;
uint8_t  relayData;			// storage current settings for data output

uint8_t rm_counter;
uint16_t cntEeRamAddr;
uint32_t secLogCnt;

typedef struct
{
	uint8_t	Digit1;
	uint8_t	Digit2;
	uint8_t Digit3;
	uint8_t LedOhrana;	  // 0-off, 0x02-red, 0x04-green, 0x06-yellow
	uint8_t LedState;	  // 0-off, 0x40-red, 0x20-green, 0x60-yellow
	uint8_t Flashing;     // bit0,1,2-display, bit4-ohrana, bit5-state
	uint16_t periodFlash; // frequency flashing
	uint8_t flagFlash;    // flag flasing
	uint8_t pulseCnt;
	uint8_t stateInd;	  // 0-off, 1-digit1, .....
} display;

typedef struct
{
	uint16_t Lengh;
	uint16_t Pause;
	uint8_t  cnt;			// series beeper
	uint8_t  State;
} beeper;

display ledDisplay;
beeper  beepPick;

void InitDrivers(void);
void Drivers(void);
void Working(void);
void LEDs(void);
void Relays(uint8_t chan, uint8_t state);
void RelayAlarm(uint8_t);
uint8_t LoadData(uint8_t led, uint8_t rel);
void ReadKeys(void);
uint16_t Keyboard(void);
uint8_t Decode(uint8_t);
void Display(char*, uint8_t, uint8_t, uint8_t);
void Beep(uint8_t);
void BeepRun(void);
void Buzzer(int state);
int ConvTemperature(int vadc);
int TestNTCsensor(int, uint16_t);
void Delays(void);
void Meassure(void);
void OutputToRegister(void);
void exitService(void);
void ReadEEtoRAM(uint32_t, uint8_t*, uint16_t);
void WriteRAMtoEE(uint32_t, uint8_t*, uint16_t);
void CompareEEpromRAM(void);
void ResetPumpsTimers(void);
void UnitStream(void);
void PrintTick(void);
void Println(UART_HandleTypeDef *huart, char _out[]);

#endif /* INC_DRIVERS_H_ */
