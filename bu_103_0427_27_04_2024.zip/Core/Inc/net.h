/*
 * net.h
 *
 *  Created on: 22 мар. 2023 г.
 *      Author: vitaly
 */

#ifndef SRC_NET_H_
#define SRC_NET_H_

/////////////////////////////////////////
// SOCKET NUMBER DEFINION              //
/////////////////////////////////////////
#define MAX_NUM_SOCKET		7	// 0...7 -> 8
#define SEND_SOCKET			2	// port 502
#define BU_SOCKET		 	1	// port 502
#define TCP_SOCKET          0	// port 80
////////////////////////////////////////////////
// Shared Buffer Definition for LOOPBACK TEST //
////////////////////////////////////////////////
#define BU_PORT				502	// server port
#define TCP_PORT			80  // default port
#define SEND_TSP_TIMEOUT	5	// in second
#define DATA_BUF_SIZE   	2048
#define SOCKET_TIME_OUT		15000		// in mSec
#define CLIENT_TIME_OUT		10000		// in mSec
#define SERVER_TIME_OUT		15000		// in mSec
#define CONNECT_TIME_OUT	5000		// in mSec
/*
// Socket Interrupt
	Sn_IR_SENDOK 	: <b>SEND_OK Interrupt</b>
	Sn_IR_TIMEOUT 	: <b>TIMEOUT Interrupt</b>
	Sn_IR_RECV 		: <b>RECV Interrupt</b>
	Sn_IR_DISCON 	: <b>DISCON Interrupt</b>
	Sn_IR_CON 		: <b>CON Interrupt</b>

// Socket state
	SOCK_CLOSED 		: Closed
	SOCK_INIT   		: Initiate state
	SOCK_LISTEN    		: Listen state
	SOCK_ESTABLISHED 	: Success to connect
	SOCK_CLOSE_WAIT   	: Closing state
	SOCK_UDP   			: UDP socket
	SOCK_MACRAW  		: MAC raw mode socket *
*/
// State definition
#define		SOCKET_ERROR		0xF8
//#define		SOCKET_INIT			0x13
//#define		SOCKET_RUN			0x14
//#define		RECV_DATA			0xF0
//#define		SEND_DATA			0xF1

#define		SEND_CLIENT_WAIT		0x80
#define		SEND_CLIENT_INIT		0x81
#define		SEND_CLIENT_CONNECT		0x82	//  2,3
#define		SEND_CLIENT_DATA		0x84
#define		SEND_CLIENT_RECV		0x85
#define		SEND_CLIENT_OK			0x86
#define     SEND_CLIENT_RESULT		0x87

#define		TIME_OUT_INIT_W5500		200	// chip select counter

// Variables
typedef struct
{
	uint8_t  num;
	uint16_t port;
	uint8_t  protokol;
	uint8_t  flag;
	uint8_t  state;
	uint8_t  state_old;
	uint8_t  send_state;	// state of TCP send
	uint8_t  send_code;		// code of error sending
	uint16_t rx_size;
	uint32_t tm_out;
	uint8_t  rx_buff[DATA_BUF_SIZE];
	uint8_t  tx_buff[DATA_BUF_SIZE];
} socket_t;

socket_t socketTCP;
//socket_t socketBU;
socket_t socketSEND;

typedef struct
{
	uint16_t nm_bt;			// counter bytes
	uint16_t st_reg;		// start register
	uint16_t nm_reg;		// counter registers for read/write
	uint8_t  err;			// temporary error counter
} modbus_t;

modbus_t modbusTCP;

uint8_t ServerIP[4];
uint8_t MyGW[4];
uint16_t ServerPort;

uint32_t event_1mS_client;
uint32_t event_1sec_client;
uint32_t presentW5500;
uint32_t int_E;

void Task_client(void);
void W5500_Reset(void);
void Sockets_Init(void);
void W5500_Init(void);
void W5500_getInit(void);
void NET_Init(void);
void SOCKET_Start(socket_t*);
void W5500_Server(socket_t*,modbus_t*);
void W5500_Client(socket_t*, uint8_t*);
void W5500_CSlow(void);
void W5500_CShigh(void);
void W5500_ReadBuff(uint8_t*,uint16_t);
void W5500_WriteBuff(uint8_t*,uint16_t);
uint8_t W5500_ReadByte(void);
void W5500_WriteByte(uint8_t);
void SetAddresses(void);
void W5500_Send_GW(void);
void W5500_Greetings(socket_t*);
uint8_t Parse(socket_t*soc, modbus_t*mod);


#endif /* SRC_NET_H_ */
