/*
 * ds1307.c
 *
 *  Created on: 17 сент. 2022 г.
 *      Author: vitaly
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "bu_103_bus.h"
#include "stm32f0xx_hal_i2c.h"
#include "ds1307.h"

extern I2C_HandleTypeDef	hi2c1;

uint32_t TableChangeTimeZimaLeto[ZIMALETO_TABLE_SIZE] = {
		0x26032302,					// 26/03/2023, 02:00, plus
		0x29102303,					// 29/10/2023, 03:00, minus
		0x31032402,					// 31/03/2024, 02:00, plus
		0x27102403,					// 27/10/2024, 03:00, minus
		0x30032502,					// 30/03/2025, 02:00, plus
		0x26102503,					// 26/10/2025, 03:00, minus
		0x29032602,					// 29/03/2026, 02:00, plus
		0x25102603,					// 25/10/2026, 03:00, minus
		0x28032702,					// 28/03/2027, 02:00, plus
		0x31102703,					// 31/10/2027, 03:00, minus
		0x26032802,					// 26/03/2028, 02:00, plus
		0x29102803,					// 29/10/2028, 03:00, minus
		0x25032902,					// 25/03/2029, 02:00, plus
		0x28102903,					// 28/10/2029, 03:00, minus
		0x31033002,					// 31/03/2030, 02:00, plus
		0x27103003,					// 27/10/2030, 03:00, minus
		0x30033102,					// 30/03/2031, 02:00, plus
		0x26103103,					// 26/10/2031, 03:00, minus
		0x28033202,					// 28/03/2032, 02:00, plus
		0x31103203,					// 31/10/2032, 03:00, minus
		0x27033302,					// 27/03/2033, 02:00, plus
		0x30103303,					// 30/10/2033, 03:00, minus
		0x26033402,					// 26/03/2034, 02:00, plus
		0x29103403,					// 29/10/2034, 03:00, minus
		0x25033502,					// 25/03/2035, 02:00, plus
		0x28103503,					// 28/10/2035, 03:00, minus
		0x30033602,					// 30/03/2036, 02:00, plus
		0x26103603,					// 26/10/2036, 03:00, minus
		0x29033702,					// 29/03/2037, 02:00, plus
		0x25103703,					// 25/10/2037, 03:00, minus
		0x28033802,					// 28/03/2038, 02:00, plus
		0x31103803,					// 31/10/2038, 03:00, minus
		0x27033902,					// 27/03/2039, 02:00, plus
		0x30103903,					// 30/10/2039, 03:00, minus
		0x25034002,					// 25/03/2040, 02:00, plus
		0x28104003,					// 28/10/2040, 03:00, minus
		0x31034102,					// 31/03/2041, 02:00, plus
		0x27104103,					// 27/10/2041, 03:00, minus
		0x30034202,					// 30/03/2042, 02:00, plus
		0x26104203,					// 26/10/2042, 03:00, minus
		0x29034302,					// 29/03/2043, 02:00, plus
		0x25104303,					// 25/10/2043, 03:00, minus
		0x27034402,					// 27/03/2044, 02:00, plus
		0x30104403,					// 30/10/2044, 03:00, minus
		0x26034502,					// 26/03/2045, 02:00, plus
		0x29104503,					// 29/10/2045, 03:00, minus
		0x25034602,					// 25/03/2046, 02:00, plus
		0x28104603,					// 28/10/2046, 03:00, minus
		0x31034702,					// 31/03/2047, 02:00, plus
		0x27104703,					// 27/10/2047, 03:00, minus
		0x29034802,					// 29/03/2048, 02:00, plus
		0x25104803,					// 25/10/2048, 03:00, minus
		0x28034902,					// 28/03/2049, 02:00, plus
		0x31104903,					// 31/10/2049, 03:00, minus
		0x27035002,					// 27/03/2050, 02:00, plus
		0x30105003,					// 30/10/2050, 03:00, minus
		0x26035102,					// 26/03/2051, 02:00, plus
		0x29105103,					// 29/10/2051, 03:00, minus
		0x31035202,					// 31/03/2052, 02:00, plus
		0x27105203,					// 27/10/2052, 03:00, minus
		0x30035302,					// 30/03/2053, 02:00, plus
		0x26105303,					// 26/10/2053, 03:00, minus
		0x29035402,					// 29/03/2054, 02:00, plus
		0x25105403,					// 25/10/2054, 03:00, minus
		0x28035502,					// 28/03/2055, 02:00, plus
		0x31105503,					// 31/10/2055, 03:00, minus
		0x26035602,					// 26/03/2056, 02:00, plus
		0x29105603,					// 29/10/2056, 03:00, minus
		0x25035702,					// 25/03/2057, 02:00, plus
		0x28105703,					// 28/10/2057, 03:00, minus
		0x31035802,					// 31/03/2058, 02:00, plus
		0x27105803,					// 27/10/2058, 03:00, minus
		0x30035902,					// 30/03/2059, 02:00, plus
		0x26105903,					// 26/10/2059, 03:00, minus
		0x28036002,					// 28/03/2060, 02:00, plus
		0x31106003,					// 31/10/2060, 03:00, minus
		0x27036102,					// 27/03/2061, 02:00, plus
		0x30106103,					// 30/10/2061, 03:00, minus
		0x26036202,					// 26/03/2062, 02:00, plus
		0x29106203,					// 29/10/2062, 03:00, minus
		0x25036302,					// 25/03/2063, 02:00, plus
		0x25106303,					// 28/10/2063, 03:00, minus
		0xFFFFFFFF,
		0xFFFFFFFF
};

void ClockInit(void)
{
	buff_i2c[0] = 0;
	HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, 1, TIMEOUT_I2C);
	HAL_I2C_Master_Receive (&hi2c1, CLOCK_ADDR, buff_i2c, 1, TIMEOUT_I2C);

    if(buff_i2c[0] & 0x80)
    {
    	buff_i2c[0] = 0;			//set address
    	buff_i2c[1] = 0;			//second default
    	buff_i2c[2] = 0;			//minute default
    	buff_i2c[3] = 0x12;			//hour default
    	buff_i2c[4] = 0x07;			//weekday default
    	buff_i2c[5] = 0x26;			//day default
    	buff_i2c[6] = 0x02;			//month default
    	buff_i2c[7] = 0x23;			//year default
        HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, 8, TIMEOUT_I2C);
    }
}

void ReadTime(void)
{
	buff_i2c[0] = 0;
	HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, 1, TIMEOUT_I2C);
	HAL_I2C_Master_Receive (&hi2c1, CLOCK_ADDR, buff_i2c, 8, TIMEOUT_I2C);

    Second = ((buff_i2c[0] >> 4) * 10) + (buff_i2c[0] & 0x0F);
    Minut = ((buff_i2c[1] >> 4) * 10) + (buff_i2c[1] & 0x0F);
    Hour = ((buff_i2c[2] >> 4) * 10) + (buff_i2c[2] & 0x0F);
    Day = ((buff_i2c[4] >> 4) * 10) + (buff_i2c[4] & 0x0F);
    Month = ((buff_i2c[5] >> 4) * 10) + (buff_i2c[5] & 0x0F);
    Year = ((buff_i2c[6] >> 4) * 10) + (buff_i2c[6] & 0x0F);

    TimeToRegisters();
}

void WriteTime(uint8_t *c, uint8_t v)
{
	int ci;

	buff_i2c[0] = 0;
	for(ci=1; ci<(v+1); ci++)
	{
		buff_i2c[ci] = *(c++);
	}
	HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, v+1, TIMEOUT_I2C);
}

void WriteDate(uint8_t *c, uint8_t v)
{
	int ci;

	buff_i2c[0] = 0x04;
	for(ci=1; ci<(v+1); ci++)
	{
		buff_i2c[ci] = *(c++);
	}
	HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, v+1, TIMEOUT_I2C);
}

void WriteWeekDay(uint8_t dn)
{
	buff_i2c[0] = 0x03;
	buff_i2c[1] = dn;
	HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, 2, TIMEOUT_I2C);
}

void ReadRAM(uint8_t addr, uint8_t *buf, uint8_t len)
{	// buff_i2c size = RAM_CONFIG_LEN_BYTES
	buff_i2c[0] = addr + RAM_START_ADDRESS;
	HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, 1, TIMEOUT_I2C);
	HAL_I2C_Master_Receive (&hi2c1, CLOCK_ADDR, buf, len, TIMEOUT_I2C);
}

void WriteRAM(uint8_t addr, uint8_t *buf, uint8_t len)
{	// buff_i2c size = RAM_CONFIG_LEN_BYTES
	if(len > RAM_LENGH_MAX)	len = RAM_LENGH_MAX;
	buff_i2c[0] = addr + RAM_START_ADDRESS;
	memcpy(buff_i2c+1, buf, len);
	HAL_I2C_Master_Transmit (&hi2c1, CLOCK_ADDR, buff_i2c, len+1, TIMEOUT_I2C);
}

void TimeToString(uint8_t* str)
{
	char value[8], tmpString[32];

    tmpString[0] = '\0';
    strcat(tmpString, "\nTime: ");
    itoa(Hour,value,10);
    if(strlen(value) == 1)  strcat(tmpString, "0");
    strcat(tmpString, value);
    strcat(tmpString, ":");
    itoa(Minut,value,10);
    if(strlen(value) == 1)  strcat(tmpString, "0");
    strcat(tmpString, value);
    strcat(tmpString, ":");
    itoa(Second,value,10);
    if(strlen(value) == 1)  strcat(tmpString, "0");
    strcat(tmpString, value);
    strcat(tmpString, "  \0");
    strcpy((char*)str, tmpString);
}

void DateToString(uint8_t* str)
{
	char tmpString[32], value[8];

    tmpString[0] = '\0';
    strcat(tmpString, "\nDate: ");
    itoa(Day,value,10);
    if(strlen(value) == 1)  strcat(tmpString, "0");
    strcat(tmpString, value);
    strcat(tmpString, "/");
    itoa(Month,value,10);
    if(strlen(value) == 1)  strcat(tmpString, "0");
    strcat(tmpString, value);
    strcat(tmpString, "/20");
    itoa(Year,value,10);
    if(strlen(value) == 1)  strcat(tmpString, "0");
    strcat(tmpString, value);
    strcat(tmpString, "  \0");
    strcpy((char*)str, tmpString);
}

void TimeToRegisters(void)
{ // date and time
/*
	uint8_t dst;

	ClockRAM.config.time_PP380 = Hour << 8;
	ClockRAM.config.time_PP380 |= Minut;
	dst = 0;
	if(ClockRAM.config.date_PP380 & 0x8000)		dst = 1;	// memory dst
	ClockRAM.config.date_PP380 = (Year << 9) | (Month << 5) | Day;
	if(dst == 1)	ClockRAM.config.date_PP380 |= 0x8000;
*/
}

void TimeFromRegisters(uint16_t val)
{ // set time from command register
	uint16_t ttmp;
	uint8_t  tbuff[4];

	ttmp = val >> 8;			// hour
	ttmp = ttmp & 0x1F;
	if(ttmp > 23)	ttmp = 12;
	tbuff[2] = ConvToChip(ttmp);
	ttmp = val;
	ttmp = ttmp & 0x3F;			// minut
	if(ttmp > 59)	ttmp = 0;
	tbuff[1] = ConvToChip(ttmp);
	tbuff[0] = 0;				// second
	WriteTime(tbuff, 3);
}

void DateFromRegisters(uint16_t val)
{ // set date from command register
	uint16_t ttmp;
	uint8_t  tbuff[4];

	ttmp = val >> 9;
	ttmp = ttmp & 0x3F;			// year
	tbuff[2] = ConvToChip(ttmp);
	ttmp = val >> 5;
	ttmp = ttmp & 0x0F;			// month
	if(ttmp > 12)	ttmp = 1;
	tbuff[1] = ConvToChip(ttmp);
	ttmp = val & 0x1F;			// day
	if(ttmp > 31)	ttmp = 1;
	tbuff[0] = ConvToChip(ttmp);
	WriteDate(tbuff, 3);
}

uint8_t ConvToChip(uint8_t val)
{ // input - 8bit, output 4bit + 4bit decimal
	uint8_t rez;

	rez = (val / 10) << 4;
	rez |= val % 10;
	return rez;
}


