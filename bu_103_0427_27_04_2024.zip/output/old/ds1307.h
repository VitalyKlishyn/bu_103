/*
 * ds1307.h
 *
 *  Created on: 17 сент. 2022 г.
 *      Author: vitaly
 */

#ifndef DS1307_H_
#define DS1307_H_

#include "main.h"
#include "drivers.h"
#include "secure.h"
#include "bu_103_bus.h"
#include "automat.h"

#define CLOCK_ADDR  		0xD0
#define RAM_START_ADDRESS	0x08
#define RAM_LENGH_MAX		50
//#define TIMEOUT_I2C			5
#define ZIMALETO_TABLE_SIZE 84

extern   uint8_t buff_i2c[];

    uint8_t Hour;
    uint8_t Minut;
    uint8_t Second;
    uint8_t Day;
    uint8_t Month;
    uint8_t Year;

void ClockInit(void);
void ReadTime(void);
void WriteTime(uint8_t*, uint8_t);
void WriteDate(uint8_t*, uint8_t);
void WriteWeekDay(uint8_t);
void ReadRAM(uint8_t, uint8_t*, uint8_t);
void WriteRAM(uint8_t, uint8_t*, uint8_t);
void DateToString(uint8_t*);
void TimeToString(uint8_t*);
void TimeToRegisters(void);
void TimeFromRegisters(uint16_t);
void DateFromRegisters(uint16_t);
uint8_t ConvToChip(uint8_t);


#endif /* DS1307_H_ */
